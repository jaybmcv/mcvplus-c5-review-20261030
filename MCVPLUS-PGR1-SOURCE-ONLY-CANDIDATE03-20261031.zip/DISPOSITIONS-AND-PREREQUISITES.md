# Canonical dispositions and prerequisites

UNTESTED / SOURCE-ONLY-NOT-AUTHORIZED. This is the single consolidated follow-up list. None is execution authorization. Exact historical names and per-name dispositions are in F03-SUBCHECK-CROSSWALK.json; grouped requirements are in F03-REQUIREMENT-MAP.md.

## SOURCE blockers

- Candidate03 source correction of F06-R1/R2/R3: empty separately provisioned store plus exclusive per-attempt claim; any collision/write/flush/close failure irrevocably revokes ALL later store writes. Retain and parse bounded Bootstrap captures before first storage write and return raw base64/parsed failure data on rejection. Native managed Dispose failures are secondary cleanup records and do not prevent original LaunchEvidence return. These are UNTESTED source corrections, not qualified protected-store admission or supervisor guarantees.


- F01: close-before-link exclusive hardlink source and unchanged Held.identity guard retained. F05 now defers all dummy filesystem preparation until the semantic phase permits progression. Semantic stop buffers all 28 honest records; L18 preparation errors retain BLOCKED/error detail with other unentered physical cases NOT_RUN. No passing guard or historical L18 repair is claimed.
- F02/F04: independently pinned runner/inspector/helper source and suspended assign-before-resume containment retained. Native binary/source toolchain provenance, protected pre-script parent/toolchain admission and an independently enforced outer supervisor for synchronous native/preflight/cleanup calls and total 900 seconds remain missing. Checking elapsed time after return cannot interrupt a stuck call.
- F06: source/ParentCoordinator.ps1 is the independently pinned parent entrypoint adapter, with a source-only guard before candidate work. It captures returning Bootstrap preflight/native/capture/termination failures, retained raw captured streams, primary and secondary cleanup errors, exclusive flushed envelope and evidence manifest. Bootstrap preserves cleanup errors; Python cleanup_close records bounded CloseHandle failures and omitted counts without retry or primary replacement. Complete guarantees remain BLOCKED: no qualified ancestor-relative evidence-store admission, protected parent toolchain, OS interruptibility or process-death-proof flush. Parameter binding/guard failure and rejected evidence destinations require an external caller to retain diagnostics. No invented entered cases. The output inventory lists successfully flushed owned evidence only, not a complete disk census. Manifest identity is returned externally to avoid circular self-hash.
- F03 remains partial: supported narrow native token/descriptor/AccessCheck predicates and fail-closed unknowns are authored. Complete arbitrary principal/group/claim, special owner/CREATOR OWNER/OWNER RIGHTS/object/callback/conditional ACE, restricted/MIC/privilege and future-child closure is absent.
- Actual-token class/origin admission adapter is a missing SOURCE implementation. NativeToken.from_handle retains/snapshots an actual handle but does not establish how it was obtained, genuine representative class or service origin. This gap is separate from unavailable operational tokens.
- Parent-handle relative resolution/at-creation directory handle binding, directory creation-to-open window, full rename/destination/replacement/redirect/volume authority and sibling-create exception remain absent.
- Exact provider finite filename/rotation enforcement, Postgres external tablespace/preload/config/library closure, complete code RX inventory and installed spec/SCM/NSSM/account/SID-type/registry/environment/loader authority adapters remain absent.
- Full protected copy/staging and installed readback/operational-consumer integration (Staging-Security, Staging-Gate, Stage-Candidate, installer) remain absent. Map hashes and rejection-only gate do not complete them.

## Future LOCAL verification (separate authorization required)

- Independently build/review native helper, pin binary plus source/toolchain relationship. No assembly is supplied or built here.
- Verify semantic stop has no prior dummy filesystem mutation; 28 accounting on mismatch, preparation failure and evidence collision; exclusive close-before-link and exact unchanged guard/sentinels; no retry or rejected-path writes.
- Exercise suspended startup/assign/resume/collision, actual token reference comparisons, bounded raw capture/decoding/nonzero/timeout/termination/close failures, exact owned job empty or explicit BLOCKED_CONTAINMENT. Include coordinator preflight/capture/manifest failures and primary plus secondary errors.
- Verify actual pin/inventory rejection, substitutions, parent-relative creation/observer continuity after missing source is supplied, and complete independently retained preservation/output inventory. No inert or synthetic observation substitutes for those adapters.

## Actual OPERATIONAL prerequisites (separate authorization required)

- Genuine ordinary/filtered/restricted/elevated/SYSTEM/service tokens with supported class/origin evidence; real SCM existence, account and SID-type bindings. No synthetic service-shaped identities or manufactured service/account/token substitutes.
- Protected bootstrap/PowerShell/.NET/Python/native helper/DLL/stdlib/compiler dependencies, every ancestor, TEMP/TMP/PATH/PGSYSCONFDIR/cwd and independent supervisor/evidence destination admission.
- Exact installed T/K/C/S roots and complete executable/config/library/environment/registry/SCM/NSSM authority/readback; full 52 packet + 1 manifest + 1,638 external payload closure and protected staging/copy evidence.
- Exact provider/tunnel secret-disabled bindings and Postgres own-cluster/external-path closure; no ledger reservation, usable permit, cluster/tunnel/provider execution follows from a filesystem result.
- Operational root/service/remote before/after preservation remains explicitly UNQUALIFIED. No probes or simulated readbacks supplied. Vercel restoration is separate and unverified.

Historical evidence remains 1 static PASS (L26), 27 BLOCKED, 134 required BLOCKED names. New runtime evidence is ZERO. All 48 attempts remain unspent (42 primary + 6 reserve). Communications publication/synchronization is excluded and is not a PG-R1 prerequisite. No new audience draft is needed for this internal security correction.
