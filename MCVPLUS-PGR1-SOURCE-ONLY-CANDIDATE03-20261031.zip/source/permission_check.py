"""PG-R1 native token/held-descriptor checker -- SOURCE ONLY, UNTESTED.

No entry point, token acquisition, privilege enablement, logon, service lookup,
ACL changes, fixture creation, or automatic execution is provided. Importing this
module is permitted only by a separately admitted protected loader; delivery is
not such admission. Native observations below never authorize Setup or staging.

AccessCheck is authoritative for the supported ordinary allow/deny DACL subset.
Unsupported authorization data produces BLOCKED_UNKNOWN, never an omitted ACE.
Actual token handles, rather than dictionaries of convenient SIDs, are required.
An actual kernel token still needs external provenance and representative-class
coverage; duplication does not establish that it is an installed service token.
"""
import ctypes as C
from ctypes import wintypes as W
import hashlib
import json
import re

import windows_api as api


PTR = C.c_void_p
DWORD = W.DWORD
HANDLE = W.HANDLE
Blocked = api.Blocked
A, K = api.A, api.K
MAX_NATIVE_BYTES = 4 * 1024 * 1024
MAX_ENTRIES = 4096
TOKEN_QUERY = 0x0008
TOKEN_IMPERSONATION = 2
SECURITY_IMPERSONATION = 2
ERROR_INSUFFICIENT_BUFFER = 122
ERROR_ACCESS_DENIED = 5
AUTHORIZATION_SECURITY_INFORMATION = 0x1F7
FILE_RIGHTS = frozenset((1, 2, 4, 8, 0x10, 0x20, 0x40, 0x80,
                         0x100, 0x10000, 0x20000, 0x40000, 0x80000, 0x100000))
MUTATION_RIGHTS = 2 | 4 | 0x10 | 0x40 | 0x100 | 0x10000 | 0x40000 | 0x80000
GROUP_KNOWN_ATTRIBUTES = 0xE000007F
PRIVILEGE_KNOWN_ATTRIBUTES = 0x80000007
SYSTEM_SID = 'S-1-5-18'
ADMIN_SID = 'S-1-5-32-544'
TRUSTED_INSTALLER_SID = 'S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464'
OWNER_SPECIAL_SIDS = frozenset(('S-1-3-0', 'S-1-3-1', 'S-1-3-4'))
KNOWN_SIDS = {
    SYSTEM_SID: ('NT AUTHORITY', 'SYSTEM', 5, 'system'),
    ADMIN_SID: ('BUILTIN', 'Administrators', 4, 'elevation-dependent-administrators'),
    'S-1-1-0': ('', 'Everyone', 5, 'untrusted-broad'),
    'S-1-5-11': ('NT AUTHORITY', 'Authenticated Users', 5, 'untrusted-broad'),
    'S-1-5-32-545': ('BUILTIN', 'Users', 4, 'untrusted-broad'),
    'S-1-3-0': ('', 'CREATOR OWNER', 5, 'unsupported-creator-owner'),
    'S-1-3-1': ('', 'CREATOR GROUP', 5, 'unsupported-creator-group'),
    'S-1-3-4': ('', 'OWNER RIGHTS', 5, 'unsupported-owner-rights'),
    TRUSTED_INSTALLER_SID: ('NT SERVICE', 'TrustedInstaller', 5,
                          'trusted-installer-existing-prerequisite-only'),
}
SID_TYPES = {1: 'User', 2: 'Group', 3: 'Domain', 4: 'Alias', 5: 'WellKnownGroup',
             6: 'DeletedAccount', 7: 'Invalid', 8: 'Unknown', 9: 'Computer',
             10: 'Label', 11: 'LogonSession'}


class Luid(C.Structure):
    _fields_ = [('low', DWORD), ('high', W.LONG)]


class SidAndAttributes(C.Structure):
    _fields_ = [('sid', PTR), ('attributes', DWORD)]


class GroupsHeader(C.Structure):
    _fields_ = [('count', DWORD), ('first', SidAndAttributes)]


class LuidAndAttributes(C.Structure):
    _fields_ = [('luid', Luid), ('attributes', DWORD)]


class PrivilegesHeader(C.Structure):
    _fields_ = [('count', DWORD), ('first', LuidAndAttributes)]


class TokenStatistics(C.Structure):
    _fields_ = [('tokenId', Luid), ('authenticationId', Luid),
                ('expirationTime', C.c_longlong), ('tokenType', DWORD),
                ('impersonationLevel', DWORD), ('dynamicCharged', DWORD),
                ('dynamicAvailable', DWORD), ('groupCount', DWORD),
                ('privilegeCount', DWORD), ('modifiedId', Luid)]


class AttributesInformation(C.Structure):
    _fields_ = [('version', W.WORD), ('reserved', W.WORD),
                ('count', DWORD), ('attributes', PTR)]


class GenericMapping(C.Structure):
    _fields_ = [('read', DWORD), ('write', DWORD), ('execute', DWORD), ('all', DWORD)]


GetTokenInformation = api.bind(A, 'GetTokenInformation',
    [HANDLE, C.c_int, PTR, DWORD, C.POINTER(DWORD)], W.BOOL)
DuplicateTokenEx = api.bind(A, 'DuplicateTokenEx',
    [HANDLE, DWORD, PTR, C.c_int, C.c_int, C.POINTER(HANDLE)], W.BOOL)
DuplicateHandle = api.bind(K, 'DuplicateHandle',
    [HANDLE, HANDLE, HANDLE, C.POINTER(HANDLE), DWORD, W.BOOL, DWORD], W.BOOL)
LookupPrivilegeName = api.bind(A, 'LookupPrivilegeNameW',
    [W.LPCWSTR, C.POINTER(Luid), W.LPWSTR, C.POINTER(DWORD)], W.BOOL)
LookupAccountSid = api.bind(A, 'LookupAccountSidW',
    [W.LPCWSTR, PTR, W.LPWSTR, C.POINTER(DWORD), W.LPWSTR,
     C.POINTER(DWORD), C.POINTER(DWORD)], W.BOOL)
LookupAccountName = api.bind(A, 'LookupAccountNameW',
    [W.LPCWSTR, W.LPCWSTR, PTR, C.POINTER(DWORD), W.LPWSTR,
     C.POINTER(DWORD), C.POINTER(DWORD)], W.BOOL)
IsValidSid = api.bind(A, 'IsValidSid', [PTR], W.BOOL)
IsValidSecurityDescriptor = api.bind(A, 'IsValidSecurityDescriptor', [PTR], W.BOOL)
GetSecurityDescriptorOwner = api.bind(A, 'GetSecurityDescriptorOwner',
    [PTR, C.POINTER(PTR), C.POINTER(W.BOOL)], W.BOOL)
GetSecurityDescriptorGroup = api.bind(A, 'GetSecurityDescriptorGroup',
    [PTR, C.POINTER(PTR), C.POINTER(W.BOOL)], W.BOOL)
GetSecurityDescriptorSacl = api.bind(A, 'GetSecurityDescriptorSacl',
    [PTR, C.POINTER(W.BOOL), C.POINTER(PTR), C.POINTER(W.BOOL)], W.BOOL)
AccessCheck = api.bind(A, 'AccessCheck',
    [PTR, HANDLE, DWORD, C.POINTER(GenericMapping), PTR, C.POINTER(DWORD),
     C.POINTER(DWORD), C.POINTER(W.BOOL)], W.BOOL)


def _blocked(reason, **details):
    raise Blocked(reason, details=details or None)


def _native_failure(reason):
    raise Blocked(reason, C.get_last_error())


def _address(value):
    return value.value if isinstance(value, C.c_void_p) else int(value or 0)


def _handle_value(value):
    # bool, dict, SID-context objects, pseudo-handles and null handles are rejected.
    if isinstance(value, C.c_void_p):
        value = value.value
    if type(value) is not int or value <= 0 or value == C.c_void_p(-1).value:
        _blocked('BLOCKED_ACTUAL_TOKEN_HANDLE_REQUIRED')
    return value


def _require_range(buffer, pointer, size, label):
    address = _address(pointer)
    start, end = C.addressof(buffer), C.addressof(buffer) + C.sizeof(buffer)
    if size < 0 or not address or address < start or address + size > end:
        _blocked('BLOCKED_NATIVE_BUFFER_RANGE', field=label)
    return address


def _luid(value):
    return '%08x:%08x' % (value.high & 0xFFFFFFFF, value.low)


def _fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=True).encode('ascii')).hexdigest()


def _token_info(handle, information_class):
    needed = DWORD()
    C.set_last_error(0)
    success = GetTokenInformation(handle, information_class, None, 0, C.byref(needed))
    error = C.get_last_error()
    if success or error != ERROR_INSUFFICIENT_BUFFER or not 0 < needed.value <= MAX_NATIVE_BYTES:
        raise Blocked('BLOCKED_TOKEN_INFORMATION_UNAVAILABLE', error,
                      {'informationClass': information_class, 'requiredBytes': needed.value})
    buffer = C.create_string_buffer(needed.value)
    returned = DWORD()
    if not GetTokenInformation(handle, information_class, buffer, len(buffer), C.byref(returned)):
        _native_failure('BLOCKED_TOKEN_INFORMATION_READ')
    if returned.value > len(buffer) or returned.value == 0:
        _blocked('BLOCKED_TOKEN_INFORMATION_SIZE', informationClass=information_class)
    return buffer


def _fixed_info(handle, information_class, structure):
    buffer = _token_info(handle, information_class)
    if len(buffer) < C.sizeof(structure):
        _blocked('BLOCKED_TOKEN_INFORMATION_TRUNCATED', informationClass=information_class)
    return structure.from_buffer_copy(buffer.raw[:C.sizeof(structure)])


def _dword_info(handle, information_class):
    return int(_fixed_info(handle, information_class, DWORD).value)


def _sid_record(pointer, buffer, allow_unresolved=False):
    address = _require_range(buffer, pointer, 8, 'SID header')
    header = C.string_at(address, 8)
    sid_bytes = 8 + 4 * header[1]
    if header[0] != 1 or header[1] > 15:
        _blocked('BLOCKED_SID_LAYOUT')
    _require_range(buffer, address, sid_bytes, 'SID body')
    if not IsValidSid(address):
        _native_failure('BLOCKED_INVALID_SID')
    text_pointer = PTR()
    if not api.SidToText(address, C.byref(text_pointer)):
        _native_failure('BLOCKED_SID_TEXT')
    try:
        sid = C.wstring_at(text_pointer)
    finally:
        api.LocalFree(text_pointer)
    if sid in KNOWN_SIDS:
        domain, name, kind, principal_class = KNOWN_SIDS[sid]
        resolution = 'EXACT_WELL_KNOWN_SID'
    elif re.fullmatch(r'S-1-16-\d+', sid):
        domain, name, kind, principal_class = 'Mandatory Label', sid, 10, 'integrity-label'
        resolution = 'STRUCTURAL_MANDATORY_LABEL_SID'
    elif re.fullmatch(r'S-1-5-5-\d+-\d+', sid):
        domain, name, kind, principal_class = 'NT AUTHORITY', sid, 11, 'logon-session'
        resolution = 'STRUCTURAL_LOGON_SESSION_SID'
    else:
        name_buffer, domain_buffer = C.create_unicode_buffer(1024), C.create_unicode_buffer(1024)
        name_length, domain_length, use = DWORD(1024), DWORD(1024), DWORD()
        # Supported resolution only; denial/unmapped/oversize is not bypassed.
        # This API can consult identity providers during a future authorized run.
        if not LookupAccountSid(None, address, name_buffer, C.byref(name_length),
                                domain_buffer, C.byref(domain_length), C.byref(use)):
            error = C.get_last_error()
            if allow_unresolved:
                return {'sid': sid, 'sidBytes': sid_bytes, 'domain': None, 'name': None,
                        'sidType': None, 'sidTypeName': 'Unresolved', 'resolved': False,
                        'principalClass': 'unresolved-principal',
                        'resolution': 'BLOCKED_PRINCIPAL_UNRESOLVED', 'win32Error': error,
                        'membershipClosure': 'UNQUALIFIED'}
            raise Blocked('BLOCKED_PRINCIPAL_UNRESOLVED', error, {'sid': sid})
        domain, name, kind = domain_buffer.value, name_buffer.value, int(use.value)
        if kind not in (1, 2, 3, 4, 5, 9, 10, 11) or not name:
            if allow_unresolved:
                return {'sid': sid, 'sidBytes': sid_bytes, 'domain': domain, 'name': name,
                        'sidType': kind, 'sidTypeName': SID_TYPES.get(kind, 'Unknown'),
                        'resolved': False, 'principalClass': 'unresolved-principal',
                        'resolution': 'BLOCKED_PRINCIPAL_SID_TYPE', 'membershipClosure': 'UNQUALIFIED'}
            _blocked('BLOCKED_PRINCIPAL_SID_TYPE', sid=sid, sidType=kind)
        principal_class = 'resolved-principal-membership-closure-unqualified'
        resolution = 'WINDOWS_LOOKUP_ACCOUNT_SID'
    return {'sid': sid, 'sidBytes': sid_bytes, 'domain': domain, 'name': name,
            'sidType': kind, 'sidTypeName': SID_TYPES.get(kind, 'Unknown'),
            'principalClass': principal_class, 'resolution': resolution, 'resolved': True,
            'membershipClosure': 'NOT_INFERRED_FROM_ACCOUNT_NAME'}


def _groups(handle, information_class):
    buffer = _token_info(handle, information_class)
    if len(buffer) < C.sizeof(DWORD):
        _blocked('BLOCKED_TOKEN_GROUP_HEADER')
    count = DWORD.from_buffer_copy(buffer.raw[:4]).value
    offset, entry_size = GroupsHeader.first.offset, C.sizeof(SidAndAttributes)
    if count > MAX_ENTRIES or (count and offset + count * entry_size > len(buffer)):
        _blocked('BLOCKED_TOKEN_GROUP_BOUND', informationClass=information_class)
    records = []
    for index in range(count):
        entry = SidAndAttributes.from_buffer_copy(buffer.raw[offset + index * entry_size:
                                                            offset + (index + 1) * entry_size])
        attributes = int(entry.attributes)
        if attributes & ~GROUP_KNOWN_ATTRIBUTES:
            _blocked('BLOCKED_TOKEN_GROUP_ATTRIBUTES', attributes=attributes)
        if attributes & 0x10 and attributes & 4:
            _blocked('BLOCKED_TOKEN_GROUP_ENABLED_DENY_ONLY_CONTRADICTION')
        record = _sid_record(entry.sid, buffer)
        record.update(attributes=attributes, enabled=bool(attributes & 4),
                      denyOnly=bool(attributes & 0x10), ownerEligible=bool(attributes & 8),
                      integrity=bool(attributes & 0x20), resource=bool(attributes & 0x20000000),
                      logonId=bool(attributes & 0xC0000000 == 0xC0000000))
        records.append(record)
    if len({entry['sid'] for entry in records}) != len(records):
        _blocked('BLOCKED_DUPLICATE_TOKEN_GROUP_SID', informationClass=information_class)
    return records


def _privilege_record(luid, attributes):
    name = C.create_unicode_buffer(256)
    length = DWORD(len(name))
    if attributes & ~PRIVILEGE_KNOWN_ATTRIBUTES:
        _blocked('BLOCKED_TOKEN_PRIVILEGE_ATTRIBUTES', attributes=attributes)
    if attributes & 2 and attributes & 4:
        _blocked('BLOCKED_TOKEN_PRIVILEGE_ENABLED_REMOVED_CONTRADICTION')
    if not LookupPrivilegeName(None, C.byref(luid), name, C.byref(length)):
        _native_failure('BLOCKED_PRIVILEGE_NAME_UNRESOLVED')
    return {'luid': _luid(luid), 'name': name.value, 'attributes': int(attributes),
            'enabled': bool(attributes & 2), 'enabledByDefault': bool(attributes & 1),
            'removed': bool(attributes & 4), 'usedForAccess': bool(attributes & 0x80000000)}


def _privileges(handle):
    buffer = _token_info(handle, 3)
    if len(buffer) < 4:
        _blocked('BLOCKED_TOKEN_PRIVILEGE_HEADER')
    count = DWORD.from_buffer_copy(buffer.raw[:4]).value
    offset, entry_size = PrivilegesHeader.first.offset, C.sizeof(LuidAndAttributes)
    if count > MAX_ENTRIES or (count and offset + count * entry_size > len(buffer)):
        _blocked('BLOCKED_TOKEN_PRIVILEGE_BOUND')
    result = []
    for index in range(count):
        entry = LuidAndAttributes.from_buffer_copy(buffer.raw[offset + index * entry_size:
                                                             offset + (index + 1) * entry_size])
        result.append(_privilege_record(entry.luid, entry.attributes))
    if len({entry['luid'] for entry in result}) != len(result):
        _blocked('BLOCKED_DUPLICATE_TOKEN_PRIVILEGE')
    return result


def _statistics(handle):
    stats = _fixed_info(handle, 10, TokenStatistics)
    return {'tokenId': _luid(stats.tokenId), 'authenticationId': _luid(stats.authenticationId),
            'modifiedId': _luid(stats.modifiedId), 'expirationTime': stats.expirationTime,
            'tokenType': int(stats.tokenType), 'impersonationLevel': int(stats.impersonationLevel),
            'groupCount': int(stats.groupCount), 'privilegeCount': int(stats.privilegeCount)}


def _sid_field(handle, information_class, with_attributes=False, allow_null=False):
    buffer = _token_info(handle, information_class)
    structure = SidAndAttributes if with_attributes else PTR
    if len(buffer) < C.sizeof(structure):
        _blocked('BLOCKED_TOKEN_SID_FIELD_TRUNCATED', informationClass=information_class)
    entry = structure.from_buffer_copy(buffer.raw[:C.sizeof(structure)])
    pointer = entry.sid if with_attributes else entry.value
    if not pointer and allow_null:
        return None
    result = _sid_record(pointer, buffer)
    if with_attributes:
        result['attributes'] = int(entry.attributes)
    return result


def _attribute_summary(handle, information_class):
    header = _fixed_info(handle, information_class, AttributesInformation)
    if header.version != 1 or header.reserved or header.count or header.attributes:
        _blocked('BLOCKED_TOKEN_CLAIMS_OR_SECURITY_ATTRIBUTES',
                 informationClass=information_class, version=header.version,
                 count=header.count, hasAttributePointer=bool(header.attributes))
    return {'informationClass': information_class, 'version': header.version, 'count': 0}


def _snapshot_token(handle):
    before = _statistics(handle)
    user = _sid_field(handle, 1, with_attributes=True)
    if user['attributes']:
        _blocked('BLOCKED_TOKEN_USER_ATTRIBUTES', attributes=user['attributes'])
    groups, restricted = _groups(handle, 2), _groups(handle, 11)
    privileges = _privileges(handle)
    integrity = _sid_field(handle, 25, with_attributes=True)
    match = re.fullmatch(r'S-1-16-(\d+)', integrity['sid'])
    if not match or integrity['attributes'] not in (0x20, 0x60):
        _blocked('BLOCKED_TOKEN_INTEGRITY_LAYOUT')
    integrity['rid'] = int(match.group(1))
    token_type = _dword_info(handle, 8)
    if token_type not in (1, 2):
        _blocked('BLOCKED_TOKEN_TYPE')
    impersonation = _dword_info(handle, 9) if token_type == 2 else None
    if impersonation is not None and impersonation < SECURITY_IMPERSONATION:
        _blocked('BLOCKED_TOKEN_IMPERSONATION_LEVEL')
    owner, primary_group = _sid_field(handle, 4), _sid_field(handle, 5)
    # All claim namespaces, including restricted/device/security attributes, are
    # inspected. Unsupported information classes are unavailable evidence.
    claims = [_attribute_summary(handle, item) for item in (33, 34, 35, 36, 39)]
    device_groups, restricted_device_groups = _groups(handle, 37), _groups(handle, 38)
    if device_groups or restricted_device_groups:
        _blocked('BLOCKED_TOKEN_DEVICE_GROUPS_UNSUPPORTED')
    capabilities = _groups(handle, 30)
    appcontainer_sid = _sid_field(handle, 31, allow_null=True)
    appcontainer = _dword_info(handle, 29)
    sandbox_inert = _dword_info(handle, 15)
    ui_access = _dword_info(handle, 26)
    virtual_enabled, virtual_allowed = _dword_info(handle, 24), _dword_info(handle, 23)
    mandatory_policy = _dword_info(handle, 27)
    if mandatory_policy & ~3:
        _blocked('BLOCKED_TOKEN_MANDATORY_POLICY', policy=mandatory_policy)
    if appcontainer or appcontainer_sid or capabilities:
        _blocked('BLOCKED_APPCONTAINER_CAPABILITY_TOKEN_UNSUPPORTED')
    if sandbox_inert or ui_access or virtual_enabled:
        _blocked('BLOCKED_TOKEN_SANDBOX_UIACCESS_OR_VIRTUALIZATION',
                 sandboxInert=sandbox_inert, uiAccess=ui_access, virtualizationEnabled=virtual_enabled)
    trust_level = _sid_field(handle, 41, allow_null=True)
    if trust_level:
        _blocked('BLOCKED_TOKEN_PROCESS_TRUST_LEVEL_UNSUPPORTED', processTrustLevel=trust_level)
    elevation, elevation_type = _dword_info(handle, 20), _dword_info(handle, 18)
    if elevation not in (0, 1) or elevation_type not in (1, 2, 3):
        _blocked('BLOCKED_TOKEN_ELEVATION_LAYOUT')
    has_restrictions, is_restricted = _dword_info(handle, 21), _dword_info(handle, 40)
    if has_restrictions not in (0, 1) or is_restricted not in (0, 1):
        _blocked('BLOCKED_TOKEN_RESTRICTION_LAYOUT')
    enabled_admin = any(group['sid'] == ADMIN_SID and group['enabled'] and not group['denyOnly']
                        for group in groups)
    restricted_context = bool(restricted or has_restrictions or is_restricted)
    trusted = None
    if not restricted_context and user['sid'] == SYSTEM_SID and integrity['rid'] >= 0x4000:
        trusted = 'LOCAL_SYSTEM'
    elif (not restricted_context and enabled_admin and elevation == 1 and
          integrity['rid'] >= 0x3000 and elevation_type != 3):
        trusted = 'ENABLED_ELEVATED_BUILTIN_ADMINISTRATORS'
    after = _statistics(handle)
    if before != after or before['groupCount'] != len(groups) or before['privilegeCount'] != len(privileges):
        _blocked('BLOCKED_TOKEN_CHANGED_DURING_INSPECTION')
    return {'actualToken': True, 'synthetic': None, 'operationalEvidence': False,
            'provenance': 'REAL_KERNEL_TOKEN_HANDLE_OPERATIONAL_ORIGIN_UNQUALIFIED',
            'user': user, 'groups': groups,
            'enabled': [group['sid'] for group in groups if group['enabled'] and not group['denyOnly']],
            'denyOnly': [group['sid'] for group in groups if group['denyOnly']],
            'restricted': restricted, 'hasRestrictions': bool(has_restrictions),
            'isRestricted': bool(is_restricted), 'restrictedIntersection': 'WINDOWS_ACCESSCHECK_NATIVE_TOKEN',
            'owner': owner, 'primaryGroup': primary_group, 'integrity': integrity,
            'privileges': privileges, 'claims': claims, 'deviceGroups': device_groups,
            'restrictedDeviceGroups': restricted_device_groups, 'capabilities': capabilities,
            'appContainer': bool(appcontainer), 'appContainerSid': appcontainer_sid,
            'processTrustLevel': trust_level, 'mandatoryPolicy': mandatory_policy,
            'virtualizationAllowed': bool(virtual_allowed), 'virtualizationEnabled': bool(virtual_enabled),
            'uiAccess': bool(ui_access), 'sandboxInert': bool(sandbox_inert),
            'elevated': bool(elevation), 'elevationType': elevation_type,
            'trustedPrincipal': trusted, 'tokenType': token_type,
            'impersonationLevel': impersonation, 'sessionId': _dword_info(handle, 12),
            'statistics': after, 'originAuthenticationId': _luid(_fixed_info(handle, 17, Luid))}


class NativeToken:
    """One retained actual token and a non-elevating impersonation duplicate.

    No fallback acquisition or duplicate retry. The source handle must already
    permit this supported operation; failure remains BLOCKED. No SID-list or
    actualToken/synthetic/provenance caller flag is accepted as an alternative.
    """
    def __init__(self):
        _blocked('BLOCKED_USE_NATIVE_TOKEN_FROM_HANDLE')

    @classmethod
    def from_handle(cls, handle):
        source_value = _handle_value(handle)
        result = object.__new__(cls)
        result.source, result.handle = HANDLE(), HANDLE()
        try:
            process = api.GetCurrentProcess()
            if not DuplicateHandle(process, source_value, process, C.byref(result.source), 0, False, 2):
                _native_failure('BLOCKED_RETAIN_ACTUAL_TOKEN_HANDLE')
            result.source_snapshot = _snapshot_token(result.source)
            if not DuplicateTokenEx(result.source, TOKEN_QUERY, None, SECURITY_IMPERSONATION,
                                    TOKEN_IMPERSONATION, C.byref(result.handle)):
                _native_failure('BLOCKED_ACTUAL_TOKEN_IMPERSONATION_DUPLICATE')
            result.snapshot = _snapshot_token(result.handle)
            for field in ('user', 'groups', 'restricted', 'owner', 'primaryGroup', 'integrity',
                          'privileges', 'claims', 'mandatoryPolicy', 'trustedPrincipal',
                          'hasRestrictions', 'isRestricted', 'deviceGroups', 'restrictedDeviceGroups',
                          'capabilities', 'appContainer', 'appContainerSid', 'processTrustLevel',
                          'virtualizationAllowed', 'virtualizationEnabled', 'uiAccess',
                          'sandboxInert', 'elevated', 'elevationType'):
                if result.source_snapshot[field] != result.snapshot[field]:
                    _blocked('BLOCKED_TOKEN_DUPLICATE_CONTEXT_DIFFERENCE', field=field)
            if result.snapshot['statistics']['authenticationId'] != result.source_snapshot['statistics']['authenticationId']:
                _blocked('BLOCKED_TOKEN_DUPLICATE_AUTHENTICATION_DIFFERENCE')
            result.source_fingerprint = _fingerprint(result.source_snapshot)
            result.fingerprint = _fingerprint(result.snapshot)
            return result
        except BaseException:
            result.close()
            raise

    def verify(self):
        if not self.source or not self.handle:
            _blocked('BLOCKED_TOKEN_HANDLE_CLOSED')
        source_now, evaluation_now = _snapshot_token(self.source), _snapshot_token(self.handle)
        if _fingerprint(source_now) != self.source_fingerprint or _fingerprint(evaluation_now) != self.fingerprint:
            _blocked('BLOCKED_TOKEN_CONTINUITY')
        return evaluation_now

    def close(self):
        for field in ('handle', 'source'):
            handle = getattr(self, field, None)
            if handle:
                api.cleanup_close(handle, 'NativeToken.close.'+field)
                setattr(self, field, HANDLE())

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def inspect_token(token):
    """Inspect actual supplied token; errors raise Blocked, never a partial PASS."""
    if isinstance(token, NativeToken):
        return token.verify()
    with NativeToken.from_handle(token) as retained:
        return retained.verify()


def _map_file_mask(mask):
    mapping = GenericMapping(0x120089, 0x120116, 0x1200A0, 0x1F01FF)
    value = DWORD(mask)
    api.MapGeneric(C.byref(value), C.byref(mapping))
    return int(value.value)


def _acl_records(sd, buffer, sacl=False):
    present, defaulted, acl = W.BOOL(), W.BOOL(), PTR()
    getter = GetSecurityDescriptorSacl if sacl else api.GetDacl
    if not getter(sd, C.byref(present), C.byref(acl), C.byref(defaulted)):
        _native_failure('BLOCKED_DESCRIPTOR_ACL_READ')
    result = {'present': bool(present.value), 'defaulted': bool(defaulted.value),
              'null': not bool(acl), 'aces': [], 'unsupported': []}
    if not present.value or not acl:
        if not sacl:
            result['unsupported'].append('BLOCKED_ABSENT_OR_NULL_DACL')
        return result
    base = _require_range(buffer, acl, 8, 'ACL header')
    header = C.string_at(base, 8)
    revision = header[0]
    length = int.from_bytes(header[2:4], 'little')
    count = int.from_bytes(header[4:6], 'little')
    if revision not in (2, 4) or header[1] or header[6:8] != b'\x00\x00':
        _blocked('BLOCKED_ACL_REVISION_OR_RESERVED')
    if length < 8 or count > MAX_ENTRIES:
        _blocked('BLOCKED_ACL_BOUND')
    _require_range(buffer, base, length, 'ACL body')
    result.update(revision=revision, bytes=length, aceCount=count)
    cursor = base + 8
    for index in range(count):
        pointer = PTR()
        if not api.GetAce(acl, index, C.byref(pointer)):
            _native_failure('BLOCKED_GET_ACE')
        address = _require_range(buffer, pointer, 4, 'ACE header')
        ace_header = C.string_at(address, 4)
        kind, flags = ace_header[0], ace_header[1]
        ace_bytes = int.from_bytes(ace_header[2:4], 'little')
        if address != cursor or ace_bytes < 4 or ace_bytes % 4 or address + ace_bytes > base + length:
            _blocked('BLOCKED_ACE_BOUND_OR_LAYOUT')
        raw = C.string_at(address, ace_bytes)
        record = {'index': index, 'type': kind, 'flags': flags, 'bytes': ace_bytes,
                  'inherited': bool(flags & 0x10), 'inheritOnly': bool(flags & 8),
                  'objectInherit': bool(flags & 1), 'containerInherit': bool(flags & 2),
                  'noPropagate': bool(flags & 4), 'rawHex': raw.hex()}
        supported_layout = kind == 0x11 if sacl else kind in (0, 1)
        if not supported_layout:
            # Object, callback/conditional, resource-attribute, central policy,
            # process-trust and access-filter layouts are retained, never skipped.
            record['unsupported'] = 'BLOCKED_UNSUPPORTED_AUTHORIZATION_ACE_TYPE_%02X' % kind
            result['unsupported'].append(record['unsupported'])
        elif ace_bytes < 16 or flags & ~0x1F:
            record['unsupported'] = 'BLOCKED_ACE_FLAGS_OR_SIZE'
            result['unsupported'].append(record['unsupported'])
        else:
            mask = int.from_bytes(raw[4:8], 'little')
            principal = _sid_record(address + 8, buffer, allow_unresolved=True)
            if ace_bytes != 8 + principal['sidBytes']:
                _blocked('BLOCKED_TRAILING_ACE_APPLICATION_DATA')
            record.update(mask=mask, mappedMask=_map_file_mask(mask) if not sacl else mask,
                          principal=principal, sid=principal['sid'],
                          kind='MANDATORY_LABEL' if sacl else 'ALLOW' if kind == 0 else 'DENY')
            if not principal['resolved']:
                record['unsupported'] = 'BLOCKED_PRINCIPAL_UNRESOLVED'
                result['unsupported'].append(record['unsupported'])
            if principal['sid'] in OWNER_SPECIAL_SIDS:
                record['unsupported'] = 'BLOCKED_CREATOR_OR_OWNER_RIGHTS_SEMANTICS'
                result['unsupported'].append(record['unsupported'])
            if sacl and (not re.fullmatch(r'S-1-16-\d+', principal['sid']) or mask & ~7):
                record['unsupported'] = 'BLOCKED_MANDATORY_LABEL_LAYOUT_OR_POLICY'
                result['unsupported'].append(record['unsupported'])
            if not sacl and record['mappedMask'] & ~0x1F01FF:
                record['unsupported'] = 'BLOCKED_FILE_ACE_UNKNOWN_ACCESS_BITS'
                result['unsupported'].append(record['unsupported'])
        result['aces'].append(record)
        cursor = address + ace_bytes
    # Free ACL capacity is valid, but nonzero unparsed data is not part of this
    # narrow supported subset. It cannot conceal a second authorization layout.
    if cursor > base + length or any(C.string_at(cursor, base + length - cursor)):
        _blocked('BLOCKED_ACL_UNPARSED_TRAILING_BYTES')
    return result


def _decode_descriptor(raw):
    if not isinstance(raw, bytes) or not 20 <= len(raw) <= MAX_NATIVE_BYTES:
        _blocked('BLOCKED_DESCRIPTOR_BYTE_BOUND')
    buffer = C.create_string_buffer(raw, len(raw))
    if not IsValidSecurityDescriptor(buffer):
        _native_failure('BLOCKED_INVALID_SECURITY_DESCRIPTOR')
    flags, revision = C.c_ushort(), DWORD()
    if not api.SDControl(buffer, C.byref(flags), C.byref(revision)):
        _native_failure('BLOCKED_DESCRIPTOR_CONTROL')
    # Self-relative only. Server-security/untrusted-DACL and resource-manager
    # control semantics are not silently normalized away.
    unsupported = []
    if revision.value != 1 or not flags.value & 0x8000:
        unsupported.append('BLOCKED_DESCRIPTOR_REVISION_OR_NON_SELF_RELATIVE')
    if flags.value & (0x0040 | 0x0080 | 0x4000):
        unsupported.append('BLOCKED_DESCRIPTOR_SERVER_OR_RESOURCE_MANAGER_CONTROL')
    if raw[1]:
        unsupported.append('BLOCKED_DESCRIPTOR_RESOURCE_MANAGER_BYTE')
    owner, group, owner_defaulted, group_defaulted = PTR(), PTR(), W.BOOL(), W.BOOL()
    if not GetSecurityDescriptorOwner(buffer, C.byref(owner), C.byref(owner_defaulted)):
        _native_failure('BLOCKED_DESCRIPTOR_OWNER_READ')
    if not GetSecurityDescriptorGroup(buffer, C.byref(group), C.byref(group_defaulted)):
        _native_failure('BLOCKED_DESCRIPTOR_GROUP_READ')
    if not owner or not group:
        _blocked('BLOCKED_DESCRIPTOR_OWNER_OR_GROUP_ABSENT')
    owner_record = _sid_record(owner, buffer, allow_unresolved=True)
    group_record = _sid_record(group, buffer, allow_unresolved=True)
    if not owner_record['resolved'] or not group_record['resolved']:
        unsupported.append('BLOCKED_DESCRIPTOR_OWNER_OR_GROUP_UNRESOLVED')
    if owner_record['sid'] in OWNER_SPECIAL_SIDS or group_record['sid'] in OWNER_SPECIAL_SIDS:
        unsupported.append('BLOCKED_DESCRIPTOR_CREATOR_OR_OWNER_SPECIAL_SID')
    dacl, sacl = _acl_records(buffer, buffer), _acl_records(buffer, buffer, sacl=True)
    unsupported.extend(dacl['unsupported'])
    unsupported.extend(sacl['unsupported'])
    labels = [ace for ace in sacl['aces'] if ace.get('kind') == 'MANDATORY_LABEL']
    if len(labels) > 1 or any(ace['inheritOnly'] for ace in labels):
        unsupported.append('BLOCKED_MULTIPLE_OR_INHERIT_ONLY_MANDATORY_LABELS')
    if labels and 'sid' in labels[0] and re.fullmatch(r'S-1-16-\d+', labels[0]['sid']):
        integrity = {'sid': labels[0]['sid'], 'rid': int(labels[0]['sid'].rsplit('-', 1)[1]),
                     'policy': labels[0]['mask'], 'source': 'HELD_EXPLICIT_MANDATORY_LABEL'}
    elif not labels:
        # Windows treats an object with no label as medium integrity. This is
        # used only after all authorization-relevant SACL classes were queried.
        integrity = {'sid': 'S-1-16-8192', 'rid': 8192, 'policy': 1,
                     'source': 'WINDOWS_IMPLICIT_MEDIUM_NO_EXPLICIT_LABEL'}
    else:
        integrity = None
        unsupported.append('BLOCKED_INTEGRITY_LABEL_UNRESOLVED')
    return {'ownerSid': owner_record['sid'], 'owner': owner_record,
            'ownerDefaulted': bool(owner_defaulted.value), 'group': group_record,
            'groupDefaulted': bool(group_defaulted.value), 'controlFlags': int(flags.value),
            'daclProtected': bool(flags.value & 0x1000), 'saclProtected': bool(flags.value & 0x2000),
            'daclAutoInherited': bool(flags.value & 0x0400), 'saclAutoInherited': bool(flags.value & 0x0800),
            'dacl': dacl, 'sacl': sacl, 'integrity': integrity,
            'rawHex': raw.hex(), 'sha256': hashlib.sha256(raw).hexdigest(),
            'securityInformation': AUTHORIZATION_SECURITY_INFORMATION,
            'auditSaclRead': False, 'allAuthorizationRelevantSaclClassesRequested': True,
            'unsupported': sorted(set(unsupported)),
            'arbitraryPrincipalMembershipClosure': 'NOT_ESTABLISHED_BY_REPRESENTATIVE_TOKENS',
            'ownerAuthority': 'NATIVE_ACCESSCHECK_FOR_ACTUAL_TOKEN; GLOBAL_OWNER_POLICY_REQUIRED'}


def _capture_authorization_descriptor(held):
    owner, group, dacl, sacl, sd = PTR(), PTR(), PTR(), PTR(), PTR()
    error = api.SecurityInfo(held.h, 1, AUTHORIZATION_SECURITY_INFORMATION,
                             C.byref(owner), C.byref(group), C.byref(dacl),
                             C.byref(sacl), C.byref(sd))
    if error:
        raise Blocked('BLOCKED_COMPLETE_AUTHORIZATION_DESCRIPTOR_UNAVAILABLE', error,
                      {'securityInformation': AUTHORIZATION_SECURITY_INFORMATION})
    try:
        size = api.SDLength(sd)
        if not 20 <= size <= MAX_NATIVE_BYTES:
            _blocked('BLOCKED_AUTHORIZATION_DESCRIPTOR_SIZE', bytes=size)
        return _decode_descriptor(C.string_at(sd, size))
    finally:
        if sd:
            api.LocalFree(sd)


def inspect_descriptor(held):
    """Enumerate full supported authorization projection from the SAME handle.

    Original 0x17 Held.security fields remain available as originalDescriptor.
    The broader 0x1F7 read includes dynamic-access/resource/trust/filter classes;
    audit-only SACL data is irrelevant to grants and is not privilege-enabled.
    Unsupported ACEs remain visible and force blocked individual decisions.
    """
    if not isinstance(held, api.Held) or not getattr(held, 'h', None):
        _blocked('BLOCKED_HELD_NATIVE_OBJECT_REQUIRED')
    identity_before = held.verify()
    original_before = held.security()
    descriptor = _capture_authorization_descriptor(held)
    after = _capture_authorization_descriptor(held)
    identity_after = held.verify()
    if (descriptor['sha256'] != after['sha256'] or identity_before != identity_after or
            original_before['sha256'] != held.security()['sha256']):
        _blocked('BLOCKED_DESCRIPTOR_OR_HELD_IDENTITY_CONTINUITY')
    if descriptor['ownerSid'] != original_before['ownerSid']:
        _blocked('BLOCKED_DESCRIPTOR_PROJECTION_OWNER_DIFFERENCE')
    descriptor.update(path=held.path, identity=identity_after,
                      originalDescriptor=original_before,
                      originalHeldDescriptor=held.descriptor,
                      continuity='SAME_HELD_HANDLE_DOUBLE_AUTHORIZATION_READ_AND_HELD_VERIFY')
    return descriptor


def _native_access_check(raw, token, requested):
    # Work on a private copy: map generic bits in common allow/deny ACEs while
    # preserving the original descriptor bytes and hash in the evidence.
    buffer = C.create_string_buffer(raw, len(raw))
    present, defaulted, dacl = W.BOOL(), W.BOOL(), PTR()
    if not api.GetDacl(buffer, C.byref(present), C.byref(dacl), C.byref(defaulted)):
        _native_failure('BLOCKED_ACCESSCHECK_GET_DACL')
    if not present.value or not dacl:
        _blocked('BLOCKED_ACCESSCHECK_NULL_DACL')
    acl_address = _require_range(buffer, dacl, 8, 'AccessCheck DACL')
    count = int.from_bytes(C.string_at(acl_address + 4, 2), 'little')
    mapping = GenericMapping(0x120089, 0x120116, 0x1200A0, 0x1F01FF)
    for index in range(count):
        pointer = PTR()
        if not api.GetAce(dacl, index, C.byref(pointer)):
            _native_failure('BLOCKED_ACCESSCHECK_GET_ACE')
        address = _require_range(buffer, pointer, 8, 'AccessCheck ACE')
        if C.string_at(address, 1)[0] not in (0, 1):
            _blocked('BLOCKED_ACCESSCHECK_UNSUPPORTED_ACE')
        mask = DWORD.from_address(address + 4)
        api.MapGeneric(C.byref(mask), C.byref(mapping))
    # A single bounded call; no token/privilege or AccessCheck retry on failure.
    privilege_buffer = C.create_string_buffer(65536)
    privilege_bytes = DWORD(len(privilege_buffer))
    granted, access_status = DWORD(), W.BOOL()
    if not AccessCheck(buffer, token.handle, requested, C.byref(mapping), privilege_buffer,
                       C.byref(privilege_bytes), C.byref(granted), C.byref(access_status)):
        _native_failure('BLOCKED_WINDOWS_ACCESSCHECK_FAILED')
    if not 8 <= privilege_bytes.value <= len(privilege_buffer):
        _blocked('BLOCKED_ACCESSCHECK_PRIVILEGESET_SIZE')
    count = int.from_bytes(privilege_buffer.raw[:4], 'little')
    control = int.from_bytes(privilege_buffer.raw[4:8], 'little')
    entry_size = C.sizeof(LuidAndAttributes)
    if count > MAX_ENTRIES or 8 + count * entry_size > privilege_bytes.value:
        _blocked('BLOCKED_ACCESSCHECK_PRIVILEGESET_BOUND')
    used_privileges = []
    for index in range(count):
        entry = LuidAndAttributes.from_buffer_copy(privilege_buffer.raw[8 + index * entry_size:
                                                                       8 + (index + 1) * entry_size])
        used_privileges.append(_privilege_record(entry.luid, entry.attributes))
    # On a denied access check, granted is retained as diagnostic data and is
    # never treated as a partial permit or a successful right.
    allowed = bool(access_status.value) and granted.value & requested == requested
    if bool(access_status.value) and not allowed:
        _blocked('BLOCKED_ACCESSCHECK_SUCCESS_MASK_INCONSISTENT')
    return {'engine': 'Windows AccessCheck', 'requested': requested,
            'granted': int(granted.value), 'accessStatus': bool(access_status.value),
            'win32Error': 0 if allowed else ERROR_ACCESS_DENIED,
            'outcome': 'ALLOWED' if allowed else 'DENIED',
            'privilegesUsed': used_privileges, 'privilegeSetControl': control,
            'actual': True, 'actualToken': True, 'synthetic': None,
            'operationalEvidence': False, 'scope': 'NATIVE_ACTUAL_TOKEN_STANDARD_FILE_DACL',
            'genericMapping': {'read': mapping.read, 'write': mapping.write,
                               'execute': mapping.execute, 'all': mapping.all},
            'mappedDescriptorSha256': hashlib.sha256(buffer.raw).hexdigest()}


def inspect_access(held, token_handle, desired, *, object_type='file', role=None):
    """Check one concrete right; all unresolved conditions fail closed.

    qualified means only that this individual held-object/token observation is
    within the supported subset. It never means a path, service, token corpus,
    bootstrap, installed root, creation operation, SCM binding, or Setup passed.
    Caller role is a diagnostic label and cannot confer token trust.
    """
    result = {'requested': desired, 'outcome': 'BLOCKED_UNKNOWN', 'qualified': False,
              'operationalEvidence': False, 'actualToken': False, 'synthetic': None,
              'actual': False, 'objectType': object_type, 'callerRoleLabel': role}
    owned = None
    try:
        if type(desired) is not int or desired not in FILE_RIGHTS:
            _blocked('BLOCKED_INDIVIDUAL_CONCRETE_FILE_RIGHT_REQUIRED')
        if object_type not in ('file', 'directory'):
            _blocked('BLOCKED_OBJECT_TYPE_UNSUPPORTED')
        native_token = token_handle if isinstance(token_handle, NativeToken) else NativeToken.from_handle(token_handle)
        if not isinstance(token_handle, NativeToken):
            owned = native_token
        context = native_token.verify()
        result.update(actualToken=True, token=context, tokenFingerprint=native_token.fingerprint,
                      sourceTokenFingerprint=native_token.source_fingerprint)
        descriptor = inspect_descriptor(held)
        result.update(path=held.path, identity=descriptor['identity'], descriptor=descriptor,
                      originalDescriptor=descriptor['originalDescriptor'])
        is_directory = bool(descriptor['identity']['attributes'] & 0x10)
        if is_directory != (object_type == 'directory'):
            _blocked('BLOCKED_HELD_OBJECT_TYPE_DIFFERENCE')
        if descriptor['unsupported']:
            _blocked('BLOCKED_UNSUPPORTED_DESCRIPTOR_SEMANTICS', reasons=descriptor['unsupported'])
        # A resolved owner can still confer implicit security-changing authority;
        # the native check models it for this actual token. The enclosing policy
        # must reject an owner outside its exact path-specific trusted boundary.
        if context['trustedPrincipal'] is None:
            enabled = [privilege for privilege in context['privileges'] if privilege['enabled']]
            unqualified = [privilege for privilege in enabled if privilege['name'] != 'SeChangeNotifyPrivilege']
            if unqualified:
                _blocked('BLOCKED_UNTRUSTED_ENABLED_PRIVILEGE_EFFECTS', privileges=unqualified)
        integrity = descriptor['integrity']
        if integrity is None:
            _blocked('BLOCKED_MANDATORY_INTEGRITY_UNRESOLVED')
        # AccessCheck's DACL result alone is not a mandatory integrity decision.
        # Same/downward IL cannot be denied by no-up policy. Upward cases remain
        # blocked rather than incorrectly extending the DACL result to MIC.
        if context['integrity']['rid'] < integrity['rid']:
            _blocked('BLOCKED_MIC_UPWARD_ACCESS_SEMANTICS_UNQUALIFIED',
                     tokenIntegrity=context['integrity'], objectIntegrity=integrity,
                     tokenMandatoryPolicy=context['mandatoryPolicy'])
        result['mandatoryIntegrity'] = {
            'outcome': 'NO_UPWARD_ACCESS', 'tokenRid': context['integrity']['rid'],
            'objectRid': integrity['rid'], 'objectPolicy': integrity['policy'],
            'tokenMandatoryPolicy': context['mandatoryPolicy'],
            'scope': 'SAME_OR_DOWNWARD_INTEGRITY_ONLY'}
        native = _native_access_check(bytes.fromhex(descriptor['rawHex']), native_token, desired)
        result['native'] = native
        # SeChangeNotifyPrivilege is the only enabled untrusted privilege whose
        # traversal effect is admitted here. No backup/restore, ownership,
        # relabel, impersonation or security-privilege bypass is synthesized.
        if context['trustedPrincipal'] is None and any(
                item['name'] != 'SeChangeNotifyPrivilege' for item in native['privilegesUsed']):
            _blocked('BLOCKED_ACCESSCHECK_UNQUALIFIED_PRIVILEGE_USE', privileges=native['privilegesUsed'])
        after = inspect_descriptor(held)
        native_token.verify()
        if descriptor['sha256'] != after['sha256'] or descriptor['identity'] != after['identity']:
            _blocked('BLOCKED_ACCESSCHECK_DESCRIPTOR_CONTINUITY')
        result.update(outcome=native['outcome'], qualified=True, actual=True,
                      granted=native['granted'], reason='SUPPORTED_NATIVE_TOKEN_DACL_OBSERVATION_ONLY',
                      nativeOutcome=native['outcome'], win32Error=native['win32Error'],
                      scope='INDIVIDUAL_RIGHT_NOT_CHAIN_OR_OPERATIONAL_APPROVAL')
        return result
    except Blocked as error:
        result.update(reason=error.reason, win32Error=error.win32, blockedDetails=error.details)
        return result
    except (ValueError, TypeError, OverflowError, OSError) as error:
        result.update(reason='BLOCKED_NATIVE_CHECK_INPUT_OR_OS_ERROR', errorType=type(error).__name__)
        return result
    finally:
        if owned is not None:
            owned.close()


def check_right(held, token_handle, desired, is_directory=False):
    """Compatibility spelling; no combined-mask or context-dictionary fallback."""
    if type(is_directory) is not bool:
        return {'requested': desired, 'outcome': 'BLOCKED_UNKNOWN', 'qualified': False,
                'operationalEvidence': False, 'reason': 'BLOCKED_EXPLICIT_OBJECT_TYPE_REQUIRED'}
    return inspect_access(held, token_handle, desired,
                          object_type='directory' if is_directory else 'file')


def resolve_service_sids():
    """Resolve only the three normative identities, with exact native roundtrip.

    This creates no service, account, token, permission or fallback identity.
    Lookup success alone is not evidence of an installed service or service SID
    type configuration. SCM presence/bindings and real tokens remain separate
    operational prerequisites. No caller-provided names or SID overrides exist.
    """
    names = {'postgres': 'MCVQ5Postgres1029', 'provider': 'MCVQ5Provider1029',
             'tunnel': 'MCVQ5Tunnel1029'}
    result = {}
    for role, service in names.items():
        account = 'NT SERVICE\\' + service
        sid_buffer = C.create_string_buffer(68)
        sid_bytes = DWORD(len(sid_buffer))
        domain = C.create_unicode_buffer(1024)
        domain_chars, use = DWORD(len(domain)), DWORD()
        # One bounded native call; denial, absent account or oversized result
        # blocks rather than triggering service creation, probing or retries.
        if not LookupAccountName(None, account, sid_buffer, C.byref(sid_bytes), domain,
                                 C.byref(domain_chars), C.byref(use)):
            raise Blocked('BLOCKED_REQUIRED_SERVICE_IDENTITY_UNAVAILABLE', C.get_last_error(),
                          {'service': service, 'account': account})
        if not 8 <= sid_bytes.value <= len(sid_buffer):
            _blocked('BLOCKED_SERVICE_SID_BYTE_BOUND', service=service)
        record = _sid_record(C.addressof(sid_buffer), sid_buffer)
        sid = record['sid']
        if (not re.fullmatch(r'S-1-5-80-\d+-\d+-\d+-\d+-\d+', sid) or
                record['domain'] != 'NT SERVICE' or record['name'] != service or
                domain.value != 'NT SERVICE' or record['sidType'] != use.value):
            _blocked('BLOCKED_REQUIRED_SERVICE_IDENTITY_ROUNDTRIP', account=account,
                     returnedDomain=domain.value, principal=record, sidUse=int(use.value))
        result[role] = {'name': account, 'serviceName': service, 'sid': sid,
                        'roundTrip': record, 'engine': 'Windows LookupAccountNameW/LookupAccountSidW',
                        'installedServiceEvidence': False, 'actualServiceTokenEvidence': False,
                        'operationalEvidence': False,
                        'scope': 'IDENTITY_RESOLUTION_ONLY_NOT_SCM_OR_TOKEN_QUALIFICATION'}
    if len({entry['sid'] for entry in result.values()}) != len(names):
        _blocked('BLOCKED_REQUIRED_SERVICE_SID_COLLISION')
    return result
