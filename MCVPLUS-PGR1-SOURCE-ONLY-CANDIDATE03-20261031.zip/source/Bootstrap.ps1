[CmdletBinding()]
param(
 [Parameter(Mandatory)][ValidateSet('LocalValidation','ProtectedStage','Apply','Setup')][string]$Mode,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedSourceManifestSha256,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedBootstrapSha256,
 [Parameter(Mandatory)][string]$PythonExecutable,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedPythonSha256,
 [Parameter(Mandatory)][string]$NativeHelperAssembly,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedNativeHelperAssemblySha256,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedNativeHelperSourceSha256,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedInspectorSha256
)
if ($Mode -ne 'LocalValidation') {throw 'UNCONDITIONAL_OPERATIONAL_ADMISSION_BLOCK'}
# Delivery is source authoring only. No parameter, environment variable or manifest
# can authorize this revision. Future local verification requires a separately
# authorized, reviewed source revision and new frozen pins, including the DLL.
throw 'SOURCE-ONLY-NOT-AUTHORIZED'
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$clock=[Diagnostics.Stopwatch]::StartNew()
$root='D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate03'
$source=$root+'\source'
$jobName='PG-R1-mcvplus-pgr1-source-only-20261031-candidate03-runner'
if ($PSCommandPath -cne ($source+'\Bootstrap.ps1')) {throw 'EXACT_LOCAL_NAMESPACE_REQUIRED'}
$locks=New-Object 'Collections.Generic.List[IDisposable]'
$runner=$null;$inspector=$null;$result=$null;$primary=$null
$cleanupErrors=New-Object 'Collections.Generic.List[string]'
try {
 function Read-C5PinnedStream([string]$Path,[string]$ExpectedHash,[bool]$ReadBytes=$false) {
  # One retained stream for hash and parse/load bytes; deny write/delete sharing.
  $s=[IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read);$locks.Add($s)
  $sha=[Security.Cryptography.SHA256]::Create()
  try {$hash=[BitConverter]::ToString($sha.ComputeHash($s)).Replace('-','').ToLowerInvariant()} finally {$sha.Dispose()}
  if ($hash -cne $ExpectedHash) {throw ('EXTERNAL_OR_SOURCE_PIN_MISMATCH: '+$Path)}
  $bytes=$null
  if ($ReadBytes) {
   $s.Position=0;$memory=New-Object IO.MemoryStream
   try {$s.CopyTo($memory);$bytes=$memory.ToArray()} finally {$memory.Dispose()}
  }
  return @{stream=$s;bytes=$bytes;hash=$hash;length=$s.Length}
 }
 function Assert-AbsoluteImagePath([string]$Path) {
  if ($Path -cnotmatch '^[A-Z]:\\' -or $Path -match '["\r\n]' -or [IO.Path]::GetFullPath($Path) -cne $Path) {throw 'EXACT_LOCAL_EXECUTABLE_PATH_REQUIRED'}
 }
 $bootstrapHeld=Read-C5PinnedStream $PSCommandPath $ExpectedBootstrapSha256
 Assert-AbsoluteImagePath $PythonExecutable
 Assert-AbsoluteImagePath $NativeHelperAssembly
 $interpreterHeld=Read-C5PinnedStream $PythonExecutable $ExpectedPythonSha256
 # Root manifest is canonical. source/SOURCE-MANIFEST.json remains historical
 # and is bound as a normal source file, never used as this revision's admission.
 $manifestHeld=Read-C5PinnedStream ($root+'\SOURCE-MANIFEST.json') $ExpectedSourceManifestSha256 $true
 $manifest=[Text.Encoding]::UTF8.GetString($manifestHeld.bytes)|ConvertFrom-Json
 if ($manifest.schema -ne 2 -or $manifest.status -cne 'UNTESTED' -or $manifest.executionAuthorized -ne $false -or $manifest.namespace -cne $root -or $manifest.sourceDirectory -cne $source) {throw 'SOURCE_IDENTITY'}
 $expected=@{};$dirs=@{};$pins=@{}
 foreach ($pin in $manifest.files) {
  $rel=[string]$pin.path
  if (!$rel -or $rel -cnotmatch '^source/' -or $rel -match '[^A-Za-z0-9_./-]|(^|/)\.{1,2}(/|$)|^/|//|[. ](/|$)|(^|/)(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])([./]|$)' -or $expected.ContainsKey($rel)) {throw 'SOURCE_PATH_OR_COLLISION'}
  $expected[$rel]=$true;$pins[$rel]=$pin;$d=Split-Path -Parent $rel
  while ($d) {$dirs[$d.Replace('\','/')]=$true;$d=Split-Path -Parent $d}
 }
 foreach ($required in @('source/Bootstrap.ps1','source/run.py','source/windows_api.py','source/gate.py','source/permission_check.py','source/path_policy.py','source/DELIVERY-POLICY.json','source/FIXTURE-MATRIX.json','source/policy/PATH-SPECIFIC-GATE-REVISION.md','source/policy/BOUNDED-LOCAL-VALIDATION-PLAN.md','source/policy/STATE-ROOT-BINDINGS.md','source/policy/LOCAL-POLICY.json','source/native/ContainedLaunch.cs','source/auxiliary/inspect_owned_job.py')) {
  if (!$pins.ContainsKey($required)) {throw ('REQUIRED_SOURCE_MISSING: '+$required)}
 }
 if ($pins['source/Bootstrap.ps1'].sha256 -cne $ExpectedBootstrapSha256) {throw 'BOOTSTRAP_MANIFEST_BINDING'}
 if ($pins['source/native/ContainedLaunch.cs'].sha256 -cne $ExpectedNativeHelperSourceSha256) {throw 'NATIVE_HELPER_SOURCE_EXTERNAL_PIN_MISMATCH'}
 if ($pins['source/auxiliary/inspect_owned_job.py'].sha256 -cne $ExpectedInspectorSha256) {throw 'INSPECTOR_EXTERNAL_PIN_MISMATCH'}
 $queue=New-Object 'Collections.Generic.Queue[string]';$queue.Enqueue($source)
 while ($queue.Count) {
  $dir=$queue.Dequeue()
  if ((Get-Item -LiteralPath $dir -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'SOURCE_REPARSE'}
  foreach ($i in Get-ChildItem -LiteralPath $dir -Force) {
   if ($i.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'SOURCE_REPARSE'}
   $rel=$i.FullName.Substring($root.Length+1).Replace('\','/')
   if ($i.PSIsContainer) {if (!$dirs.ContainsKey($rel)) {throw 'EXTRA_SOURCE_DIRECTORY'};$queue.Enqueue($i.FullName)}
   elseif (!$expected.ContainsKey($rel)) {throw 'EXTRA_SOURCE_FILE'}
  }
 }
 foreach ($pin in $manifest.files) {
  if ($pin.sha256 -cnotmatch '^[a-f0-9]{64}$' -or $pin.bytes -lt 0) {throw 'INVALID_PIN'}
  $heldSource=Read-C5PinnedStream ($root+'\'+$pin.path.Replace('/','\')) $pin.sha256
  if ($heldSource.length -ne $pin.bytes) {throw 'SOURCE_SIZE_DRIFT'}
 }
 $deliveryHeld=Read-C5PinnedStream ($source+'\DELIVERY-POLICY.json') $pins['source/DELIVERY-POLICY.json'].sha256 $true
 $delivery=[Text.Encoding]::UTF8.GetString($deliveryHeld.bytes)|ConvertFrom-Json
 if ($delivery.schema -ne 2 -or $delivery.status -cne 'UNTESTED' -or $delivery.sourceOnly -ne $true -or $delivery.executionAuthorized -ne $false -or $delivery.nativeLaunchEnabled -ne $false -or $delivery.compilationEnabled -ne $false -or $delivery.helperLoadEnabled -ne $false -or $delivery.fixtureCreationEnabled -ne $false -or $delivery.namespace -cne $root -or $delivery.sourceDirectory -cne $source) {throw 'DELIVERY_POLICY_IDENTITY_OR_DISABLED_STATE'}
 # Independent helper binary pin is required in addition to its source pin.
 # This delivery has no DLL and performs no compilation or build invocation.
 # Future source-to-binary provenance and protected loader admission are blockers.
 $helperHeld=Read-C5PinnedStream $NativeHelperAssembly $ExpectedNativeHelperAssemblySha256 $true
 $inspectorHeld=Read-C5PinnedStream ($source+'\auxiliary\inspect_owned_job.py') $ExpectedInspectorSha256
 $policyHeld=Read-C5PinnedStream ($source+'\policy\LOCAL-POLICY.json') $pins['source/policy/LOCAL-POLICY.json'].sha256 $true
 $localPolicy=[Text.Encoding]::UTF8.GetString($policyHeld.bytes)|ConvertFrom-Json
 if ($localPolicy.nativeLaunchEnabled -ne $true -or $localPolicy.compilationEnabled -ne $false -or $localPolicy.bounds.nativeChildSeconds -ne 30) {throw 'BLOCKED_LOCAL_POLICY_ADMISSION'}
 foreach ($name in @('runner-evidence','fixtures')) {if (Test-Path -LiteralPath ($root+'\'+$name)) {throw 'OUTPUT_NAMESPACE_COLLISION_NO_RETRY'}}
 if ($clock.Elapsed.TotalSeconds -ge 835) {throw 'TOTAL_BOUND_STOP_BEFORE_NATIVE_LAUNCH'}
 # Load only retained independently pinned assembly bytes; never Add-Type.
 # The helper itself also has an unconditional source-only guard.
 $assembly=[Reflection.Assembly]::Load([byte[]]$helperHeld.bytes)
 $launcherType=$assembly.GetType('McvPlus.PgR1.ContainedLauncher',$true)
 $runMethod=$launcherType.GetMethod('Run')
 $deadline=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()/1000.0 + 28
 [string[]]$runnerArgs=@('-I','-B','-X','utf8',($source+'\run.py'),'--mode=LocalValidation',('--manifest='+$ExpectedSourceManifestSha256),('--bootstrap='+$ExpectedBootstrapSha256),('--deadline='+$deadline.ToString('R',[Globalization.CultureInfo]::InvariantCulture)),('--parent-job='+$jobName))
 [object[]]$invokeArgs=New-Object object[] 5
 $invokeArgs[0]=$PythonExecutable;$invokeArgs[1]=$runnerArgs;$invokeArgs[2]=$source;$invokeArgs[3]=$ExpectedPythonSha256;$invokeArgs[4]=$jobName
 $runner=$runMethod.Invoke($null,$invokeArgs)
 $main=$runner.Evidence
 $aux=$null
 if ($main.Status -ceq 'LOCAL_CHILD_EXITED_NOT_QUALIFICATION' -and $main.JobEmptyAfterExit) {
  # Runner job handle remains held by $runner. Inspector has its OWN job,
  # also assigned while suspended, so active-process-limit=1 is not relaxed.
  if ($clock.Elapsed.TotalSeconds -ge 865) {throw 'TOTAL_BOUND_STOP_BEFORE_AUXILIARY_LAUNCH'}
  [string[]]$auxArgs=@('-I','-B','-X','utf8',($source+'\auxiliary\inspect_owned_job.py'),('--job='+$jobName),('--expected-pid='+$main.ProcessId),('--expected-start-filetime='+$main.ProcessStartFileTimeUtc))
  [object[]]$auxInvokeArgs=New-Object object[] 5
  $auxInvokeArgs[0]=$PythonExecutable;$auxInvokeArgs[1]=$auxArgs;$auxInvokeArgs[2]=$source;$auxInvokeArgs[3]=$ExpectedPythonSha256;$auxInvokeArgs[4]=$jobName+'-inspector'
  $inspector=$runMethod.Invoke($null,$auxInvokeArgs)
  $aux=$inspector.Evidence
  if ($aux.Status -ceq 'LOCAL_CHILD_EXITED_NOT_QUALIFICATION') {
   try {
    $readback=$aux.StandardOutput|ConvertFrom-Json
    if ($readback.status -cne 'EMPTY_JOB_AND_ORIGINAL_PROCESS_NOT_RUNNING' -or $readback.job -cne $jobName -or $readback.expectedPid -ne $main.ProcessId -or [string]$readback.expectedStartFileTimeUtc -cne [string]$main.ProcessStartFileTimeUtc) {throw 'INSPECTOR_EXACT_BINDING_OR_RESULT'}
   } catch {$aux.Status='BLOCKED_INSPECTOR_RESULT';$aux.Failure=$_.Exception.Message}
  }
 }
 # Serialize only after owned handle closure, so close failures remain visible.
 $status=if($main.Status -cne 'LOCAL_CHILD_EXITED_NOT_QUALIFICATION'){'BLOCKED_MAIN_CONTAINMENT'}elseif($null -eq $aux -or $aux.Status -cne 'LOCAL_CHILD_EXITED_NOT_QUALIFICATION'){'BLOCKED_AUXILIARY_CONTAINMENT'}else{'LOCAL_EVIDENCE_ONLY_NOT_OPERATIONAL_QUALIFICATION'}
 $result=[pscustomobject]@{schema=2;status=$status;runner=$main;inspector=$aux;sourceManifestSha256=$ExpectedSourceManifestSha256;bootstrapSha256=$ExpectedBootstrapSha256;helperSourceSha256=$ExpectedNativeHelperSourceSha256;helperAssemblySha256=$ExpectedNativeHelperAssemblySha256;inspectorSourceSha256=$ExpectedInspectorSha256;allAuxiliaryPinsAdmittedBeforeMainLaunch=$true;elapsedSeconds=$clock.Elapsed.TotalSeconds;retryCount=0;historicalF02F04='NOT_RETROACTIVELY_CLOSED';operationalDecision='BLOCKED'}
 } catch {
 $primary=@{type=$_.Exception.GetType().FullName;message=$_.Exception.Message;stage='BOOTSTRAP_PREFLIGHT_OR_LAUNCH'}
} finally {
 foreach ($session in @($inspector,$runner)) {
  if ($null -ne $session) {
   try {$session.Dispose()} catch {if($cleanupErrors.Count -lt 128){$cleanupErrors.Add($_.Exception.Message)}}
   foreach($failure in $session.Evidence.CleanupFailures) {if($cleanupErrors.Count -lt 128){$cleanupErrors.Add([string]$failure)}}
  }
 }
 foreach ($lock in $locks) {try {$lock.Dispose()} catch {if($cleanupErrors.Count -lt 128){$cleanupErrors.Add($_.Exception.Message)}}}
}
[pscustomobject]@{schema=3;status='BLOCKED_UNTESTED';primaryError=$primary;secondaryCleanupErrors=@($cleanupErrors);result=$result;runner=if($runner){$runner.Evidence}else{$null};inspector=if($inspector){$inspector.Evidence}else{$null};caseEntry='NO_CASES_INVENTED_BY_PARENT';operationalReadbacks='UNQUALIFIED';retryCount=0}|ConvertTo-Json -Depth 32
