Candidate02 precedence: F05-F06-SOURCE-NOTES.md supersedes inherited sequencing/envelope descriptions below. In particular, preparation occurs only after semantic stop admission; parent durable adapter is authored but supervisor/toolchain guarantees remain blocked.

# F02 and F04 authored source: UNTESTED, source only

This document describes authored mechanisms, not observed behavior or independent review. No candidate, inspector, launcher or helper was executed, imported, compiled, parsed through a compiler/AST, or exercised with fixtures/tests. There is no delivered helper DLL. No historical evidence, result or receipt is replaced. Historical F02/F04 remain unqualified. All 48 hosted attempts remain unspent. Operational admission remains unconditionally blocked.

## Exact source and admission symbols

| Requirement | Source symbol or block | Authored behavior |
| --- | --- | --- |
| Delivery block | `Bootstrap.ps1` initial unconditional `SOURCE-ONLY-NOT-AUTHORIZED`; `ContainedLauncher.RequireFutureAuthorization`; `inspect_owned_job.py` initial raise | No option, manifest flag or environment variable enables this revision. Nonlocal Bootstrap mode separately throws `UNCONDITIONAL_OPERATIONAL_ADMISSION_BLOCK`. |
| Canonical admission | Bootstrap `Read-C5PinnedStream`, root manifest inventory loop | Root `SOURCE-MANIFEST.json`, schema 2, full candidate-relative `source/...` pins. Historical `source/SOURCE-MANIFEST.json` is a listed ordinary file. Retained read streams deny write/delete sharing. Exact source subtree closure rejects extras, absent files, path collisions and reparse entries. |
| Independent auxiliary admission before main | Bootstrap `ExpectedNativeHelperSourceSha256`, `ExpectedNativeHelperAssemblySha256`, `ExpectedInspectorSha256` and corresponding binding checks | External inspector/source pins must agree with manifest entries; helper assembly is separately hash-checked and loaded from those retained bytes only, never compiled. All pins/streams precede main creation. |
| Preconfigured parent job | `ContainedLauncher.RunContained` job creation/readback | Exact runner/inspector names only; named collision rejected; new job empty; active-process limit 1 plus kill-on-job-close and no breakaway flags, read back before CreateProcess. |
| Suspended process | `Native.CreateProcessW`, `StartupInfoEx` and exact handle attribute list | Native `CREATE_SUSPENDED` plus `EXTENDED_STARTUPINFO_PRESENT`; only stdout/stderr write and null stdin inherited. Parent job and read endpoints never inherited. |
| Assign before first resume | `AssignProcessToJobObject`, `IsProcessInJob`, `QueryPids`, `ResumeThread` | Assign still-suspended process; query exact named job membership and singleton PID; only then resume and require previous suspend count exactly 1. |
| Actual identity | `GetProcessTimes`, `QueryFullProcessImageNameW`; retained image stream SHA256 | Record returned process PID, FILETIME creation/start UTC, exact image path comparison and hash of retained executable stream. No process-name lookup or broad sweep. |
| Time and capture bound | `RunContained` loops, `Drain`, `LaunchEvidence` | Stopwatch starts before CreateProcess; normal execution wait ends at 28 seconds, termination/drain budget ends at 30 seconds. Available-byte pipe reads only; each burst finite; capture at most 8 MiB per stream; strict UTF-8 decode. Capture/timeout/nonzero/query failures block. |
| Failure cleanup | `TerminateExact`, `CloseOwned`, `OwnedSession.Dispose` | Exact created process/job handles only. Assignment-call success separately retained so a failed membership check still terminates its job. Kill job and also terminate exact process if still alive, finite remaining-budget wait, query job, retain errors. No PID/name kill, retries, deletion or shared-process sweep. |
| Runner parent adoption | `run.py` parent-job argument and `windows_api.py` `Job` (harness correction) | Runner opens parent job query-only, checks active=1, flags=0x2008 and exact current PID; it never creates/assigns a second job. Parent job ownership remains parent-only. |
| Independent post-exit query | Bootstrap auxiliary branch, `inspect_owned_job.inspect_exact` | Parent retains empty runner job, launches inspector in a different preconfigured active=1 job, with the same 30-second process machinery. Inspector queries exact held runner job and PID/start, distinguishes absent/reused/exited/still-running identity, records native failures. Absent named job is blocked, not interpreted as empty. |
| Evidence continuity | `LaunchEvidence`, Bootstrap final object | Both native child records contain executable/hash/PID/start/lifetime/exit/timeout/capture/job/failure fields; combined output binds source manifest, Bootstrap, helper source/binary and inspector source pins. Sessions close before final serialization so close failures affect status. |

All of these changes are source authoring only. The result names `LOCAL_CHILD_EXITED_NOT_QUALIFICATION` and `LOCAL_EVIDENCE_ONLY_NOT_OPERATIONAL_QUALIFICATION` describe dormant future control flow; they are not results produced during this task.

## Exact additional source pins required

Root manifest must include these candidate-relative files, in addition to every other exact source subtree file:

- `source/Bootstrap.ps1`
- `source/native/ContainedLaunch.cs`
- `source/auxiliary/inspect_owned_job.py`
- `source/NATIVE-CONTAINMENT-SOURCE-NOTES.md`
- `source/DELIVERY-POLICY.json`
- `source/permission_check.py`
- `source/path_policy.py`

The manifest must not pretend a helper assembly exists. A future external helper DLL needs an independently supplied full path and SHA256 plus build provenance tied to the exact source pin. No manifest generation step compiles, loads or runs it.

## Remaining prerequisites and limitations

1. **Source/build prerequisite:** no DLL exists; native source has not been compiled or syntax-checked. A separately authorized future revision must establish compiler/toolchain provenance, exact source-to-binary binding, supported process architecture and .NET/Windows API compatibility. Removing guards alone does not authorize activity.
2. **Local verification prerequisite:** no native creation, assignment, resume, timeout, nonzero exit, capture overflow/encoding, collision, failed query, failed termination or handle-close failure injection has been performed. Exact 30-second behavior, PID/start continuity, singleton membership, cleanup errors and inspector bounds have no new execution evidence.
3. **Bound limitation:** finite waits and stopwatches cannot guarantee interruption of a hung synchronous OS call or a blocked coordinator. A separately approved independently timed outer watchdog is still required; no such evidence is invented here. A failed termination is retained as blocked and cannot be asserted safe by source alone.
4. **Operational prerequisite:** protected interpreter/native DLL/stdlib/dependencies, ancestors, environment/TEMP/PATH, assembly loader and parent-relative path continuity remain unqualified. Retained byte streams are not a claim that these operational loader conditions are satisfied.
5. **Operational prerequisite:** actual installed roots, real service tokens/identities, SCM/environment/configuration closure and operational entrypoint remain blocked by their own requirements. These launcher changes cannot grant permission or qualify the permission checker.
6. **Historical boundary:** original Finalize-Containment and inspector sources are read-only references under `original-reference`. The revised Bootstrap integrates the future bounded auxiliary invocation rather than reusing the historical unbounded finalizer. No historical inspector identity, pre-run pin or lifetime is manufactured.

No current execution instructions, build commands, acceptance switches, retry paths or fixture invocations are supplied by this note.
