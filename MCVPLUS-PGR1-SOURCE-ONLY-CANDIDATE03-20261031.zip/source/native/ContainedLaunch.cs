// SOURCE-ONLY-NOT-AUTHORIZED. UNTESTED source; no DLL is delivered.
// No build command, compile-on-load path, acceptance flag or operational mode.
// A future separately authorized revision must remove the unconditional guard,
// build under a qualified toolchain, bind binary/source provenance and verify
// every failure path in a disposable local environment before any admission.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace McvPlus.PgR1
{
    public sealed class LaunchEvidence
    {
        public string Status { get; set; }
        public string Failure { get; set; }
        public int? Win32Error { get; set; }
        public string Executable { get; set; }
        public string ExecutableSha256 { get; set; }
        public string ExecutableHashMethod { get; set; }
        public string ObservedImagePath { get; set; }
        public uint ProcessId { get; set; }
        public long ProcessStartFileTimeUtc { get; set; }
        public string ProcessStartUtc { get; set; }
        public string CreationAttemptUtc { get; set; }
        public string ExitObservedUtc { get; set; }
        public double ObservedLifetimeSeconds { get; set; }
        public int LifetimeBoundSeconds { get; set; }
        public bool TimedOut { get; set; }
        public bool HasExited { get; set; }
        public uint? ExitCode { get; set; }
        public bool CreatedSuspended { get; set; }
        public bool JobConfiguredBeforeCreate { get; set; }
        public bool AssignedBeforeResume { get; set; }
        public bool AssignmentCallSucceeded { get; set; }
        public bool Resumed { get; set; }
        public string JobName { get; set; }
        public uint ActiveProcessLimit { get; set; }
        public bool KillOnJobClose { get; set; }
        public bool CollisionRejected { get; set; }
        public uint[] JobPidsBeforeResume { get; set; }
        public uint[] JobPidsAfterExit { get; set; }
        public bool JobEmptyAfterExit { get; set; }
        public bool CaptureComplete { get; set; }
        public int StandardOutputBytes { get; set; }
        public int StandardErrorBytes { get; set; }
        public string StandardOutputBase64 { get; set; }
        public string StandardErrorBase64 { get; set; }
        public string StandardOutput { get; set; }
        public string StandardError { get; set; }
        public bool TerminationAttempted { get; set; }
        public bool? JobTerminationSucceeded { get; set; }
        public bool? ProcessTerminationSucceeded { get; set; }
        public List<string> CleanupFailures { get; set; }
        public string Qualification { get; set; }
        public LaunchEvidence()
        {
            Status = "BLOCKED_NOT_STARTED";
            CleanupFailures = new List<string>();
            Qualification = "UNTESTED_SOURCE_ONLY_NO_OPERATIONAL_QUALIFICATION";
            LifetimeBoundSeconds = 30;
        }
    }

    // Parent owns the job until independent inspection has completed. The child
    // opens it query-only; it never creates or assigns itself to another job.
    public sealed class OwnedSession : IDisposable
    {
        internal IntPtr Job;
        public LaunchEvidence Evidence { get; internal set; }
        public void Dispose()
        {
            if (Job == IntPtr.Zero) return;
            IntPtr held = Job; Job = IntPtr.Zero;
            if (!Native.CloseHandle(held))
                Evidence.CleanupFailures.Add("CloseHandle(job):" + Marshal.GetLastWin32Error());
            if (Evidence.CleanupFailures.Count != 0) Evidence.Status = "BLOCKED_CLEANUP";
        }
    }

    public static class ContainedLauncher
    {
        private const uint MaxCaptureBytes = 8388608;
        private const uint FailureExit = 0xE0000001;
        private static void RequireFutureAuthorization()
        {
            throw new InvalidOperationException("SOURCE-ONLY-NOT-AUTHORIZED");
        }

        public static OwnedSession Run(string executable, string[] arguments,
            string workingDirectory, string expectedSha256, string jobName)
        {
            RequireFutureAuthorization();
            return RunContained(executable, arguments, workingDirectory, expectedSha256, jobName);
        }

        private static OwnedSession RunContained(string executable, string[] arguments,
            string workingDirectory, string expectedSha256, string jobName)
        {
            LaunchEvidence e = new LaunchEvidence();
            e.Executable = executable; e.ExecutableSha256 = expectedSha256; e.JobName = jobName;
            e.ExecutableHashMethod = "SHA256 of same retained FileShare.Read stream before creation";
            OwnedSession session = new OwnedSession { Evidence = e };
            IntPtr process = IntPtr.Zero, thread = IntPtr.Zero;
            IntPtr outRead = IntPtr.Zero, outWrite = IntPtr.Zero;
            IntPtr errRead = IntPtr.Zero, errWrite = IntPtr.Zero, nul = IntPtr.Zero;
            IntPtr attributes = IntPtr.Zero, handleList = IntPtr.Zero;
            bool attributesInitialized = false, created = false;
            FileStream image = null;
            MemoryStream stdout = new MemoryStream(), stderr = new MemoryStream();
            bool outEof = false, errEof = false;
            Stopwatch lifetime = null;
            try
            {
                RequireAbsolute(executable); RequireAbsolute(workingDirectory);
                if (expectedSha256 == null || expectedSha256.Length != 64 ||
                    !IsLowerHex(expectedSha256)) throw new InvalidOperationException("IMAGE_PIN_FORMAT");
                if (jobName != "PG-R1-mcvplus-pgr1-source-only-20261031-candidate03-runner" &&
                    jobName != "PG-R1-mcvplus-pgr1-source-only-20261031-candidate03-runner-inspector")
                    throw new InvalidOperationException("EXACT_JOB_NAMESPACE_REQUIRED");
                image = new FileStream(executable, FileMode.Open, FileAccess.Read, FileShare.Read);
                string hash;
                using (SHA256 sha = SHA256.Create())
                    hash = BitConverter.ToString(sha.ComputeHash(image)).Replace("-", "").ToLowerInvariant();
                if (!String.Equals(hash, expectedSha256, StringComparison.Ordinal))
                    throw new InvalidOperationException("IMAGE_PIN_MISMATCH");

                // SetLastError(0) distinguishes a newly created job from a
                // preexisting named object. A collision is never adopted.
                Native.SetLastError(0);
                session.Job = Native.CreateJobObjectW(IntPtr.Zero, jobName);
                int jobError = Marshal.GetLastWin32Error();
                Check(session.Job != IntPtr.Zero, "CreateJobObject");
                if (jobError == 183) { e.CollisionRejected = true; throw new InvalidOperationException("JOB_NAME_COLLISION"); }
                Native.ExtendedLimits limits = new Native.ExtendedLimits();
                limits.Basic.LimitFlags = 0x00002000 | 0x00000008;
                limits.Basic.ActiveProcessLimit = 1;
                Check(Native.SetInformationJobObject(session.Job, 9, ref limits,
                    (uint)Marshal.SizeOf(typeof(Native.ExtendedLimits))), "SetJobLimits");
                Native.ExtendedLimits readback;
                Check(Native.QueryJobLimits(session.Job, 9, out readback,
                    (uint)Marshal.SizeOf(typeof(Native.ExtendedLimits)), IntPtr.Zero), "QueryJobLimits");
                if (readback.Basic.ActiveProcessLimit != 1 ||
                    readback.Basic.LimitFlags != (0x00002000 | 0x00000008))
                    throw new InvalidOperationException("JOB_LIMIT_READBACK_MISMATCH");
                if (QueryPids(session.Job).Length != 0) throw new InvalidOperationException("NEW_JOB_NOT_EMPTY");
                e.JobConfiguredBeforeCreate = true; e.KillOnJobClose = true; e.ActiveProcessLimit = 1;

                Native.SecurityAttributes sa = new Native.SecurityAttributes();
                sa.Length = Marshal.SizeOf(typeof(Native.SecurityAttributes)); sa.InheritHandle = true;
                Check(Native.CreatePipe(out outRead, out outWrite, ref sa, 0), "CreateStdoutPipe");
                Check(Native.CreatePipe(out errRead, out errWrite, ref sa, 0), "CreateStderrPipe");
                Check(Native.SetHandleInformation(outRead, 1, 0), "NoInheritStdoutRead");
                Check(Native.SetHandleInformation(errRead, 1, 0), "NoInheritStderrRead");
                nul = Native.CreateFileW("NUL", 0x80000000, 3, ref sa, 3, 0, IntPtr.Zero);
                Check(nul != new IntPtr(-1), "OpenNullStdin");
                UIntPtr attributeBytes = UIntPtr.Zero;
                bool sizeResult = Native.InitializeProcThreadAttributeList(IntPtr.Zero, 1, 0, ref attributeBytes);
                if (sizeResult || Marshal.GetLastWin32Error() != 122 || attributeBytes.ToUInt64() > 65536)
                    throw new InvalidOperationException("ATTRIBUTE_LIST_SIZE_QUERY");
                attributes = Marshal.AllocHGlobal(checked((int)attributeBytes.ToUInt64()));
                Check(Native.InitializeProcThreadAttributeList(attributes, 1, 0, ref attributeBytes), "InitHandleList");
                attributesInitialized = true;
                handleList = Marshal.AllocHGlobal(IntPtr.Size * 3);
                Marshal.WriteIntPtr(handleList, 0, outWrite);
                Marshal.WriteIntPtr(handleList, IntPtr.Size, errWrite);
                Marshal.WriteIntPtr(handleList, IntPtr.Size * 2, nul);
                Check(Native.UpdateProcThreadAttribute(attributes, 0, new IntPtr(0x00020002),
                    handleList, new UIntPtr((uint)(IntPtr.Size * 3)), IntPtr.Zero, IntPtr.Zero), "SetExactHandleList");
                Native.StartupInfoEx startup = new Native.StartupInfoEx();
                startup.Startup.Cb = Marshal.SizeOf(typeof(Native.StartupInfoEx));
                startup.Startup.Flags = 0x00000100;
                startup.Startup.StdInput = nul; startup.Startup.StdOutput = outWrite; startup.Startup.StdError = errWrite;
                startup.AttributeList = attributes;
                StringBuilder command = new StringBuilder(Quote(executable));
                if (arguments == null) throw new InvalidOperationException("ARGUMENTS_REQUIRED");
                foreach (string argument in arguments) command.Append(' ').Append(Quote(argument));
                if (command.Length >= 32767) throw new InvalidOperationException("COMMAND_LENGTH");

                Native.ProcessInformation pi;
                e.CreationAttemptUtc = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture);
                lifetime = Stopwatch.StartNew();
                Check(Native.CreateProcessW(executable, command, IntPtr.Zero, IntPtr.Zero, true,
                    0x00000004 | 0x00080000 | 0x08000000, IntPtr.Zero, workingDirectory,
                    ref startup, out pi), "CreateProcessSuspended");
                created = true; process = pi.Process; thread = pi.Thread;
                e.ProcessId = pi.ProcessId; e.CreatedSuspended = true;
                // Close parent write endpoints before capture. Only the three
                // explicit stdio handles were inherited; no job handle was.
                CloseOwned(ref outWrite, "stdoutWrite", e);
                CloseOwned(ref errWrite, "stderrWrite", e);
                CloseOwned(ref nul, "nullStdin", e);
                if (e.CleanupFailures.Count != 0) throw new InvalidOperationException("PARENT_PIPE_CLOSE_FAILURE");
                long creation, exit, kernel, user;
                Check(Native.GetProcessTimes(process, out creation, out exit, out kernel, out user), "GetProcessTimes");
                e.ProcessStartFileTimeUtc = creation;
                e.ProcessStartUtc = DateTime.FromFileTimeUtc(creation).ToString("o", CultureInfo.InvariantCulture);
                StringBuilder actualImage = new StringBuilder(32768); uint imageChars = (uint)actualImage.Capacity;
                Check(Native.QueryFullProcessImageNameW(process, 0, actualImage, ref imageChars), "QueryProcessImage");
                e.ObservedImagePath = actualImage.ToString();
                if (!String.Equals(executable, e.ObservedImagePath, StringComparison.Ordinal))
                    throw new InvalidOperationException("PROCESS_IMAGE_IDENTITY_MISMATCH");
                Check(Native.AssignProcessToJobObject(session.Job, process), "AssignSuspendedProcessToJob");
                e.AssignmentCallSucceeded = true;
                bool inJob;
                Check(Native.IsProcessInJob(process, session.Job, out inJob), "QuerySuspendedJobMembership");
                e.JobPidsBeforeResume = QueryPids(session.Job);
                if (!inJob || e.JobPidsBeforeResume.Length != 1 || e.JobPidsBeforeResume[0] != e.ProcessId)
                    throw new InvalidOperationException("PRE_RESUME_CONTAINMENT_MISMATCH");
                e.AssignedBeforeResume = true;
                if (lifetime.Elapsed.TotalSeconds >= 28) throw new InvalidOperationException("STARTUP_BUDGET_EXHAUSTED");
                // ResumeThread must report exactly the single CREATE_SUSPENDED
                // suspend count. A different count blocks and terminates.
                uint previousSuspendCount = Native.ResumeThread(thread);
                if (previousSuspendCount == 0xFFFFFFFF) ThrowWin32("ResumeThread");
                if (previousSuspendCount != 1) throw new InvalidOperationException("RESUME_SUSPEND_COUNT_MISMATCH");
                e.Resumed = true;
                CloseOwned(ref thread, "initialThread", e);
                if (e.CleanupFailures.Count != 0) throw new InvalidOperationException("THREAD_HANDLE_CLOSE_FAILURE");

                while (true)
                {
                    Drain(outRead, stdout, ref outEof); Drain(errRead, stderr, ref errEof);
                    uint wait = Native.WaitForSingleObject(process, 10);
                    if (wait == 0) { e.HasExited = true; break; }
                    if (wait != 258) ThrowWin32("WaitForOwnedProcess");
                    if (lifetime.Elapsed.TotalSeconds >= 28)
                    { e.TimedOut = true; throw new InvalidOperationException("CHILD_TIMEOUT"); }
                }
                // Drain only available bytes; never ReadToEnd or block on a pipe.
                while (!outEof || !errEof)
                {
                    Drain(outRead, stdout, ref outEof); Drain(errRead, stderr, ref errEof);
                    if (lifetime.Elapsed.TotalSeconds >= 30) throw new InvalidOperationException("CAPTURE_DEADLINE");
                    if (!outEof || !errEof) Native.WaitForSingleObject(process, 1);
                }
                e.CaptureComplete = true;
                uint code; Check(Native.GetExitCodeProcess(process, out code), "GetOwnedExitCode"); e.ExitCode = code;
                e.JobPidsAfterExit = QueryPids(session.Job);
                e.JobEmptyAfterExit = e.JobPidsAfterExit.Length == 0;
                if (!e.JobEmptyAfterExit) throw new InvalidOperationException("POST_EXIT_JOB_NOT_EMPTY");
                if (code != 0) throw new InvalidOperationException("CHILD_NONZERO_EXIT");
                if (lifetime.Elapsed.TotalSeconds > 30) throw new InvalidOperationException("CHILD_BOUND_EXCEEDED");
                e.Status = "LOCAL_CHILD_EXITED_NOT_QUALIFICATION";
            }
            catch (Exception ex)
            {
                e.Status = "BLOCKED_NATIVE_LAUNCH_OR_EVIDENCE";
                e.Failure = ex.Message;
                Win32Exception native = ex as Win32Exception;
                if (native != null) e.Win32Error = native.NativeErrorCode;
                // Collision job was not created by us. Never terminate it.
                if (created) TerminateExact(process, session.Job, e, lifetime);
            }
            finally
            {
                if (created && !e.HasExited) TerminateExact(process, session.Job, e, lifetime);
                if (lifetime != null)
                {
                    e.ObservedLifetimeSeconds = lifetime.Elapsed.TotalSeconds;
                    if (e.ObservedLifetimeSeconds > 30) { e.Status = "BLOCKED_CHILD_BOUND"; e.TimedOut = true; }
                }
                e.ExitObservedUtc = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture);
                e.StandardOutputBase64 = Convert.ToBase64String(stdout.ToArray());
                e.StandardErrorBase64 = Convert.ToBase64String(stderr.ToArray());
                e.StandardOutputBytes = checked((int)stdout.Length); e.StandardErrorBytes = checked((int)stderr.Length);
                try
                {
                    UTF8Encoding utf8 = new UTF8Encoding(false, true);
                    e.StandardOutput = utf8.GetString(stdout.ToArray()); e.StandardError = utf8.GetString(stderr.ToArray());
                }
                catch (DecoderFallbackException) { e.CaptureComplete = false; e.Status = "BLOCKED_CAPTURE_ENCODING"; }
                DisposeManaged(stdout, "stdoutBuffer", e); DisposeManaged(stderr, "stderrBuffer", e);
                CloseOwned(ref thread, "initialThread", e); CloseOwned(ref process, "ownedProcess", e);
                CloseOwned(ref outRead, "stdoutRead", e); CloseOwned(ref outWrite, "stdoutWrite", e);
                CloseOwned(ref errRead, "stderrRead", e); CloseOwned(ref errWrite, "stderrWrite", e);
                CloseOwned(ref nul, "nullStdin", e);
                if (attributesInitialized) Native.DeleteProcThreadAttributeList(attributes);
                if (attributes != IntPtr.Zero) Marshal.FreeHGlobal(attributes);
                if (handleList != IntPtr.Zero) Marshal.FreeHGlobal(handleList);
                DisposeManaged(image, "imageStream", e);
                if (e.CleanupFailures.Count != 0) e.Status = "BLOCKED_CLEANUP";
                // A collided handle must be closed, never retained as an owned job.
                if (e.CollisionRejected) session.Dispose();
            }
            return session;
        }

        private static void TerminateExact(IntPtr process, IntPtr job, LaunchEvidence e, Stopwatch clock)
        {
            if (e.TerminationAttempted || process == IntPtr.Zero) return;
            e.TerminationAttempted = true;
            // Only handles returned by our CreateProcess/CreateJobObject. No
            // PID/name lookup, shared-process enumeration, retry or broad sweep.
            if (e.AssignmentCallSucceeded)
            {
                e.JobTerminationSucceeded = Native.TerminateJobObject(job, FailureExit);
                if (e.JobTerminationSucceeded != true) e.CleanupFailures.Add("TerminateJob:" + Marshal.GetLastWin32Error());
            }
            // Also terminate a suspended process when assignment itself failed.
            uint before = Native.WaitForSingleObject(process, 0);
            if (before == 0) e.ProcessTerminationSucceeded = true;
            else
            {
                e.ProcessTerminationSucceeded = Native.TerminateProcess(process, FailureExit);
                if (e.ProcessTerminationSucceeded != true) e.CleanupFailures.Add("TerminateProcess:" + Marshal.GetLastWin32Error());
            }
            double remaining = clock == null ? 0 : Math.Max(0, 30 - clock.Elapsed.TotalSeconds);
            uint wait = Native.WaitForSingleObject(process, (uint)Math.Min(2000, remaining * 1000));
            e.HasExited = wait == 0;
            if (!e.HasExited) e.CleanupFailures.Add("OWNED_PROCESS_EXIT_NOT_CONFIRMED_WITHIN_BOUND");
            else
            {
                uint code;
                if (Native.GetExitCodeProcess(process, out code)) e.ExitCode = code;
                else e.CleanupFailures.Add("CleanupExitCode:" + Marshal.GetLastWin32Error());
            }
            if (e.AssignmentCallSucceeded)
            {
                try { e.JobPidsAfterExit = QueryPids(job); e.JobEmptyAfterExit = e.JobPidsAfterExit.Length == 0; }
                catch (Exception ex) { e.CleanupFailures.Add("CleanupJobQuery:" + ex.Message); }
                if (!e.JobEmptyAfterExit) e.CleanupFailures.Add("OWNED_JOB_EMPTY_NOT_CONFIRMED");
            }
        }

        private static void Drain(IntPtr pipe, MemoryStream sink, ref bool eof)
        {
            if (eof) return;
            // Each call is bounded so a noisy child cannot defer the lifetime
            // check indefinitely. Only this parent consumes this read endpoint.
            for (int burst = 0; burst < 64; ++burst)
            {
                uint available;
                if (!Native.PeekNamedPipe(pipe, IntPtr.Zero, 0, IntPtr.Zero, out available, IntPtr.Zero))
                {
                    int error = Marshal.GetLastWin32Error();
                    if (error == 109) { eof = true; return; }
                    throw new Win32Exception(error, "PeekCapturePipe");
                }
                if (available == 0) return;
                byte[] buffer = new byte[Math.Min(4096U, available)]; uint read;
                Check(Native.ReadFile(pipe, buffer, (uint)buffer.Length, out read, IntPtr.Zero), "ReadAvailableCapture");
                if (read == 0) throw new InvalidOperationException("CAPTURE_ZERO_READ");
                if (sink.Length + read > MaxCaptureBytes) throw new InvalidOperationException("CAPTURE_SIZE_LIMIT");
                sink.Write(buffer, 0, (int)read);
            }
        }

        private static uint[] QueryPids(IntPtr job)
        {
            const int capacity = 16;
            int bytes = 8 + capacity * IntPtr.Size; IntPtr buffer = Marshal.AllocHGlobal(bytes);
            try
            {
                Check(Native.QueryInformationJobObject(job, 3, buffer, (uint)bytes, IntPtr.Zero), "QueryOwnedJobPids");
                uint assigned = unchecked((uint)Marshal.ReadInt32(buffer, 0));
                uint count = unchecked((uint)Marshal.ReadInt32(buffer, 4));
                if (count > capacity || count > assigned) throw new InvalidOperationException("JOB_PID_LIST_TRUNCATED");
                uint[] ids = new uint[count];
                for (int i = 0; i < ids.Length; ++i)
                {
                    ulong value = unchecked((ulong)Marshal.ReadIntPtr(buffer, 8 + i * IntPtr.Size).ToInt64());
                    if (value > UInt32.MaxValue) throw new InvalidOperationException("JOB_PID_RANGE");
                    ids[i] = (uint)value;
                }
                return ids;
            }
            finally { Marshal.FreeHGlobal(buffer); }
        }

        private static string Quote(string value)
        {
            if (value == null || value.IndexOf('\0') >= 0 || value.IndexOf('\r') >= 0 || value.IndexOf('\n') >= 0)
                throw new InvalidOperationException("INVALID_COMMAND_ARGUMENT");
            StringBuilder result = new StringBuilder("\""); int slashes = 0;
            foreach (char ch in value)
            {
                if (ch == '\\') { ++slashes; continue; }
                if (ch == '"') { result.Append('\\', slashes * 2 + 1).Append(ch); slashes = 0; continue; }
                result.Append('\\', slashes).Append(ch); slashes = 0;
            }
            return result.Append('\\', slashes * 2).Append('"').ToString();
        }

        private static void DisposeManaged(IDisposable value, string role, LaunchEvidence evidence)
        {
            if (value == null) return;
            try { value.Dispose(); }
            catch (Exception error)
            {
                // Secondary cleanup must never escape before the original
                // failure/session evidence is returned to the parent.
                evidence.CleanupFailures.Add(role + ":" + error.GetType().FullName + ":" + error.Message);
                evidence.Status = "BLOCKED_CLEANUP";
            }
        }

        private static bool IsLowerHex(string text)
        { foreach (char ch in text) if (!(ch >= '0' && ch <= '9') && !(ch >= 'a' && ch <= 'f')) return false; return true; }
        private static void RequireAbsolute(string path)
        {
            if (String.IsNullOrEmpty(path) || path.Length < 3 || path[0] < 'A' || path[0] > 'Z' ||
                path[1] != ':' || path[2] != '\\' || path.IndexOf('"') >= 0 || path.IndexOf('\0') >= 0 ||
                path.IndexOf('\r') >= 0 || path.IndexOf('\n') >= 0 ||
                !String.Equals(Path.GetFullPath(path), path, StringComparison.Ordinal))
                throw new InvalidOperationException("EXACT_ABSOLUTE_PATH_REQUIRED");
        }
        private static void Check(bool ok, string operation) { if (!ok) ThrowWin32(operation); }
        private static void ThrowWin32(string operation) { throw new Win32Exception(Marshal.GetLastWin32Error(), operation); }
        private static void CloseOwned(ref IntPtr handle, string role, LaunchEvidence evidence)
        {
            if (handle == IntPtr.Zero || handle == new IntPtr(-1)) { handle = IntPtr.Zero; return; }
            IntPtr value = handle; handle = IntPtr.Zero;
            if (!Native.CloseHandle(value)) evidence.CleanupFailures.Add("CloseHandle(" + role + "):" + Marshal.GetLastWin32Error());
        }
    }

    internal static class Native
    {
        [StructLayout(LayoutKind.Sequential)] internal struct SecurityAttributes { internal int Length; internal IntPtr Descriptor; [MarshalAs(UnmanagedType.Bool)] internal bool InheritHandle; }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)] internal struct StartupInfo
        {
            internal int Cb; internal string Reserved; internal string Desktop; internal string Title;
            internal uint X, Y, XSize, YSize, XCountChars, YCountChars, FillAttribute, Flags;
            internal ushort ShowWindow, Reserved2Size; internal IntPtr Reserved2, StdInput, StdOutput, StdError;
        }
        [StructLayout(LayoutKind.Sequential)] internal struct StartupInfoEx { internal StartupInfo Startup; internal IntPtr AttributeList; }
        [StructLayout(LayoutKind.Sequential)] internal struct ProcessInformation { internal IntPtr Process, Thread; internal uint ProcessId, ThreadId; }
        [StructLayout(LayoutKind.Sequential)] internal struct BasicLimits
        {
            internal long PerProcessUserTimeLimit, PerJobUserTimeLimit; internal uint LimitFlags;
            internal UIntPtr MinimumWorkingSetSize, MaximumWorkingSetSize; internal uint ActiveProcessLimit;
            internal UIntPtr Affinity; internal uint PriorityClass, SchedulingClass;
        }
        [StructLayout(LayoutKind.Sequential)] internal struct IoCounters { internal ulong ReadOperations, WriteOperations, OtherOperations, ReadBytes, WriteBytes, OtherBytes; }
        [StructLayout(LayoutKind.Sequential)] internal struct ExtendedLimits
        {
            internal BasicLimits Basic; internal IoCounters Io;
            internal UIntPtr ProcessMemoryLimit, JobMemoryLimit, PeakProcessMemoryUsed, PeakJobMemoryUsed;
        }
        [DllImport("kernel32.dll")] internal static extern void SetLastError(uint error);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] internal static extern IntPtr CreateJobObjectW(IntPtr attributes, string name);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool SetInformationJobObject(IntPtr job, int info, ref ExtendedLimits limits, uint bytes);
        [DllImport("kernel32.dll", EntryPoint = "QueryInformationJobObject", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool QueryJobLimits(IntPtr job, int info, out ExtendedLimits limits, uint bytes, IntPtr returned);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool QueryInformationJobObject(IntPtr job, int info, IntPtr buffer, uint bytes, IntPtr returned);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool IsProcessInJob(IntPtr process, IntPtr job, [MarshalAs(UnmanagedType.Bool)] out bool member);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool CreatePipe(out IntPtr read, out IntPtr write, ref SecurityAttributes attributes, uint size);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool SetHandleInformation(IntPtr handle, uint mask, uint flags);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] internal static extern IntPtr CreateFileW(string name, uint access, uint share, ref SecurityAttributes attributes, uint creation, uint flags, IntPtr template);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool InitializeProcThreadAttributeList(IntPtr list, int count, uint flags, ref UIntPtr size);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool UpdateProcThreadAttribute(IntPtr list, uint flags, IntPtr attribute, IntPtr value, UIntPtr bytes, IntPtr previous, IntPtr returned);
        [DllImport("kernel32.dll")] internal static extern void DeleteProcThreadAttributeList(IntPtr list);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool CreateProcessW(string application, StringBuilder command, IntPtr processAttributes, IntPtr threadAttributes, [MarshalAs(UnmanagedType.Bool)] bool inheritHandles, uint flags, IntPtr environment, string directory, ref StartupInfoEx startup, out ProcessInformation process);
        [DllImport("kernel32.dll", SetLastError = true)] internal static extern uint ResumeThread(IntPtr thread);
        [DllImport("kernel32.dll", SetLastError = true)] internal static extern uint WaitForSingleObject(IntPtr handle, uint milliseconds);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool GetProcessTimes(IntPtr process, out long creation, out long exit, out long kernel, out long user);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool QueryFullProcessImageNameW(IntPtr process, uint flags, StringBuilder image, ref uint chars);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool GetExitCodeProcess(IntPtr process, out uint exitCode);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool PeekNamedPipe(IntPtr pipe, IntPtr buffer, uint bytes, IntPtr read, out uint available, IntPtr left);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool ReadFile(IntPtr handle, byte[] buffer, uint bytes, out uint read, IntPtr overlapped);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool TerminateJobObject(IntPtr job, uint exitCode);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool TerminateProcess(IntPtr process, uint exitCode);
        [DllImport("kernel32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool CloseHandle(IntPtr handle);
    }
}
