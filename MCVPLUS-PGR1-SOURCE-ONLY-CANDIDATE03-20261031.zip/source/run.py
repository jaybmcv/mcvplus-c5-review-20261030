"""Historical local harness, revised as UNTESTED SOURCE ONLY.
Delivery does not authorize any execution. The unconditional delivery block must
remain in this candidate; future authorization requires a separately reviewed
revision and independent external pins, never an acceptance flag or argument.
"""
raise SystemExit('SOURCE_ONLY_NOT_AUTHORIZED')
import sys
if sys.argv.count('--mode=LocalValidation')!=1 or any(x.startswith('--mode') and x!='--mode=LocalValidation' for x in sys.argv):
    raise SystemExit('UNCONDITIONAL_OPERATIONAL_ADMISSION_BLOCK')
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import threading
import time
import traceback

ROOT=Path(r'D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate03')
SOURCE=ROOT/'source'
def digest(data):return hashlib.sha256(data).hexdigest()
def utc():
    import datetime
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
parser=argparse.ArgumentParser(allow_abbrev=False)
parser.add_argument('--mode',required=True);parser.add_argument('--manifest',required=True);parser.add_argument('--bootstrap',required=True);parser.add_argument('--deadline',type=float,required=True)
parser.add_argument('--parent-job',required=True)
args=parser.parse_args()
if args.mode!='LocalValidation' or sys.argv.count('--mode=LocalValidation')!=1 or any(x.startswith('--mode') and x!='--mode=LocalValidation' for x in sys.argv):
    raise SystemExit('UNCONDITIONAL_OPERATIONAL_ADMISSION_BLOCK')
if args.parent_job!='PG-R1-'+ROOT.name+'-runner':raise SystemExit('EXACT_PARENT_OWNED_JOB_REQUIRED')
if Path(__file__)!=SOURCE/'run.py':raise SystemExit('EXACT_LOCAL_NAMESPACE_ONLY')
if len(args.manifest)!=64 or len(args.bootstrap)!=64:raise SystemExit('EXTERNAL_PINS_REQUIRED')
raw=(ROOT/'SOURCE-MANIFEST.json').read_bytes()
if digest(raw)!=args.manifest or digest((SOURCE/'Bootstrap.ps1').read_bytes())!=args.bootstrap:raise SystemExit('EXTERNAL_PIN_MISMATCH')
manifest=json.loads(raw);pins={p['path']:p for p in manifest['files']}
if len(pins)!=len(manifest['files']):raise SystemExit('MANIFEST_COLLISION')
if manifest.get('schema')!=2 or manifest.get('status')!='UNTESTED' or manifest.get('executionAuthorized') is not False:raise SystemExit('SOURCE_ONLY_MANIFEST_REQUIRED')
if any(not rel.startswith('source/') for rel in pins):raise SystemExit('SOURCE_MANIFEST_FULL_CANDIDATE_PATH_REQUIRED')
if len({rel.casefold() for rel in pins})!=len(pins):raise SystemExit('SOURCE_MANIFEST_CASE_COLLISION')
required={'source/run.py','source/windows_api.py','source/gate.py','source/permission_check.py','source/path_policy.py',
          'source/Bootstrap.ps1','source/DELIVERY-POLICY.json','source/native/ContainedLaunch.cs','source/auxiliary/inspect_owned_job.py'}
if not required.issubset(pins):raise SystemExit('REQUIRED_HELPER_SOURCE_MISSING')
allowed=set(pins)
actual=set();actual_dirs=set()
expected_dirs={'/'.join(rel.split('/')[:i]) for rel in pins for i in range(2,len(rel.split('/')))}
for directory,dirs,files in os.walk(SOURCE,followlinks=False):
    for name in dirs+files:
        p=Path(directory)/name
        if p.is_symlink() or (p.stat(follow_symlinks=False).st_file_attributes&0x400):raise SystemExit('SOURCE_REPARSE')
    for name in dirs:actual_dirs.add((Path(directory)/name).relative_to(ROOT).as_posix())
    for name in files:actual.add((Path(directory)/name).relative_to(ROOT).as_posix())
if actual!=allowed or actual_dirs!=expected_dirs:raise SystemExit('EXTRA_OR_MISSING_SOURCE')
verified_bytes={}
for rel,pin in pins.items():
    if rel.startswith('/') or '\\' in rel or ':' in rel or '..' in rel.split('/'):raise SystemExit('SOURCE_PATH')
    data=(ROOT/rel).read_bytes()
    if len(data)!=pin['bytes'] or digest(data)!=pin['sha256']:raise SystemExit('SOURCE_DRIFT')
    verified_bytes[rel]=data
# Only after independent pins and exact source inventory do candidate modules load.
delivery=json.loads(verified_bytes['source/DELIVERY-POLICY.json'])
if (delivery.get('sourceOnly') is not True or delivery.get('executionAuthorized') is not False or
    any(delivery.get(k) is not False for k in ('nativeLaunchEnabled','compilationEnabled','helperLoadEnabled','fixtureCreationEnabled'))):
    raise SystemExit('SOURCE_ONLY_DELIVERY_POLICY_REQUIRED')
# Preserve the original normative policy bytes as historical input. Its old
# local enablement fields confer no authorization over DELIVERY-POLICY.json or
# the unconditional source-only delivery guard above.
policy=json.loads(verified_bytes['source/policy/LOCAL-POLICY.json'])
if (policy.get('helperLoadEnabled') is not True or policy.get('fixtureCreationEnabled') is not True or
    policy.get('nativeLaunchEnabled') is not True or policy.get('compilationEnabled') is not False or
    policy.get('bounds',{}).get('nativeChildSeconds')!=30):
    raise SystemExit('BLOCKED_LOCAL_POLICY_ADMISSION')
def load(name):
    spec=importlib.util.spec_from_file_location(name,SOURCE/(name+'.py'))
    module=importlib.util.module_from_spec(spec)
    if name in sys.modules:raise SystemExit('UNPINNED_PRELOADED_CANDIDATE_MODULE')
    sys.modules[name]=module
    # Execute exactly the bytes already externally pinned; never reread candidate
    # helper by pathname after verification. Python bytecode is in-memory only.
    exec(compile(verified_bytes['source/'+name+'.py'],str(SOURCE/(name+'.py')),'exec'),module.__dict__)
    return module
win=load('windows_api');permission_check=load('permission_check');path_policy=load('path_policy');gate=load('gate')
matrix=json.loads(verified_bytes['source/FIXTURE-MATRIX.json'])
if [c['id'] for c in matrix['cases']]!=[f'L{i:02}' for i in range(1,29)]:raise SystemExit('EXACT_28_IDS_ONCE')
# Wall-clock launcher budget is converted once; in-process deadlines are monotonic.
deadline=time.monotonic()+max(0,min(30,args.deadline-time.time()))
active_deadline=deadline
finished=False
def watchdog():
    while not finished:
        if time.monotonic()>min(deadline,active_deadline):os._exit(124)
        time.sleep(.05)
threading.Thread(target=watchdog,daemon=True).start()

job=None;out=None;held=[];rows=[];evidence=[];payload=0;output_bytes=0;hardlink_preparation=None
HARDLINK_FIXTURE_DATA=b'synthetic hardlink sentinel; no operational content\n'
stop=None;start=utc();run_out=ROOT/'runner-evidence';fixture_root=ROOT/'fixtures'
def create_dir(p):
    h=win.new_directory(str(p));held.append(h);return h
def create_file(p,data=b'synthetic, not a credential or ledger entry\n'):
    global payload
    if payload+len(data)>512*1024*1024:raise win.Blocked('FIXTURE_PAYLOAD_BOUND')
    h=win.new_file(str(p),data);held.append(h);payload+=len(data);return h
def write_evidence(name,value):
    global output_bytes
    data=json.dumps(value,indent=2,sort_keys=True).encode()
    if output_bytes+len(data)>2*1024**3-32*1024**2:raise win.Blocked('RETAINED_RECEIPT_BOUND_WITH_LOG_RESERVE')
    h=win.new_file(str(run_out/name),data);held.append(h);output_bytes+=len(data)
    evidence.append({'path':'runner-evidence/'+name,'bytes':len(data),'sha256':h.hash(),'held':h.record()})
def observation(name,status,detail,actual=True,simulated=False):
    return {'name':name,'status':status,'detail':detail,'actual':actual,'simulated':simulated,'operationalEvidence':False}
def planned(case,done,status='BLOCKED'):
    names={x['name'] for x in done}
    return done+[observation(s['name'],status,'Not attempted after stop' if status=='NOT_RUN' else 'Unsupported or no actual token/continuity demonstration; not inferred from synthetic checks',False) for s in case['subchecks'] if s['name'] not in names]

def semantic(case,row):
    mismatch=False;checks=[];rights=[]
    row['subchecks']=checks
    for text in case['descriptors']:
        for name in case['contexts']:
            context=matrix['syntheticContextDefinitions'][name]
            for right in matrix['individualRights']:
                requested=int(right['mask'],16)
                if mismatch:
                    rights.append({'descriptor':text,'tokenContext':context,'contextName':name,'name':right['name'],'desiredAccess':requested,'reference':{'outcome':'NOT_RUN'},'gate':{'outcome':'NOT_RUN'},'comparison':'NOT_RUN','reason':'SEMANTIC_MISMATCH_STOP'})
                    continue
                g=gate.evaluate(text,context,requested)
                try:r=win.reference(text,context,requested)
                except win.Blocked as e:r={'outcome':'UNQUALIFIED','resultProduced':False,'attempted':True,'nativeInvocation':'NOT_COMPLETED_OR_NOT_REACHED_SEE_ERROR','reason':str(e),'actualToken':False,'synthetic':True}
                comparison='NOT_COMPARABLE'
                if g.get('qualified') and r['outcome'] in ('ALLOWED','DENIED'):
                    comparison='MATCH' if g['outcome']==r['outcome'] else 'MISMATCH'
                    mismatch|=comparison=='MISMATCH'
                rights.append({'descriptor':text,'tokenContext':context,'contextName':name,'name':right['name'],'desiredAccess':requested,'reference':r,'gate':g,'comparison':comparison})
    row['individualRights']=rights
    row['fixtureDescriptors']=case['descriptors']
    row['tokenProvenance']={'syntheticContexts':matrix['syntheticContextDefinitions'],'actualTokenAcquisitions':0,'realTokenClasses':{n:'UNQUALIFIED_NOT_ACQUIRED_NO_RETRY' for n in matrix['realTokenClassesRequired']},'privilegeEnablement':False,'duplicateTokenCalls':0}
    comparable=[r for r in rights if r['comparison'] in ('MATCH','MISMATCH')]
    checks.append(observation('supported-common-ace-authz-comparison','FAIL' if mismatch else 'PASS' if comparable else 'BLOCKED',{'comparisonCount':len(comparable),'unqualifiedCount':len(rights)-len(comparable)},True,True))
    # Every named PASS must cite its own exact invoked right and expected result.
    normal='synthetic-ordinary';filtered='synthetic-filtered-admin'
    pg='synthetic-postgres';provider='synthetic-provider';tunnel='synthetic-tunnel'
    mutation=[2,4,0x10,0x40,0x100,0x10000,0x40000,0x80000]
    tests={
      'L01':[('ordinary-mutation-denials',0,normal,mutation,'DENIED'),('filtered-admin-not-trusted',0,filtered,mutation,'DENIED'),('intended-read-execute',0,normal,[1,0x20,0x20000],'ALLOWED')],
      'L02':[('ancestor-add-subdirectory-only',0,normal,[4],'ALLOWED'),('delete-and-parent-delete-child-negative',0,normal,[0x40,0x10000],'DENIED'),('write-dac-owner-ea-attribute-negative',0,normal,[0x10,0x100,0x40000,0x80000],'DENIED')],
      'L03':[('parent-delete-child-allowed',0,normal,[0x40],'ALLOWED'),('child-delete-denied',1,normal,[0x10000],'DENIED')],
      'L04':[('child-delete-allowed',1,normal,[0x10000],'ALLOWED'),('parent-delete-child-denied',0,normal,[0x40],'DENIED')],
      'L05':[('file-write-data',0,normal,[2],'ALLOWED'),('file-append-data',1,normal,[4],'ALLOWED'),('directory-add-file',0,normal,[2],'ALLOWED'),('directory-add-subdirectory',1,normal,[4],'ALLOWED')],
      'L06':[('write-dac',0,normal,[0x40000],'ALLOWED'),('write-owner',1,normal,[0x80000],'ALLOWED')],
      'L07':[('file-write-ea',0,normal,[0x10],'ALLOWED'),('file-write-attributes',1,normal,[0x100],'ALLOWED'),('directory-write-ea',0,normal,[0x10],'ALLOWED'),('directory-write-attributes',1,normal,[0x100],'ALLOWED')],
      'L08':[('generic-write-map',0,normal,[2,4,0x10,0x100],'ALLOWED'),('generic-all-map',1,normal,mutation,'ALLOWED'),('inherit-only-ace',2,normal,[2],'DENIED'),('inherited-effective-ace',3,normal,[2],'ALLOWED'),('deny-before-allow',4,normal,[2],'DENIED'),('allow-before-deny-noncanonical',5,normal,[2],'ALLOWED')],
      'L09':[('deny-only-grant-ineffective',0,filtered,mutation,'DENIED')],
      'L11':[('postgres-modify-own-subtree',0,pg,[2,4,0x10,0x100,0x10000],'ALLOWED'),('cross-service-denied',0,provider,mutation,'DENIED'),('code-denied',1,pg,mutation,'DENIED')],
      'L12':[('provider-slots-modify-dummy-names-only',0,provider,[2,4,0x10,0x100,0x10000],'ALLOWED'),('tunnel-read-only',1,tunnel,mutation,'DENIED'),('operator-slots-denied',2,provider,mutation,'DENIED')],
      'L13':[('provider-secret-write-denied',0,provider,mutation,'DENIED'),('tunnel-config-write-denied',1,tunnel,mutation,'DENIED'),('install-receipt-write-denied',2,provider,mutation,'DENIED'),('intended-service-read',0,provider,[1,0x20000],'ALLOWED')],
      'L14':[('service-modify-on-state-root',0,provider,[2,4,0x10000],'ALLOWED'),('inherited-service-modify',0,provider,[2],'ALLOWED')]}
    tests['L08'].append(('generic-read-map',6,normal,[1,8,0x80,0x20000,0x100000],'ALLOWED'))
    tests['L14'].append(('deny-only-service-group',0,'synthetic-deny-only-service',mutation,'DENIED'))
    for name,index,ctx,masks,expected in tests.get(case['id'],[]):
        selected=[x for x in rights if x['descriptor']==case['descriptors'][index] and x['contextName']==ctx and x['desiredAccess'] in masks]
        complete=len(selected)==len(masks) and all(x['comparison'] in ('MATCH','MISMATCH') for x in selected)
        valid=complete and all(x['gate']['outcome']==x['reference']['outcome']==expected for x in selected)
        if complete and not valid:mismatch=True
        checks.append(observation(name,'PASS' if valid else 'FAIL' if complete else 'BLOCKED',{'scope':'SYNTHETIC_DACL_ONLY','descriptorIndex':index,'context':ctx,'requestedMasks':masks,'expected':expected,'results':selected,'noActualPathOrTokenQualification':True},True,True))
    if case['id'] in ('L02','L03','L04','L05') and not mismatch:
        child_indexes=[1] if case['id'] in ('L02','L03','L04') else [0,1]
        for index in child_indexes:
            selected_child=[x for x in rights if x['descriptor']==case['descriptors'][index] and x['contextName']==normal]
            selected_parent=[x for x in rights if x['descriptor']==case['descriptors'][0] and x['contextName']==normal] if case['id']!='L05' else []
            child=[x['gate'] for x in selected_child];parent=[x['gate'] for x in selected_parent]
            decision=gate.classify_component(child,parent)
            # Reference-confirmed concrete grants justify a rejection observation.
            danger_child={2,4,0x10,0x40,0x100,0x10000,0x40000,0x80000}
            danger_parent={0x10,0x40,0x100,0x10000,0x40000,0x80000}
            demonstrated=any(x['comparison']=='MATCH' and x['reference']['outcome']=='ALLOWED' and x['desiredAccess'] in masks for selected,masks in ((selected_child,danger_child),(selected_parent,danger_parent)) for x in selected)
            expected='BLOCKED_EFFECTIVE_ACCESS' if demonstrated else 'BLOCKED_UNKNOWN'
            if decision!=expected:mismatch=True
            checks.append(observation('parent-child-route-classification-'+str(index),'FAIL' if decision!=expected else 'PASS' if demonstrated else 'BLOCKED',{'decision':decision,'expectedRejection':expected,'referenceConfirmedForbiddenGrant':demonstrated,'scope':'SYNTHETIC_REJECTION_ONLY_NO_SIBLING_OR_SCOPED_APPROVAL'},True,True))
    # Each normative named scenario stays blocked unless its specific proof exists.
    # Synthetic matches alone cannot close real tokens, owner/MIC or full-chain proof.
    row['subchecks']=planned(case,checks)
    row['status']='FAIL' if mismatch else 'BLOCKED'
    row['gateResult']='BLOCKED_UNKNOWN' if not comparable else 'SYNTHETIC_SEMANTICS_OBSERVED_NOT_PATH_QUALIFICATION'
    row['reason']='REFERENCE_GATE_MISMATCH' if mismatch else 'Supported synthetic DACL results recorded; required actual-token/unsupported/full-chain subchecks remain unqualified'
    return mismatch

def sentinel(h):return {'hash':h.hash(),'held':h.record()}
def fixtures(case,row):
    n=int(case['id'][1:]);done=[];base=fixture_root/case['id']
    row['subchecks']=done
    if n==18:
        h=win.hold_prepared_hardlink_directory(str(base),hardlink_preparation);held.append(h)
    else:create_dir(base)
    row['handles'].append(held[-1].record())
    if n in (15,22):
        h=create_file(base/'collision.txt');before=sentinel(h);row['preSentinel']=before
        try:
            win.new_file(str(base/'collision.txt'),b'forbidden overwrite')
            raise RuntimeError('EXCLUSIVE_CREATE_UNEXPECTED_SUCCESS')
        except win.Blocked as e:
            row['postSentinel']=sentinel(h)
            if before!=row['postSentinel']:raise RuntimeError('COLLISION_SENTINEL_CHANGED')
            expected=e.reason=='BLOCKED_COLLISION_OR_FILE_CREATE' and e.win32 in (80,183)
            done.append(observation('preexisting-file' if n==15 else 'receipt-collision','PASS' if expected else 'BLOCKED',{'error':str(e),'reason':e.reason,'win32':e.win32,'exactCollisionGuardReached':expected,'sentinelUnchanged':True,'destinationWriteProof':'CREATE_NEW failed at collision before write' if expected else 'UNQUALIFIED_UNRELATED_FAILURE'}))
        if n==15:
            directory_before=next(x for x in held if x.path==str(base)).record()
            try:win.new_directory(str(base))
            except win.Blocked as e:
                expected=e.reason=='BLOCKED_COLLISION_OR_DIRECTORY_CREATE' and e.win32 in (80,183)
                directory_after=next(x for x in held if x.path==str(base)).record()
                if directory_before!=directory_after:raise RuntimeError('DIRECTORY_COLLISION_SENTINEL_CHANGED')
                done.append(observation('preexisting-directory','PASS' if expected else 'BLOCKED',{'error':str(e),'reason':e.reason,'win32':e.win32,'before':directory_before,'after':directory_after,'exactCollisionGuardReached':expected}))
            else:raise RuntimeError('DIRECTORY_COLLISION_UNEXPECTED_SUCCESS')
        row['gateResult']='BLOCKED_COLLISION'
    elif n==16:
        target=create_file(base/'target.txt');row['preSentinel']=sentinel(target)
        # Single supported CreateSymbolicLink attempt with no privilege retry.
        path=base/'link.txt'
        if not win.CreateSymbolicLink(str(path),str(base/'target.txt'),0):
            done.append(observation('symlink','BLOCKED',f'CreateSymbolicLink unavailable WIN32_{win.C.get_last_error()}'))
        else:
            try:
                unexpected=win.Held(str(path));unexpected.close()
            except win.Blocked as e:done.append(observation('symlink','PASS' if e.reason=='BLOCKED_REPARSE' else 'BLOCKED',{'error':str(e),'reason':e.reason,'win32':e.win32,'exactReparseGuardReached':e.reason=='BLOCKED_REPARSE'}))
            else:raise RuntimeError('REPARSE_NOT_REJECTED')
        row['postSentinel']=sentinel(target)
        if row['preSentinel']!=row['postSentinel']:raise RuntimeError('REPARSE_TARGET_CHANGED')
        row['gateResult']='BLOCKED_REPARSE'
    elif n==17:
        # No filesystem API is called on rejected path candidates.
        bad=[str(base/'..'/'escape'),str(base)+':ads',r'\\server\share\x',r'\\?\C:\x',str(base/'x.'),str(base/'x '),str(base/'FOO~1'),str(base/'NUL')]
        for value in bad:
            try:win.canonical(value)
            except win.Blocked as e:done.append(observation('path-'+value,'PASS' if e.reason=='BLOCKED_NAMESPACE_ALIAS' else 'BLOCKED',str(e)))
            else:raise RuntimeError('ALIAS_ACCEPTED:'+value)
        duplicate=['a.txt','A.txt'];collision=len({s.casefold() for s in duplicate})!=len(duplicate)
        if not collision:raise RuntimeError('CASE_COLLISION_NOT_DETECTED')
        done.append(observation('case-collision','BLOCKED','Limited casefold equality observation; actual duplicate-inventory admission rejection not exercised.'));row['gateResult']='BLOCKED_ALIAS'
    elif n==18:
        # Preparation occurred before any Held locks existed, including retained
        # ancestor locks. This row invokes the unchanged actual rejection guard.
        initial=hardlink_preparation['initialFileSentinel']
        before={name:win.hardlink_fixture_sentinel(str(base/name)) for name in ('original.txt','alias.txt')}
        win.require_hardlink_same_object(initial,before)
        row['creationSentinel']=initial;row['preSentinel']=before
        row['fixturePreparation']={'order':'raw exclusive directories/file; close all creation/read handles; CreateHardLink; then first Held locks','beforeAnyHeldLock':True,'directories':hardlink_preparation['directories'],'untrustedObserverContinuity':'UNQUALIFIED'}
        exact=False
        try:
            unexpected=win.Held(str(base/'original.txt'));unexpected.close()
        except win.Blocked as e:
            exact=e.reason=='BLOCKED_HARDLINK' and e.win32 is None
            error={'error':str(e),'reason':e.reason,'win32':e.win32,'exactLinkCountGuardReached':exact}
        else:raise RuntimeError('HARDLINK_ACCEPTED')
        after={name:win.hardlink_fixture_sentinel(str(base/name)) for name in ('original.txt','alias.txt')}
        win.require_hardlink_same_object(initial,after)
        if before!=after:raise RuntimeError('HARDLINK_SAME_OBJECT_SENTINEL_CHANGED')
        row['postSentinel']=after
        error.update({'sameIdentitySentinelsUnchanged':True,'bothNamesReferToExclusiveCreatedIdentity':True,'fixtureOnlyObservationNoPathApproval':True})
        done.append(observation('link-count-greater-than-one','PASS' if exact else 'BLOCKED',error))
        done.append(observation('held-file-id','PASS',{'method':'read-only same-handle identity/descriptor/hash sentinels for both fixed names; no accepted Held file','exclusiveCreatedFileId':initial['identity']['fileId'],'volume':initial['identity']['volume'],'bothAliasIdsMatch':True,'beforeAfterGuardUnchanged':True,'pathApproval':False}))
        done.append(observation('same-bytes-insufficient','PASS' if exact else 'BLOCKED',{'bothAliasHashesEqualExclusiveCreatedHash':True,'sha256':initial['sha256'],'linkCountGuardRejectedDespiteSameBytes':exact,'pathApproval':False}))
        done.append(observation('all-alias-proof-unavailable','BLOCKED','Only two fixed disposable names were observed. No exhaustive adversarial alias, parent authority, observer, or operational continuity proof is supplied.'))
        row['gateResult']='BLOCKED_HARDLINK' if exact else 'BLOCKED_UNKNOWN'
    elif n==19:
        h=create_file(base/'at-create.txt');record=h.record();row['handles'].append(record)
        verified=win.verify_created(h)
        done.append(observation('exclusive-create','PASS',record))
        done.append(observation('explicit-protected-descriptor-at-create','PASS',{'nativeCreateNew':True,'saAtCreation':True,'exactReadbackVerification':verified,'scope':'CURRENT_HELD_OBJECT_OBSERVATION_ONLY'}))
        done.append(observation('trusted-owner','BLOCKED',{'ownerSidObserved':record['descriptor']['ownerSid'],'reason':'Expected owner verified on held object; no independent untrusted-token observer/creation-window proof.'}))
        row['gateResult']='BLOCKED_CONTINUITY'
    elif n==20:
        h=create_file(base/'held.txt');row['handles'].append(h.record());row['gateResult']='BLOCKED_CONTINUITY'
        done.append(observation('no-malicious-admin-resistance-claim','PASS','No untrusted OS token acquired; no substitution or parent rename attempted.'))
    elif n==21:
        h=create_file(base/'held.txt');replacement=create_file(base/'different.txt')
        if h.info['fileId']==replacement.info['fileId']:raise RuntimeError('IDENTITY_FIXTURE_NOT_DISTINCT')
        row['handles'] += [h.record(),replacement.record()]
        done.append(observation('path-handle-drift-injection','BLOCKED',{'differentObjectIdObserved':replacement.info,'heldIdObserved':h.verify(),'reason':'Limited identity observation only; no drift injected into an admission rejection function.'},True,True))
        row['preSentinel']=sentinel(h);row['postSentinel']=sentinel(h)
        done.append(observation('descriptor-from-same-handle','PASS',h.descriptor))
        done.append(observation('hash-from-same-handle','PASS',row['postSentinel']))
        row['gateResult']='BLOCKED_CONTINUITY'
    elif n==23:
        h=create_file(base/'pinned.txt',b'one pinned dummy byte sequence');same=create_file(base/'same-bytes.txt',b'one pinned dummy byte sequence')
        a,b=sentinel(h),sentinel(same)
        if a['hash']!=b['hash'] or a['held']['identity']['fileId']==b['held']['identity']['fileId']:raise RuntimeError('SAME_BYTE_FIXTURE_WRONG')
        done.append(observation('same-byte-untrusted-substitution','BLOCKED',{'heldSourceObserved':a,'otherObjectObserved':b,'reason':'Limited equal-byte/different-ID observation only; no untrusted substitution/rejection adapter exercised.'},True,True))
        row['gateResult']='BLOCKED_CONTINUITY'
    row['subchecks']=planned(case,done);row['status']='BLOCKED';row['reason']='Implemented local observations retained; required unavailable adversarial/token/continuity subchecks remain BLOCKED'

def static_cases(case,row):
    n=int(case['id'][1:]);done=[]
    row['subchecks']=done
    if n==24:
        # In-memory negative controls; never load wrong candidate or rewrite frozen source.
        controls={'wrong-external-manifest-pin':digest(raw)!='0'*64,'wrong-external-bootstrap-pin':digest(verified_bytes['source/Bootstrap.ps1'])!='0'*64}
        for k,v in controls.items():
            if not v:raise RuntimeError('PIN_NEGATIVE_CONTROL')
            done.append(observation(k,'BLOCKED','Limited in-memory digest inequality only; no rejection through actual bootstrap admission was exercised.',True,True))
        for name in ('source/gate.py','source/windows_api.py','source/run.py'):
            changed=verified_bytes[name]+b'\n# simulated stale byte\n'
            if digest(changed)==pins[name]['sha256']:raise RuntimeError('STALE_PIN_NOT_DETECTED')
            done.append(observation('stale-'+name,'BLOCKED','Limited changed-byte hash observation; admission rejection not exercised and no candidate loaded.',True,True))
        extra=allowed|{'adjacent-approval.json'}
        if extra==allowed:raise RuntimeError('EXTRA_CONTROL')
        done.append(observation('extra-manifest-entry','BLOCKED','Limited unequal-set observation; extra-inventory rejection not exercised.',True,True))
        row['gateResult']='BLOCKED_EXTERNAL_PIN_OR_EXTRA'
    elif n==25:
        done.append(observation('block-before-add-type-native-launch','BLOCKED','No compiler/Add-Type path exists; no protected dependency-rejection adapter or qualified launch chain demonstrated.'))
        row['gateResult']='BLOCKED_LAUNCH_CHAIN_UNQUALIFIED'
    elif n==26:
        done.append(observation('unconditional-admission','BLOCKED',{'reason':'Historical AST/prefix adapter does not qualify the revised source-only launch chain. Independent frozen-source review and later authorized local verification are required.','sourceOnlyDelivery':'run.py exits before imports; Bootstrap.ps1 rejects before launch; no argument or acceptance flag enables this delivered revision.','historicalStaticPassUnchanged':True},False))
        row['gateResult']='BLOCKED_REVISED_ADMISSION_NOT_VERIFIED';row['status']='BLOCKED'
    elif n==27:
        # Avoid spawning a native child merely to claim containment. Timeout/nonzero
        # controls below are explicitly inert simulations, not native process evidence.
        done.append(observation('timeout-injection','BLOCKED',{'reason':'Inert literal observation only; no native timeout injected','nativeChildLaunched':False},True,True))
        done.append(observation('nonzero-child-injection','BLOCKED',{'reason':'Inert literal observation only; no native nonzero child injected'},True,True))
        done.append(observation('containment-failure-injection','BLOCKED',{'reason':'No native containment failure injected','limitedActualJobObservation':job.ensure_only_runner()},True,True))
        row['gateResult']='BLOCKED_CONTAINMENT_NATIVE_INJECTION_UNQUALIFIED'
    elif n==28:
        done.append(observation('sole-runner-job-membership','PASS',job.ensure_only_runner()))
        done.append(observation('owned-job-empty','BLOCKED','Runner is still executing. Parent must verify its exit and zero owned survivors; no post-exit proof from inside runner.'))
        # Parent supplied baseline remains unmodified and is hashed, not reinterpreted as our run.
        baseline=ROOT/'preservation-before.json'
        if baseline.exists():
            done.append(observation('parent-preservation-baseline','BLOCKED',{'observedSha256':digest(baseline.read_bytes()),'role':'parent evidence not externally bound or compared by this harness; limited hash observation only'}))
        done.append(observation('roots-readonly-metadata-if-accessible','BLOCKED',{'status':'UNQUALIFIED','reason':'No operational root readback adapter invoked or simulated; separate authorization and implementation required.'},False))
        # No SCM route implemented: no mutation or substitute enumeration.
        row['preservationDelta']['services']='UNQUALIFIED_PARENT_READBACK_REQUIRED'
        row['gateResult']='BLOCKED_PRESERVATION_PARTIAL'
    row['subchecks']=planned(case,done)
    if n!=26:row['status']='BLOCKED'
    row['reason']='Static/inert or limited actual observations only; unimplemented required proof remains BLOCKED'

def new_row(case):
    row={'caseId':case['id'],'utcStart':None,'status':'NOT_RUN','reason':stop,'sourceManifestSha256':args.manifest,'bootstrapSha256':args.bootstrap,'policySha256':pins['source/policy/PATH-SPECIFIC-GATE-REVISION.md']['sha256'],'harnessSha256':pins['source/run.py']['sha256'],'fixtureNamespace':str(fixture_root/case['id']),'fixtureDescriptors':case['descriptors'],'individualRights':[],'tokenProvenance':{'actualTokens':'UNQUALIFIED_NOT_ACQUIRED'},'handles':[],'preSentinel':{'status':'NOT_APPLICABLE_OR_NOT_CAPTURED'},'postSentinel':{'status':'NOT_APPLICABLE_OR_NOT_CAPTURED'},'actual':False,'simulated':False,'operationalEvidence':False,'preservationDelta':{'operational':'NOT_INDEPENDENTLY_PROVEN','scmCalls':0,'credentialsAccessed':False,'hostedAttemptsSpent':0},'subchecks':[]}
    row['gateResult']='NOT_RUN'
    row['individualRights']=[{'tokenContext':ctx,'name':r['name'],'desiredAccess':int(r['mask'],16),'reference':{'outcome':'UNQUALIFIED' if not stop else 'NOT_RUN','reason':'No token/reference requested by this fixture or prerequisite unavailable'},'gate':{'outcome':'NOT_RUN'},'comparison':'NOT_RUN'} for ctx in case['contexts'] for r in matrix['individualRights']]
    return row

rows=[new_row(case) for case in matrix['cases']]
primary=None;phase='NATIVE_MEMBERSHIP';preparation_failure=None;secondary_cleanup=[]
try:
    job=win.Job(args.parent_job);job.ensure_only_runner()
    phase='SEMANTIC'
    # Buffer bounded semantic receipts. No dummy directory/file exists yet.
    for case,row in zip(matrix['cases'][:14],rows[:14]):
        if stop:break
        row['actual']=True;row['utcStart']=utc();row['simulated']=True
        try:
            if semantic(case,row):
                stop='SEMANTIC_REFERENCE_GATE_MISMATCH_STOP'
                if primary is None:primary={'phase':phase,'caseId':case['id'],'error':stop}
        except BaseException as error:
            row.update(status='BLOCKED',reason=str(error),gateResult='BLOCKED_SEMANTIC_ERROR')
            primary={'phase':phase,'caseId':case['id'],'type':type(error).__name__,'error':str(error)[:4096]}
            stop='SEMANTIC_CHECK_ERROR_STOP'
        row['utcEnd']=utc()
        if win.cleanup_snapshot()['errorCount']:stop='SEMANTIC_CLEANUP_FAILURE_STOP'
        if time.monotonic()>deadline-5:stop='CHILD_LIFETIME_BOUND_STOP'
    if win.cleanup_snapshot()['errorCount']:stop='SEMANTIC_CLEANUP_FAILURE_STOP'
    if not stop:
        phase='L18_PREPARATION'
        try:
            # No Held ancestor lock until exclusive creation is closed and linked.
            hardlink_preparation=win.prepare_hardlink_scenario(HARDLINK_FIXTURE_DATA)
            payload+=len(HARDLINK_FIXTURE_DATA)
            if win.cleanup_snapshot()['errorCount']:raise win.Blocked('PREPARATION_CLEANUP_FAILURE')
        except BaseException as error:
            preparation_failure={'type':type(error).__name__,'error':str(error)[:4096],
                                 'reason':getattr(error,'reason',None),'win32':getattr(error,'win32',None),
                                 'details':getattr(error,'details',None),'phase':phase}
            primary=preparation_failure;stop='L18_PREPARATION_FAILURE_STOP'
            # L18 preparation was entered; L15-L17 and L19+ were never entered.
            rows[17].update(actual=True,utcStart=utc(),status='BLOCKED',gateResult='BLOCKED_PREPARATION',
                            reason=stop,preparationFailure=preparation_failure)
    if not stop:
        phase='PHYSICAL_CASES'
        h=win.hold_prepared_hardlink_directory(str(fixture_root),hardlink_preparation);held.append(h)
        for case,row in zip(matrix['cases'][14:],rows[14:]):
            if stop:break
            row['actual']=True;row['utcStart']=utc()
            try:
                if case['id']<='L23':fixtures(case,row)
                else:static_cases(case,row)
            except BaseException as error:
                row.update(status='BLOCKED',reason=str(error)[:4096],gateResult='BLOCKED_CASE_FAILURE',
                           sourceError={'type':type(error).__name__,'reason':getattr(error,'reason',None),'win32':getattr(error,'win32',None)})
                if primary is None:primary={'phase':phase,'caseId':case['id'],'error':str(error)[:4096]}
                stop='CASE_FAILURE_STOP'
            row['utcEnd']=utc()
            if win.cleanup_snapshot()['errorCount']:stop='CLEANUP_FAILURE_STOP'
            if time.monotonic()>deadline-5:stop='CHILD_LIFETIME_BOUND_STOP'
except BaseException as error:
    if primary is None:primary={'phase':phase,'type':type(error).__name__,'error':str(error)[:4096]}
    stop='HARNESS_FAILURE_STOP'
finally:
    # All close results are collected, never replace primary, never retried.
    for h in reversed(held):
        try:h.close()
        except BaseException as error:
            if len(secondary_cleanup)<128:secondary_cleanup.append({'phase':'HANDLE_CLEANUP','type':type(error).__name__,'error':str(error)[:4096]})
    held.clear()
    if job:job.close()
    for case,row in zip(matrix['cases'],rows):
        row['subchecks']=planned(case,row['subchecks'],status='NOT_RUN' if not row['actual'] else 'BLOCKED')
        if not row['actual']:row.update(status='NOT_RUN',reason=stop or 'NOT_ENTERED',gateResult='NOT_RUN')
    report={'schema':2,'status':'BLOCKED','cases':rows,'total':28,'counts':{status:sum(row['status']==status for row in rows) for status in ('PASS','FAIL','BLOCKED','NOT_RUN')},'performed':sum(row['actual'] for row in rows),'primaryError':primary,
            'preparationFailure':preparation_failure,'secondaryCleanupErrors':secondary_cleanup,'cleanup':win.cleanup_snapshot(),
            'caseEntryAccounting':'HARNESS_ONLY_PARENT_STARTUP_FAILURE_CANNOT_INVENT_CASES',
            'operationalReadbacks':'UNQUALIFIED','hostedAttemptsRemaining':48,'executionQualification':False}
    try:
        # Separate evidence destination; no writes into a rejected fixture path.
        create_dir(run_out)
        for row in rows:write_evidence(row['caseId']+'.json',row)
        write_evidence('AGGREGATE.json',report)
        write_evidence('EVIDENCE-MANIFEST.json',{'schema':2,'files':list(evidence),'sourceManifestSha256':args.manifest,'parentEnvelopeRequired':True})
    except BaseException as error:
        report['evidenceFailure']={'type':type(error).__name__,'error':str(error)[:4096]}
    finally:
        for h in reversed(held):
            try:h.close()
            except BaseException as error:
                if len(secondary_cleanup)<128:secondary_cleanup.append({'phase':'EVIDENCE_CLEANUP','type':type(error).__name__,'error':str(error)[:4096]})
        report['cleanup']=win.cleanup_snapshot()
        # Full receipt set remains available to bounded parent capture on evidence collision.
        data=json.dumps(report)
        if len(data.encode('utf-8'))<=8*1024*1024:print(data)
        else:print(json.dumps({'status':'BLOCKED_REPORT_BOUND','total':28,'counts':{status:sum(row['status']==status for row in rows) for status in ('PASS','FAIL','BLOCKED','NOT_RUN')},'performed':sum(row['actual'] for row in rows),'primaryError':primary,'cleanup':win.cleanup_snapshot(),'caseRecordsRetainedInOwnedEvidenceOnly':len(evidence)}))
        finished=True
