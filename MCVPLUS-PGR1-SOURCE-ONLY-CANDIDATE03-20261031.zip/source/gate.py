"""Conservative finite semantic gate, independent of Windows reference.
evaluate/classify_component remain synthetic rejection machinery. The read-only
operational router requires an already pinned path_policy module and still blocks
incomplete PG-R1 semantics and missing operational inputs. UNTESTED source only.
"""
import re

ALIASES={'BA':'S-1-5-32-544','SY':'S-1-5-18','WD':'S-1-1-0','AU':'S-1-5-11','BU':'S-1-5-32-545','CO':'S-1-3-0','OW':'S-1-3-4'}
RIGHTS={'FA':0x1f01ff,'FR':0x120089,'FW':0x120116,'FX':0x1200a0,'GA':0x10000000,'GR':0x80000000,'GW':0x40000000,'GX':0x20000000,'WD':0x40000,'WO':0x80000,'SD':0x10000,'RC':0x20000}
def map_rights(value):
    x=value&0x0fffffff
    for bit,m in ((0x10000000,0x1f01ff),(0x80000000,0x120089),(0x40000000,0x120116),(0x20000000,0x1200a0)):
        if value&bit:x|=m
    return x
def mask(text):
    if text.startswith('0x'):return int(text,16)
    if len(text)%2:raise ValueError('rights grammar')
    n=0
    for i in range(0,len(text),2):n|=RIGHTS[text[i:i+2]]
    return n
def evaluate(sddl,context,desired):
    result={'requested':desired,'outcome':'BLOCKED_UNKNOWN','qualified':False,'operationalEvidence':False}
    try:
        if type(desired) is not int or desired not in {1,2,4,8,0x10,0x20,0x40,0x80,0x100,0x10000,0x20000,0x40000,0x80000,0x100000}:
            raise ValueError('individual concrete requested right required')
        if context.get('restricted') or context.get('privileges') or 'S:' in sddl:raise ValueError('MIC/restricted/privilege unsupported')
        owner=re.search(r'^O:(.*?)(?=G:|D:)',sddl)
        if not owner or ALIASES.get(owner[1],owner[1]) not in ('S-1-5-18','S-1-5-32-544'):raise ValueError('owner authority unsupported')
        if 'D:' not in sddl or 'NO_ACCESS_CONTROL' in sddl:raise ValueError('null DACL')
        aces=re.findall(r'\(([^()]*)\)',sddl)
        dacl=sddl.split('D:',1)[1]
        flags=re.sub(r'\([^()]*\)','',dacl)
        if flags not in ('','P','AI','PAI','AR','PAR'):raise ValueError('DACL grammar')
        allow=set(context.get('enabled',[]))|{context['user']}
        deny=allow|set(context.get('denyOnly',[]))
        known=deny|{'S-1-5-18','S-1-5-32-544','S-1-5-80-1001-1002-1003-1004-1005','S-1-5-80-2001-2002-2003-2004-2005','S-1-5-80-3001-3002-3003-3004-3005'}
        parsed=[]
        for ace in aces:
            p=ace.split(';')
            if len(p)!=6 or p[0] not in ('A','D') or p[3] or p[4]:raise ValueError('ACE type/claim unsupported')
            sid=ALIASES.get(p[5],p[5])
            if sid not in known or sid in ('S-1-3-0','S-1-3-4'):raise ValueError('principal/owner-rights unresolved')
            aceflags=[p[1][i:i+2] for i in range(0,len(p[1]),2)]
            if any(f not in ('OI','CI','IO','ID','NP') for f in aceflags):raise ValueError('ACE flag unsupported')
            parsed.append((p[0],aceflags,map_rights(mask(p[2])),sid))
        remaining=map_rights(desired);granted=0
        for kind,flags,bits,sid in parsed:
            if 'IO' in flags:continue
            hit=bits&remaining
            if kind=='D' and sid in deny and hit:
                return dict(result,outcome='DENIED',qualified=True,granted=granted,reason='DACL_DENY')
            if kind=='A' and sid in allow:granted|=hit;remaining&=~hit
        return dict(result,outcome='ALLOWED' if remaining==0 else 'DENIED',qualified=True,granted=granted,reason='FINITE_COMMON_ACE_DACL_ONLY')
    except (ValueError,KeyError,IndexError) as e:return dict(result,reason=str(e))

def classify_component(child_results,parent_results):
    """Rejection-only finite DACL observation, never a capability approval engine.

    A qualified individual grant can demonstrate a forbidden route independently.
    Empty/incomplete/combined/unknown inputs cannot demonstrate protection. Even
    complete denials lack typed path/service/token/authority/continuity proof.
    """
    if not isinstance(child_results,list) or not isinstance(parent_results,list):
        return 'BLOCKED_UNKNOWN'
    child_mutation={2,4,0x10,0x40,0x100,0x10000,0x40000,0x80000}
    parent_danger={0x10,0x40,0x100,0x10000,0x40000,0x80000}
    for results,forbidden in ((child_results,child_mutation),(parent_results,parent_danger)):
        for result in results:
            if not isinstance(result,dict):continue
            right=result.get('requested')
            if (type(right) is int and right in forbidden and
                result.get('qualified') is True and result.get('outcome')=='ALLOWED'):
                return 'BLOCKED_EFFECTIVE_ACCESS'
    # No scoped/sibling flags and no PASS path. Parent insertion alone does not
    # establish replacement, nor a SIBLING_CREATE_ONLY exception.
    return 'BLOCKED_UNKNOWN'

def operational_decision(chain=None,tokens=None):
    """Read-only PG-R1 inspection, never staging/Setup authorization.

    path_policy and its native dependency must already be installed in sys.modules
    from independently pinned bytes by the sealed loader. Do not resolve an
    adjacent Python module here. Missing loader admission is a blocked input.
    """
    import sys
    policy=sys.modules.get('path_policy')
    if policy is None:
        return {'outcome':'BLOCKED_LAUNCH_CHAIN_UNQUALIFIED','qualified':False,
                'operationalEvidence':False,'reason':'PINNED_PATH_POLICY_NOT_LOADED'}
    return policy.check_chain(chain,tokens if tokens is not None else {})
