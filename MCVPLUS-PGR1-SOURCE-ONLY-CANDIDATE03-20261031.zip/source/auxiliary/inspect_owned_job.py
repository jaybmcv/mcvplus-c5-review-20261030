"""Source-only future auxiliary: exact held job and original process identity.

This is not a retroactive correction to historical inspector evidence. Its own
PID/start/executable/hash/lifetime/exit/capture evidence belongs to the parent
ContainedLaunch session. Never discover, enumerate or terminate other processes.
"""
raise RuntimeError('SOURCE-ONLY-NOT-AUTHORIZED')

import argparse
import ctypes as c
from ctypes import wintypes as w
import datetime
import json
import sys


EXPECTED_JOB = 'PG-R1-mcvplus-pgr1-source-only-20261031-candidate03-runner'
k = c.WinDLL('kernel32', use_last_error=True)
OpenJob = k.OpenJobObjectW
OpenJob.argtypes = [w.DWORD, w.BOOL, w.LPCWSTR]
OpenJob.restype = w.HANDLE
QueryJob = k.QueryInformationJobObject
QueryJob.argtypes = [w.HANDLE, c.c_int, c.c_void_p, w.DWORD, c.POINTER(w.DWORD)]
QueryJob.restype = w.BOOL
OpenProcess = k.OpenProcess
OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
OpenProcess.restype = w.HANDLE
GetTimes = k.GetProcessTimes
GetTimes.argtypes = [w.HANDLE] + [c.POINTER(c.c_ulonglong)] * 4
GetTimes.restype = w.BOOL
Wait = k.WaitForSingleObject
Wait.argtypes = [w.HANDLE, w.DWORD]
Wait.restype = w.DWORD
Close = k.CloseHandle
Close.argtypes = [w.HANDLE]
Close.restype = w.BOOL


class Pids(c.Structure):
    _fields_ = [('assigned', w.DWORD), ('count', w.DWORD), ('ids', c.c_size_t * 16)]


def inspect_exact(job_name, expected_pid, expected_start):
    result = {
        'schema': 2,
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'job': job_name,
        'expectedPid': expected_pid,
        'expectedStartFileTimeUtc': str(expected_start),
        'status': 'BLOCKED_UNPROVEN',
        'jobStatus': 'BLOCKED_NOT_QUERIED',
        'originalIdentityStatus': 'BLOCKED_NOT_QUERIED',
        'scope': 'Exact held job query and exact PID/start only; no sweep or mutation',
        'mutation': False,
        'operationalEvidence': False,
        'cleanupErrors': [],
    }
    # Parent retains this exact named job until this inspector exits. Absent job
    # is a failure here: it does not establish an empty held job.
    job = OpenJob(4, False, job_name)
    if not job:
        result.update(jobStatus='BLOCKED_HELD_JOB_UNAVAILABLE', openJobError=c.get_last_error())
        return result
    try:
        pids = Pids()
        if not QueryJob(job, 3, c.byref(pids), c.sizeof(pids), None):
            result.update(jobStatus='BLOCKED_JOB_QUERY', queryJobError=c.get_last_error())
        elif pids.count > 16 or pids.count > pids.assigned:
            result.update(jobStatus='BLOCKED_JOB_PID_LIST_TRUNCATED', count=pids.count, assigned=pids.assigned)
        else:
            ids = list(pids.ids[:pids.count])
            result.update(pids=ids, assigned=pids.assigned,
                          jobStatus='EMPTY_HELD_JOB' if not ids else 'BLOCKED_JOB_NOT_EMPTY')
    finally:
        if not Close(job):
            result['cleanupErrors'].append({'handle': 'job', 'win32': c.get_last_error()})

    process = OpenProcess(0x00100000 | 0x00001000, False, expected_pid)
    if not process:
        error = c.get_last_error()
        # ERROR_INVALID_PARAMETER for an otherwise admitted PID means absent.
        # Access denied, transient errors and privilege failures never do.
        result.update(openProcessError=error,
                      originalIdentityStatus='ORIGINAL_PID_ABSENT' if error == 87 else 'BLOCKED_PROCESS_OPEN')
    else:
        try:
            creation = c.c_ulonglong()
            exit_time = c.c_ulonglong()
            kernel = c.c_ulonglong()
            user = c.c_ulonglong()
            if not GetTimes(process, c.byref(creation), c.byref(exit_time), c.byref(kernel), c.byref(user)):
                result.update(originalIdentityStatus='BLOCKED_PROCESS_TIMES', processTimesError=c.get_last_error())
            else:
                result['observedStartFileTimeUtc'] = str(creation.value)
                if creation.value != expected_start:
                    result['originalIdentityStatus'] = 'PID_REUSED_ORIGINAL_IDENTITY_ABSENT'
                else:
                    # An exact original process object still open elsewhere can
                    # be observed signaled after exit; distinguish it from absent.
                    wait = Wait(process, 0)
                    result.update(processWait=wait,
                                  originalIdentityStatus='ORIGINAL_IDENTITY_EXITED' if wait == 0 else 'BLOCKED_ORIGINAL_IDENTITY_PRESENT')
        finally:
            if not Close(process):
                result['cleanupErrors'].append({'handle': 'process', 'win32': c.get_last_error()})
    identity_closed = result['originalIdentityStatus'] in (
        'ORIGINAL_PID_ABSENT', 'PID_REUSED_ORIGINAL_IDENTITY_ABSENT', 'ORIGINAL_IDENTITY_EXITED')
    if result['jobStatus'] == 'EMPTY_HELD_JOB' and identity_closed and not result['cleanupErrors']:
        # The exact field originalIdentityStatus retains exited vs absent.
        result['status'] = 'EMPTY_JOB_AND_ORIGINAL_PROCESS_NOT_RUNNING'
    return result


def main():
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--job', required=True)
    parser.add_argument('--expected-pid', required=True, type=int)
    parser.add_argument('--expected-start-filetime', required=True, type=int)
    args = parser.parse_args()
    if args.job != EXPECTED_JOB or not 0 < args.expected_pid <= 0xffffffff or args.expected_start_filetime <= 0:
        raise RuntimeError('EXACT_OWNED_IDENTITY_REQUIRED')
    result = inspect_exact(args.job, args.expected_pid, args.expected_start_filetime)
    print(json.dumps(result, sort_keys=True, ensure_ascii=True))
    return 0 if result['status'] == 'EMPTY_JOB_AND_ORIGINAL_PROCESS_NOT_RUNNING' else 3


if __name__ == '__main__':
    sys.exit(main())
