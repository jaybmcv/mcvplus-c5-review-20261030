[CmdletBinding()]
param(
 [Parameter(Mandatory)][hashtable]$BootstrapArguments,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedCoordinatorSha256,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedBootstrapSha256
)
throw 'SOURCE-ONLY-NOT-AUTHORIZED'
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$root='D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate03'
# Future supervisor must independently own/protect/provision this empty store.
# This adapter never creates, repairs or adopts operational roots or ACLs.
$destination=$root+'\parent-evidence'
$primary=$null;$capturedPrimary=$null;$capturedBootstrapBytes=$null
$capturedBootstrapBase64=$null;$bootstrapResult=$null;$manifestIdentity=$null
$secondary=New-Object 'Collections.Generic.List[object]'
$inventory=New-Object 'Collections.Generic.List[object]'
$script:storeAdmitted=$false;$script:evidenceRejected=$false;$claimOwned=$false
$phase='EVIDENCE_ADMISSION';$streams=@()
function Reject-EvidenceStore {
 $script:evidenceRejected=$true
 $script:storeAdmitted=$false
}
function Get-Identity([byte[]]$Bytes) {
 $sha=[Security.Cryptography.SHA256]::Create()
 try {return @{bytes=$Bytes.Length;sha256=[BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-','').ToLowerInvariant()}} finally {$sha.Dispose()}
}
function Write-Exclusive([string]$Name,[byte[]]$Bytes) {
 if (!$script:storeAdmitted -or $script:evidenceRejected -or $Name -cnotmatch '^[A-Za-z0-9.-]+$' -or $Bytes.Length -gt 256MB) {
  Reject-EvidenceStore
  throw 'EVIDENCE_NOT_ADMITTED_REJECTED_OR_BOUND'
 }
 $stream=$null;$writeFailure=$null
 try {
  # One CREATE_NEW attempt. Any collision/write/flush/close failure revokes ALL
  # subsequent store writes, including envelope/manifest finalization.
  $stream=[IO.File]::Open(($destination+'\'+$Name),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  $stream.Write($Bytes,0,$Bytes.Length);$stream.Flush($true)
 } catch {
  $writeFailure=$_
  Reject-EvidenceStore
  throw
 } finally {
  if($stream) {
   try {$stream.Dispose()} catch {
    Reject-EvidenceStore
    if($secondary.Count -lt 128){$secondary.Add(@{phase='EVIDENCE_CLOSE';type=$_.Exception.GetType().FullName;message=$_.Exception.Message})}
    if(!$writeFailure){throw}
   }
  }
 }
 $identity=Get-Identity $Bytes
 $record=@{path=$Name;bytes=$identity.bytes;sha256=$identity.sha256;exclusive=$true;flushReturned=$true}
 $inventory.Add($record);return $record
}
try {
 # This narrow readback is NOT complete held-ancestor/protected loader admission.
 # That missing supervisor source/evidence remains an irrevocable qualifier.
 $item=Get-Item -LiteralPath $destination -Force
 if(!$item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'REJECTED_EVIDENCE_DESTINATION'}
 $acl=Get-Acl -LiteralPath $destination
 if(!$acl.AreAccessRulesProtected -or $acl.Owner -notin @('BUILTIN\Administrators','NT AUTHORITY\SYSTEM')){throw 'UNPROTECTED_EVIDENCE_DESTINATION'}
 foreach($rule in $acl.Access) {
  $sid=$rule.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
  if($rule.AccessControlType -ne 'Allow' -or $sid -notin @('S-1-5-32-544','S-1-5-18')){throw 'UNQUALIFIED_EVIDENCE_ACL'}
 }
 # An occupied destination is rejected before even an attempt claim is written.
 if(@(Get-ChildItem -LiteralPath $destination -Force).Count -ne 0){throw 'COLLIDED_NONEMPTY_EVIDENCE_DESTINATION'}
 $phase='SELF_AND_BOOTSTRAP_PREFLIGHT'
 foreach($binding in @(@($PSCommandPath,$ExpectedCoordinatorSha256),@($root+'\source\Bootstrap.ps1',$ExpectedBootstrapSha256))) {
  $held=[IO.File]::Open($binding[0],[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read);$streams+=,$held
  $sha=[Security.Cryptography.SHA256]::Create()
  try{$observed=[BitConverter]::ToString($sha.ComputeHash($held)).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
  if($observed -cne $binding[1]){throw 'INDEPENDENT_PARENT_PIN_MISMATCH'}
 }
 $phase='EXCLUSIVE_ATTEMPT_CLAIM'
 $script:storeAdmitted=$true
 $claim=@{schema=1;candidate=$root;sourceManifestPin=$BootstrapArguments.ExpectedSourceManifestSha256;nonce=[Guid]::NewGuid().ToString('N');status='UNTESTED_NOT_QUALIFICATION'}
 $null=Write-Exclusive 'PARENT-ATTEMPT-CLAIM.json' ([Text.Encoding]::UTF8.GetBytes(($claim|ConvertTo-Json)))
 $claimOwned=$true
 $phase='CHILD_NATIVE_CAPTURE_TERMINATION'
 $text=(& ($root+'\source\Bootstrap.ps1') @BootstrapArguments | Out-String)
 $bytes=[Text.Encoding]::UTF8.GetBytes($text)
 if($bytes.Length -gt 64MB){throw 'BOOTSTRAP_ENVELOPE_CAPTURE_BOUND'}
 # Retain raw captured bytes AND parse BEFORE any evidence write. Even a first
 # write collision/flush failure returns original primary/native data in memory.
 $capturedBootstrapBytes=$bytes
 $capturedBootstrapBase64=[Convert]::ToBase64String($capturedBootstrapBytes)
 $bootstrapResult=$text|ConvertFrom-Json
 $capturedPrimary=$bootstrapResult.primaryError
 if($capturedPrimary){$primary=$capturedPrimary}
 $null=Write-Exclusive 'bootstrap-envelope.json' $capturedBootstrapBytes
 foreach($role in @('runner','inspector')) {
  $native=$bootstrapResult.$role
  if($null -eq $native){continue}
  foreach($channel in @('StandardOutput','StandardError')) {
   $encodedProperty=$channel+'Base64'
   $capture=[Convert]::FromBase64String([string]$native.$encodedProperty)
   if($capture.Length -gt 8MB){Reject-EvidenceStore;throw 'NATIVE_RAW_CAPTURE_BOUND'}
   $null=Write-Exclusive ($role+'-'+$channel+'.bin') $capture
  }
 }
} catch {
 $caught=@{phase=$phase;type=$_.Exception.GetType().FullName;message=$_.Exception.Message}
 # Never attempt finalizer writes after rejection or a pre-claim failure.
 Reject-EvidenceStore
 if($capturedPrimary) {
  $primary=$capturedPrimary
  if($secondary.Count -lt 128){$secondary.Add($caught)}
 } else {$primary=$caught}
} finally {
 foreach($held in $streams) {
  try{$held.Dispose()}catch{if($secondary.Count -lt 128){$secondary.Add(@{phase='SOURCE_STREAM_CLOSE';type=$_.Exception.GetType().FullName;message=$_.Exception.Message})}}
 }
}
$envelope=@{schema=2;status='BLOCKED_UNTESTED';primaryError=$primary;secondaryCleanupErrors=@($secondary);
 bootstrap=$bootstrapResult;capturedBootstrapBase64=$capturedBootstrapBase64;
 capturedBootstrapIdentity=if($null -ne $capturedBootstrapBytes){Get-Identity $capturedBootstrapBytes}else{$null};
 sourceManifestPin=$BootstrapArguments.ExpectedSourceManifestSha256;coordinatorPin=$ExpectedCoordinatorSha256;bootstrapPin=$ExpectedBootstrapSha256;
 evidenceStoreRejected=$script:evidenceRejected;claimOwned=$claimOwned;files=@($inventory);
 outputInventoryScope='SUCCESSFULLY_FLUSHED_OWNED_FILES_ONLY_NOT_FULL_CENSUS';
 caseEntry='ONLY_RUNNER_RECORDS_MAY_ASSERT_ENTRY';preservation='UNQUALIFIED_NO_OPERATIONAL_OR_ORIGINAL_RUN_READBACK';
 operationalRoots='UNQUALIFIED';services='UNQUALIFIED';remote='UNQUALIFIED';retryCount=0;
 limits=@('protected parent toolchain/held ancestor-relative store admission missing','no independent interruptible outer OS supervisor',
 'process death before flush cannot guarantee envelope','parameter binding and source-only guard precede adapter',
 'rejected destinations receive NO further writes; external supervisor must retain returned captures',
 'captured pipe bytes may be partial; native CaptureComplete remains authoritative')}
if($script:storeAdmitted -and $claimOwned -and !$script:evidenceRejected) {
 try {
  $null=Write-Exclusive 'PARENT-ENVELOPE.json' ([Text.Encoding]::UTF8.GetBytes(($envelope|ConvertTo-Json -Depth 40)))
  $manifestIdentity=Write-Exclusive 'PARENT-EVIDENCE-MANIFEST.json' ([Text.Encoding]::UTF8.GetBytes((@{schema=1;files=@($inventory);status='UNTESTED';executionAuthorized=$false}|ConvertTo-Json -Depth 12)))
 } catch {
  Reject-EvidenceStore
  if($secondary.Count -lt 128){$secondary.Add(@{phase='FINAL_EVIDENCE_WRITE';type=$_.Exception.GetType().FullName;message=$_.Exception.Message})}
 }
}
# Latest write/cleanup failures remain visible even if the durable envelope could
# not be written. No collided destination fallback, retry, repair, or deletion.
[pscustomobject]@{envelope=$envelope;manifestIdentity=$manifestIdentity;finalSecondaryErrors=@($secondary);
 evidenceStoreRejected=$script:evidenceRejected;capturedBootstrapBase64=$capturedBootstrapBase64;
 bootstrap=$bootstrapResult;durableManifestCompleted=($null -ne $manifestIdentity)}|ConvertTo-Json -Depth 40
