# Exact path policy source - UNTESTED and partial

This is an authoring description, not independent review or runtime evidence.
No policy/checker/helper/launcher was executed, imported, compiled, syntax/AST
parsed or tested. No token, ACL, SCM or installed-root probe was performed.

gate.evaluate and classify_component retain the predecessor's independent finite
synthetic semantics and rejection-only behavior. gate.operational_decision now
routes into an already registered path_policy module; it will not import a helper
from an unchecked adjacent pathname. run.py's dormant loader registers the native
and path modules in dependency order from pinned in-memory bytes. Its unconditional
delivery guard remains before imports.

path_policy.check_chain and inspect_component implement real held-chain relation,
volume/type/descriptor and per-individual-right inspection. They call
permission_check.inspect_access on actual NativeToken instances for the child and
parent separately. Token class labels indicate required coverage; labels do not
classify a token as trusted or manufacture a service identity. Missing or unknown
classes and any unqualified right block. Actual class provenance remains a blocker.

removal_routes explicitly treats DELETE on the child and DELETE_CHILD on the
parent as alternative removal paths. A service's mutable-data ceiling cannot excuse
authority on the protected parent. Rename/move/replacement still requires complete
destination/volume/redirect semantics; source does not infer replacement from one
create bit or issue a sibling-create exception.

capability_ceiling describes rights permitted by the normative exact state paths.
It issues no ACL changes or grants. It recognizes only the bounded Postgres data
domain, exact provider slot/log file names, exact provider secret and tunnel
config/credential paths, and exact traversal directories. Every other service path
has zero ceiling until a complete reviewed installed executable/config/dependency
closure exists. No recursive grant over code or all services is emitted. A data
directory's add-file bit alone cannot enforce allowed filenames, so future-child
inventory/runtime-name proof remains blocked.

descriptor_principal_routes walks all decoded standard ALLOW trustees, including
principals absent from every representative token, against their path ceilings.
It requires exact native service-name/SID roundtrip resolution for a service
exception. Unknown trustees, nontrusted owner authority, inherited future-child
scope, unsupported descriptors and ceiling violations block. It conservatively
does not assume a deny cancels a broad allow for every possible membership/claim
combination. This is a rejecting global scan, not complete universal group/claim
analysis; no caller flag can turn it into such a proof.

staging_pins independently binds the known reference map/revision digests and the
original packet anchor. It requires exactly 52 packet entries, one original
manifest and 1,638 external entries; every file and implied directory name is
case-collision/alias checked. Original source fields remain inert provenance and
are never opened as a fallback. ExactStagingInventory observes the literal K root
through held identities, rejects reparses/hardlinks/volume transitions and extra
or missing files/directories, and compares byte counts/hashes to exact pins.
This read-only inventory adapter performs no staging or file copy. No full
payload tree is supplied or staged; observation alone cannot certify source trust
or parent-relative binding.

Every check_chain result remains blocked in this delivery. Explicit hard blockers
cover arbitrary-principal/owner/claim universality, unsupported restricted/MIC/
privilege conditions, parent-relative resolution/creation and directory continuity,
redirect/rename/volume authority, exact actual service token coverage, full installed
executable/config/environment/SCM closure, protected bootstrap/interpreter/native
DLL/stdlib/TEMP/PATH/cwd dependencies, and complete full staging/installed readback.
There are no acceptance booleans, fabricated installed records or service-token
substitutes that discharge these blockers.

The root F03-REQUIREMENT-MAP.md maps each normative requirement to actual symbols
or an explicit remaining blocker. DISPOSITIONS-AND-PREREQUISITES.md separates source
gaps, future disposable local verification and operational dependencies. Historical
one static PASS plus 27 BLOCKED and all 48 unspent attempts remain unchanged.
