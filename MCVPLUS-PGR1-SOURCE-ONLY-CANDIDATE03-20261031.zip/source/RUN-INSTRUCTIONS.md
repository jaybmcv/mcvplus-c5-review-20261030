# SOURCE-ONLY-NOT-AUTHORIZED

This candidate is UNTESTED source authoring. Do not execute, compile, import,
parse through a compiler/AST, run a launcher/helper, create a fixture, run tests,
probe tokens/ACLs/SCM, or retry any historical case. There is no current run command.
Delivery and manifest generation do not authorize execution. Entry points carry
unconditional source-only rejection; policy flags cannot turn that rejection off.

The current inventory is the candidate-root SOURCE-MANIFEST.json. Its paths begin
with source/. source/SOURCE-MANIFEST.json is byte-preserved historical provenance,
not an active manifest and not a second seal. policy/* and reference/* preserve
the normative originals, including historical paths, instructions and enablement
fields; read them as requirements/history under this source-only restriction.
DELIVERY-POLICY.json records the current disabled state.

The separate parent will commission independent source review after this manifest
is frozen. This builder performed no independent review. A later, separately
authorized revision would have to address the blockers in
../DISPOSITIONS-AND-PREREQUISITES.md and obtain a new byte manifest. Changing a
guard or flag is not a substitute for authorization or the missing implementations.

Native launch source requires a future independently built and externally pinned
helper. No helper executable or assembly is supplied or implicitly trusted. No
Add-Type compilation or automatic build is supplied. Inspector/helper source,
interpreter, launcher, policy and every auxiliary input must be pinned before any
future child creation. Protected interpreter/DLL/stdlib/TEMP/PATH/cwd closure and
outer watchdog requirements remain explicit prerequisites.

F01 is a prepared fixture-ordering correction. F02/F04 are prepared process
containment/evidence corrections. Their native failure paths and hardlink behavior
have not been exercised. F03 has new read-only native/token/descriptor and exact
path/inventory machinery; unsupported semantics and absent installed inputs still
block complete implementation and operational qualification.

The historical result remains one static PASS and 27 BLOCKED. There is no new
validation result. All 48 hosted attempts remain unspent (42 primary + 6 reserved).
ProtectedStage, Apply and Setup remain blocked. Existing exclusions apply; Vercel
access restoration is separate. Do not delete retained files or alter existing
services, installed roots, shared ACLs, secrets, permits, ledgers or historical data.

Candidate02 adds ParentCoordinator.ps1 as a source-only independently pinned entrypoint adapter. Its unconditional guard remains before current candidate work; no command is supplied. F05-F06-SOURCE-NOTES.md and the root canonical blocker list govern future preparation/evidence prerequisites. Parent evidence storage and supervisor protection remain unqualified.
