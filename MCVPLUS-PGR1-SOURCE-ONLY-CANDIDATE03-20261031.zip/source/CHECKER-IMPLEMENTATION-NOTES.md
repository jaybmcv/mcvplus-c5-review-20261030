# Native checker source dispositions

Status: **SOURCE-ONLY-NOT-AUTHORIZED / UNTESTED**. This file records source design,
not an independent review, test result, operational receipt or completion claim.
The checker has not been executed, compiled, imported, parsed with a compiler or
AST, or exercised against tokens, ACLs, services, fixtures or installed roots.

`permission_check.py` is a new implementation beside the preserved historical
finite DACL observer. There is no main routine, token acquisition path, privilege
enablement, ACL mutation, logon, service creation or automatic launch. Native DLL
loading occurs only if a later admitted loader imports the helper; delivery or
manifest production does not authorize that import.

## Source symbols and evidence contract

| Requirement | Source symbol and implemented behavior | Limit retained |
| --- | --- | --- |
| Real Windows token rather than synthetic SID lists | `NativeToken.from_handle`, `_handle_value`: accepts only an existing kernel token handle, retains the same token with `DuplicateHandle`, and makes one non-elevating `DuplicateTokenEx` impersonation copy for `AccessCheck` | No logon, process-token acquisition, token retry or privilege enablement. Handle possession does not prove an installed service or a permitted acquisition route. Fixture-origin kernel tokens cannot establish operational provenance. Context dictionaries are rejected. |
| Enabled, disabled, deny-only, restricted and owner-eligible groups | `_groups`, `_snapshot_token`: records every returned SID and raw attributes, enabled/deny-only/owner/integrity/resource/logon flags, restricted SID list, `TokenHasRestrictions`, `TokenIsRestricted` | Unknown attribute bits, contradictory enabled/deny-only flags, duplicate SIDs, unresolved SIDs, unavailable information classes and malformed buffers block. Restricted intersection is performed by the real Windows token in `AccessCheck`, not emulated from lists. |
| Owner, integrity, elevation and privileges | `_sid_field`, `_privileges`, `_statistics`, `_snapshot_token`: captures token user/owner/primary group, mandatory IL/policy, every privilege and raw flags, elevation/type, authentication/token/modified IDs, session and origin authentication ID | Trusted status derives only from unrestricted SYSTEM at system IL or enabled elevated Administrators at high IL. A caller `role` string has no trust effect. Filtered/deny-only Administrators are untrusted. |
| Claims, device, package and token-side authorization extensions | `_attribute_summary`, `_snapshot_token`: queries user/device/restricted claims, security attributes, device/restricted-device groups, AppContainer capabilities/SID, process trust, sandbox/UIAccess/virtualization | Nonempty or unsupported claims, device authorization, AppContainer, process-trust, active virtualization, sandbox-inert or UIAccess conditions block. No attribute is silently discarded. Older OS information-class denial also blocks. |
| Token continuity | `NativeToken.verify`: independently snapshots retained source and evaluation token, checks fingerprint/statistics before/after checks | No operational token-class or service-account provenance is inferred from successful duplication. Future evidence must identify representative real token classes and their permitted source. |
| Same-held descriptor | `inspect_descriptor`, `_capture_authorization_descriptor`: obtains owner/group/DACL and all requested authorization-relevant SACL classes through the existing `Held.h`; double-reads and compares before/after `Held.verify` | Requests `0x1F7`: OWNER, GROUP, DACL, LABEL, ATTRIBUTE, SCOPE, PROCESS_TRUST_LABEL and ACCESS_FILTER. Audit-only SACL access is not privilege-enabled. Any denial/unsupported class blocks instead of falling back to the older `0x17` projection. |
| Original field continuity | `inspect_descriptor`, `inspect_access`: retain original `Held.security()` and `Held.descriptor` fields under `originalDescriptor`/`originalHeldDescriptor`, plus requested/outcome/qualified/granted/reason/operationalEvidence fields | Broader descriptor raw bytes/hash are additional evidence; they do not replace or rewrite historical receipt fields. BLOCKED checks do not fabricate a granted mask. |
| Full narrow descriptor decoding | `_decode_descriptor`, `_acl_records`, `_sid_record`: validates self-relative descriptor and bounded ACL/ACE/SID layouts; preserves raw ACE bytes, masks, generic mapping, inheritance flags, owner/group, controls, label and principal account/SID type | Only standard allow/deny DACL ACEs and an ordinary single mandatory label are supported. Null/absent DACL, callback/conditional/object/compound/unknown ACEs, resource attributes, central policy, process trust and access filter ACEs are explicit blockers. Unknown ACE bytes are retained rather than interpreted as ordinary allow/deny. |
| Complete principal enumeration within supported ACE layouts | `_acl_records`, `_sid_record`: enumerates every standard ACE principal, including unresolved SIDs with explicit resolution errors; `_decode_descriptor` retains unresolved owner/group records | Resolving an account name is not arbitrary group membership closure. An unresolved principal blocks. The enclosing path policy must inspect every allow ACE and exact grant ceiling; representative token denial cannot establish a universal absence of untrusted routes. |
| Generic rights and individual rights | `_map_file_mask`, `_native_access_check`, `inspect_access`, `check_right`: accepts one concrete file/directory right, maps generic ACE masks in a private descriptor copy, and calls supported `Windows AccessCheck` using a `GENERIC_MAPPING` | No `MAXIMUM_ALLOWED`, combined desired-mask summary or permissive unknown-bit fallback. Type must match the held file/directory identity. Parent DELETE_CHILD, DELETE/rename combinations and policy capability composition belong to the enclosing per-path policy. |
| Owner implicit authority | `_native_access_check` passes the original owner SID to Windows, so standard implicit owner READ_CONTROL/WRITE_DAC behavior remains native | CREATOR OWNER, CREATOR GROUP and OWNER RIGHTS special ACEs explicitly block. Global trusted-owner/path restrictions still require enclosing policy; TrustedInstaller is not promoted to a new-root writer. |
| Mandatory integrity | `_decode_descriptor`, `inspect_access`: reads explicit label or Windows implicit medium IL and permits a native DACL observation only where subject IL is the same as or higher than object IL | Upward integrity requests explicitly block with `BLOCKED_MIC_UPWARD_ACCESS_SEMANTICS_UNQUALIFIED`. `AccessCheck` DACL output is never mislabeled as a general MIC result. Full upward no-write/read/execute-up and relabel/privilege semantics remain a source limitation. |
| Privilege effects | `_snapshot_token`, `_native_access_check`, `inspect_access`: records every token privilege and the native returned privilege set; only SeChangeNotifyPrivilege is admitted for an untrusted token | Enabled untrusted backup/restore/ownership/security/impersonation and every other non-whitelisted privilege block. No privilege is enabled or synthesized. Trusted administrator/SYSTEM hostility remains outside the normative adversary model. |
| Exact service-name/SID resolution | `resolve_service_sids`: hardcoded three normative NT SERVICE names, bounded `LookupAccountNameW`, canonical five-subauthority service SID shape, exact `LookupAccountSidW` name/domain/type roundtrip and collision rejection | A resolved SID does not prove an installed SCM service, service SID configuration, account binding or actual token. Missing/mismatched identities block; there is no override, synthetic fallback, service creation or token substitution. |

`inspect_access` returns `qualified=True` only for a supported *individual native
DACL observation*. `operationalEvidence` is always false. It never returns a
path-policy PASS, stage/setup authorization, installed-service acceptance or
qualification of a missing token class. `synthetic=None` expressly records that
the native handle's operational origin cannot be inferred by this API; it does
not claim that a kernel token could not have fixture origin.

The public interfaces are:

- `NativeToken.from_handle(handle)` as a context manager; close releases only its
  own retained and evaluation handles.
- `inspect_token(handle_or_NativeToken)` returns the complete supported token
  snapshot or raises `windows_api.Blocked`.
- `inspect_descriptor(held)` returns complete supported authorization data,
  unsupported reasons, and every decodable principal; native read failure raises
  `Blocked`.
- `inspect_access(held, token, desired, object_type='file'|'directory', role=None)`
  returns a fail-closed observation; `check_right(..., is_directory=bool)` is a
  compatibility spelling.
- `resolve_service_sids()` returns `postgres`, `provider`, `tunnel` records with
  `name`, `serviceName`, `sid`, `roundTrip`, and false installed-service/token/
  operational-evidence fields, or raises `Blocked`.

## Explicit remaining blockers

Source limitations remain for upward MIC, conditional/object/OWNER RIGHTS/CREATOR
OWNER and extended authorization ACEs/claims, nontraverse enabled privileges of
an untrusted token, package/device/process-trust tokens, and arbitrary principal
membership closure. These are executable rejection branches, not implemented
semantic support disguised as a completed checker. Exact known grant ceilings
can reject arbitrary mutation ACEs conservatively; no general group-expansion
engine is claimed here.

Operational evidence remains absent for installed roots, protected interpreter/
helper/native-DLL/TEMP/PATH/cwd launch closure, all representative real token
classes and actual service tokens, SCM/config/registry authority, observed
creation-to-held continuity and untrusted observer, full 52-file/1,691-entry
staging, and parent/rename/redirect mechanism closure. The enclosing source must
retain these blockers even if a supported individual right later returns DENIED.

Future local disposable verification and independent source review are separate
prerequisites. No such verification is authorized or performed here. Historical
1 static PASS plus 27 BLOCKED is unchanged; all 48 attempts remain unspent.
