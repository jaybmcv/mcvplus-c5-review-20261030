"""UNTESTED Windows helper source. Delivery authorizes no imports or execution.
The disabled runner contains the future pinned-byte loader; no standalone entry.
No account/service/logon/token duplication/privilege enablement or compilation.
"""
import ctypes as C
from ctypes import wintypes as W
import hashlib
import os
from pathlib import Path
import re
import time

ROOT = Path(r'D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate03')
K = C.WinDLL('kernel32', use_last_error=True)
A = C.WinDLL('advapi32', use_last_error=True)
Z = C.WinDLL('authz', use_last_error=True)
PTR = C.c_void_p
DWORD = W.DWORD
HANDLE = W.HANDLE

class Blocked(Exception):
    def __init__(self,reason,win32=None,details=None):
        self.reason=reason;self.win32=win32;self.details=details
        super().__init__(reason+(f':WIN32_{win32}' if win32 is not None else ''))

def bind(dll, name, args, result):
    f = getattr(dll, name)
    f.argtypes, f.restype = args, result
    return f

CreateFile = bind(K, 'CreateFileW', [W.LPCWSTR,DWORD,DWORD,PTR,DWORD,DWORD,HANDLE], HANDLE)
CloseHandle = bind(K, 'CloseHandle', [HANDLE], W.BOOL)
LocalFree = bind(K, 'LocalFree', [PTR], PTR)
CreateDirectory = bind(K, 'CreateDirectoryW', [W.LPCWSTR,PTR], W.BOOL)
CreateHardLink = bind(K, 'CreateHardLinkW', [W.LPCWSTR,W.LPCWSTR,PTR], W.BOOL)
CreateSymbolicLink = bind(K, 'CreateSymbolicLinkW', [W.LPCWSTR,W.LPCWSTR,DWORD], W.BOOLEAN)
SDDL = bind(A, 'ConvertStringSecurityDescriptorToSecurityDescriptorW', [W.LPCWSTR,DWORD,C.POINTER(PTR),C.POINTER(DWORD)], W.BOOL)
SDToText = bind(A, 'ConvertSecurityDescriptorToStringSecurityDescriptorW', [PTR,DWORD,DWORD,C.POINTER(PTR),C.POINTER(DWORD)], W.BOOL)
SDLength = bind(A, 'GetSecurityDescriptorLength', [PTR], DWORD)
SidToText = bind(A, 'ConvertSidToStringSidW', [PTR,C.POINTER(PTR)], W.BOOL)
SDControl = bind(A, 'GetSecurityDescriptorControl', [PTR,C.POINTER(C.c_ushort),C.POINTER(DWORD)], W.BOOL)
SecurityInfo = bind(A, 'GetSecurityInfo', [HANDLE,C.c_int,DWORD,C.POINTER(PTR),C.POINTER(PTR),C.POINTER(PTR),C.POINTER(PTR),C.POINTER(PTR)], DWORD)
ReadFile = bind(K, 'ReadFile', [HANDLE,PTR,DWORD,C.POINTER(DWORD),PTR], W.BOOL)
WriteFile = bind(K, 'WriteFile', [HANDLE,PTR,DWORD,C.POINTER(DWORD),PTR], W.BOOL)
Flush = bind(K, 'FlushFileBuffers', [HANDLE], W.BOOL)
SetPointer = bind(K, 'SetFilePointerEx', [HANDLE,C.c_longlong,PTR,DWORD], W.BOOL)
GetFinalName = bind(K, 'GetFinalPathNameByHandleW', [HANDLE,W.LPWSTR,DWORD,DWORD], DWORD)
GetCurrentProcess = bind(K, 'GetCurrentProcess', [], HANDLE)
GetCurrentProcessId = bind(K, 'GetCurrentProcessId', [], DWORD)
GetProcessTimes = bind(K, 'GetProcessTimes', [HANDLE,C.POINTER(W.FILETIME),C.POINTER(W.FILETIME),C.POINTER(W.FILETIME),C.POINTER(W.FILETIME)], W.BOOL)
OpenJob = bind(K, 'OpenJobObjectW', [DWORD,W.BOOL,W.LPCWSTR], HANDLE)
IsInJob = bind(K, 'IsProcessInJob', [HANDLE,HANDLE,C.POINTER(W.BOOL)], W.BOOL)
QueryJob = bind(K, 'QueryInformationJobObject', [HANDLE,C.c_int,PTR,DWORD,C.POINTER(DWORD)], W.BOOL)
class JobLimits(C.Structure):
    _fields_=[('processUserTime',C.c_longlong),('jobUserTime',C.c_longlong),('flags',DWORD),('minWorkingSet',C.c_size_t),('maxWorkingSet',C.c_size_t),('activeProcesses',DWORD),('affinity',C.c_size_t),('priorityClass',DWORD),('schedulingClass',DWORD)]
class IoCounters(C.Structure):
    _fields_=[('readOperations',C.c_ulonglong),('writeOperations',C.c_ulonglong),('otherOperations',C.c_ulonglong),('readBytes',C.c_ulonglong),('writeBytes',C.c_ulonglong),('otherBytes',C.c_ulonglong)]
class ExtendedJobLimits(C.Structure):
    _fields_=[('basic',JobLimits),('io',IoCounters),('processMemory',C.c_size_t),('jobMemory',C.c_size_t),('peakProcessMemory',C.c_size_t),('peakJobMemory',C.c_size_t)]

class Info(C.Structure):
    _fields_=[('attributes',DWORD),('creation',W.FILETIME),('access',W.FILETIME),('write',W.FILETIME),('volume',DWORD),('sizeHigh',DWORD),('sizeLow',DWORD),('links',DWORD),('indexHigh',DWORD),('indexLow',DWORD)]
GetInfo=bind(K,'GetFileInformationByHandle',[HANDLE,C.POINTER(Info)],W.BOOL)

class SA(C.Structure):
    _fields_=[('length',DWORD),('descriptor',PTR),('inherit',W.BOOL)]

CLEANUP_ERRORS=[]
CLEANUP_ERROR_COUNT=0

def cleanup_close(handle, operation):
    """One close attempt. Record bounded errors without replacing a primary error."""
    global CLEANUP_ERROR_COUNT
    if handle and not CloseHandle(handle):
        error=C.get_last_error()
        CLEANUP_ERROR_COUNT+=1
        if len(CLEANUP_ERRORS)<128:
            CLEANUP_ERRORS.append({'operation':operation,'win32':error,'status':'BLOCKED_CLEANUP','retry':False})
        return False
    return True

def cleanup_snapshot():
    return {'errors':list(CLEANUP_ERRORS),'errorCount':CLEANUP_ERROR_COUNT,
            'omitted':max(0,CLEANUP_ERROR_COUNT-len(CLEANUP_ERRORS)),'status':'BLOCKED_CLEANUP' if CLEANUP_ERROR_COUNT else 'NO_RECORDED_CLOSE_FAILURE'}

def failure(label):
    raise Blocked(label,C.get_last_error())

def canonical(value):
    s=str(value)
    if len(s)>240 or not re.match(r'^[A-Z]:\\',s) or '/' in s or os.path.normpath(s)!=s:
        raise Blocked('BLOCKED_NAMESPACE_ALIAS')
    if len(s)>3:
        for part in s[3:].split('\\'):
            if not part or part in ('.','..') or part.endswith(('.',' ')) or re.search(r'[:*?"<>|~]',part) or re.match(r'^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(?:\.|$)',part,re.I):
                raise Blocked('BLOCKED_NAMESPACE_ALIAS')
    return s

def local(value):
    s=canonical(value)
    if not s.startswith(str(ROOT)+'\\'):
        raise Blocked('EXACT_TASK_NAMESPACE_ONLY')
    return s

class Descriptor:
    def __init__(self,sddl):
        self.ptr=PTR()
        if not SDDL(sddl,1,C.byref(self.ptr),None): failure('SDDL_UNAVAILABLE')
    def close(self):
        if self.ptr: LocalFree(self.ptr); self.ptr=PTR()
    def __enter__(self): return self
    def __exit__(self,*_): self.close()

def descriptor_from_handle(handle):
    """Descriptor observation only. This function cannot approve a path."""
    o,g,d,s,sd=PTR(),PTR(),PTR(),PTR(),PTR()
    e=SecurityInfo(handle,1,0x17,C.byref(o),C.byref(g),C.byref(d),C.byref(s),C.byref(sd))
    if e:raise Blocked(f'GET_SECURITY_INFO_{e}')
    try:
        b=C.string_at(sd,SDLength(sd));text=PTR()
        if not SDToText(sd,1,0x17,C.byref(text),None):failure('SDDL_READBACK')
        try:
            owner=PTR()
            if not SidToText(o,C.byref(owner)):failure('OWNER_SID_READBACK')
            try:owner_sid=C.wstring_at(owner)
            finally:LocalFree(owner)
            flags=C.c_ushort();revision=DWORD()
            if not SDControl(sd,C.byref(flags),C.byref(revision)):failure('DESCRIPTOR_CONTROL_READBACK')
            sddl=C.wstring_at(text);label=re.search(r'\(ML;[^)]*\)',sddl)
            return {'sddl':sddl,'ownerSid':owner_sid,'integrityLabel':label[0] if label else 'ABSENT_OR_DEFAULT_NOT_QUALIFIED','controlFlags':flags.value,'daclProtected':bool(flags.value&0x1000),'sha256':hashlib.sha256(b).hexdigest(),'rawHex':b.hex()}
        finally:LocalFree(text)
    finally:LocalFree(sd)

class Held:
    def __init__(self,path,handle=None,created=False):
        self.path=canonical(path)
        self.h=handle if handle is not None else CreateFile(self.path,0x20081,1,None,3,0x02200000,None)
        if self.h in (None,C.c_void_p(-1).value): failure('HELD_OPEN')
        self.created=created
        try:
            self.info=self.identity()
            self.descriptor=self.security()
            self.verify()
        except BaseException:
            self.close(); raise
    def identity(self):
        i=Info()
        if not GetInfo(self.h,C.byref(i)): failure('HELD_FILE_ID')
        if i.attributes&0x400: raise Blocked('BLOCKED_REPARSE')
        if not i.attributes&0x10 and i.links!=1: raise Blocked('BLOCKED_HARDLINK')
        return {'volume':int(i.volume),'fileId':f'{i.indexHigh:08x}{i.indexLow:08x}','links':int(i.links),'attributes':int(i.attributes),'bytes':(int(i.sizeHigh)<<32)|int(i.sizeLow)}
    def security(self):
        # Same held object, owner/group/DACL and mandatory label. Never drop label on denial.
        return descriptor_from_handle(self.h)
    def verify(self):
        now=self.identity()
        if (now['volume'],now['fileId'])!=(self.info['volume'],self.info['fileId']): raise Blocked('BLOCKED_CONTINUITY')
        if self.security()['sha256']!=self.descriptor['sha256']:raise Blocked('BLOCKED_DESCRIPTOR_DRIFT')
        return now
    def hash(self):
        if self.info['attributes']&0x10: raise Blocked('NOT_A_FILE')
        self.verify()
        if not SetPointer(self.h,0,None,0): failure('HELD_SEEK')
        digest=hashlib.sha256();buf=C.create_string_buffer(65536);n=DWORD()
        while True:
            if not ReadFile(self.h,buf,len(buf),C.byref(n),None): failure('HELD_READ')
            if not n.value: break
            digest.update(buf.raw[:n.value])
        self.verify();return digest.hexdigest()
    def write(self,data):
        if not self.created: raise Blocked('WRITE_ONLY_OWN_EXCLUSIVE_OBJECT')
        local(self.path)
        n=DWORD();buf=C.create_string_buffer(data)
        if not WriteFile(self.h,buf,len(data),C.byref(n),None) or n.value!=len(data): failure('OWNED_WRITE')
        if not Flush(self.h): failure('DURABLE_FLUSH')
        self.verify()
    def record(self):
        return {'path':self.path,'parentPath':str(Path(self.path).parent),'identity':self.verify(),'descriptor':self.security(),'handle':hex(self.h),'share':'READ_ONLY_NO_DELETE_SHARE','createdByInvocation':self.created,'heldParents':self.parent_chain.record() if getattr(self,'parent_chain',None) else []}
    def close(self):
        if getattr(self,'h',None):
            closing=self.h;self.h=None;cleanup_close(closing,'Held.close')
        if getattr(self,'parent_chain',None):self.parent_chain.close();self.parent_chain=None
    def __enter__(self):return self
    def __exit__(self,*_):self.close()

class Chain:
    def __init__(self,path):
        q=Path(canonical(path));parts=[]
        while True:
            parts.insert(0,str(q))
            if q.parent==q:break
            q=q.parent
        self.held=[]
        try:
            for p in parts:
                h=Held(p);self.held.append(h)
                if h.info['volume']!=self.held[0].info['volume']:raise Blocked('BLOCKED_VOLUME_TRANSITION')
        except BaseException:self.close();raise
    def close(self):
        for h in reversed(self.held):h.close()
        self.held=[]
    def record(self):return [h.record() for h in self.held]
    def __enter__(self):return self
    def __exit__(self,*_):self.close()

PROTECTED='O:BAG:BAD:P(A;OICI;FA;;;BA)(A;OICI;FA;;;SY)'

def verify_created(h):
    return verify_created_security(h.security())

def verify_created_security(security):
    dacl=re.search(r'D:(.*?)(?=S:|$)',security['sddl'])
    aces=re.findall(r'\(([^()]*)\)',dacl[1]) if dacl else []
    allowed=[]
    for ace in aces:
        p=ace.split(';')
        if len(p)!=6 or p[0]!='A' or p[1]!='OICI' or p[2] not in ('FA','0x1f01ff') or p[3] or p[4]:raise Blocked('CREATED_DACL_READBACK_UNEXPECTED')
        if p[5] not in ('BA','SY','S-1-5-32-544','S-1-5-18'):raise Blocked('CREATED_UNTRUSTED_ACE')
        allowed.append({'BA':'S-1-5-32-544','SY':'S-1-5-18'}.get(p[5],p[5]))
    if (security['ownerSid']!='S-1-5-32-544' or not security['daclProtected'] or
        not dacl or re.sub(r'\([^()]*\)','',dacl[1])!='P' or
        sorted(allowed)!=['S-1-5-18','S-1-5-32-544']):
        raise Blocked('CREATED_OWNER_DACL_UNQUALIFIED')
    return {'expectedOwnerSid':'S-1-5-32-544','expectedProtectedDacl':PROTECTED,'readback':security,'exactOwnerAndDaclVerified':True,'untrustedObserver':'UNQUALIFIED_NOT_ACQUIRED'}

def new_file(path,data=b''):
    path=local(path)
    chain=Chain(str(Path(path).parent))
    try:
        with Descriptor(PROTECTED) as d:
            sa=SA(C.sizeof(SA),d.ptr,False)
            # CREATE_NEW returns the actual exclusive object handle, no pathname reopen.
            h=CreateFile(path,0x12019f,1,C.byref(sa),1,0x80200000,None)
            if h in (None,C.c_void_p(-1).value):failure('BLOCKED_COLLISION_OR_FILE_CREATE')
            result=Held(path,h,True);result.parent_chain=chain
            try: verify_created(result);result.write(data);return result
            except BaseException: result.close();raise
    except BaseException:chain.close();raise

def hardlink_fixture_path(path):
    """Restrict raw observation APIs to this single disposable negative fixture."""
    path=local(path)
    allowed={str(ROOT/'fixtures'/'L18'/'original.txt'),str(ROOT/'fixtures'/'L18'/'alias.txt')}
    if path not in allowed:raise Blocked('HARDLINK_SENTINEL_EXACT_FIXTURE_ONLY')
    return path

def prepare_hardlink_scenario(data):
    """Prepare L18 before caller takes any Held locks, including ancestors."""
    directories=[]
    for path in (ROOT/'fixtures',ROOT/'fixtures'/'L18'):
        path=local(str(path));handle=None
        with Descriptor(PROTECTED) as descriptor:
            sa=SA(C.sizeof(SA),descriptor.ptr,False)
            if not CreateDirectory(path,C.byref(sa)):failure('BLOCKED_COLLISION_OR_DIRECTORY_CREATE')
        try:
            handle=CreateFile(path,0x20081,7,None,3,0x02200000,None)
            if handle in (None,C.c_void_p(-1).value):handle=None;failure('HARDLINK_DIRECTORY_SENTINEL_OPEN')
            info=Info()
            if not GetInfo(handle,C.byref(info)):failure('HARDLINK_DIRECTORY_SENTINEL_ID')
            if not info.attributes&0x10 or info.attributes&0x400:raise Blocked('HARDLINK_DIRECTORY_TYPE_OR_REPARSE')
            security=descriptor_from_handle(handle);verify_created_security(security)
            directories.append({'path':path,'volume':int(info.volume),'fileId':f'{info.indexHigh:08x}{info.indexLow:08x}',
                                'descriptor':security,'observationOnly':True,'untrustedObserverContinuity':'UNQUALIFIED'})
        finally:
            if handle:cleanup_close(handle,'hardlink directory sentinel close')
    initial=prepare_hardlink_fixture(str(ROOT/'fixtures'/'L18'/'original.txt'),str(ROOT/'fixtures'/'L18'/'alias.txt'),data)
    return {'initialFileSentinel':initial,'directories':directories,'beforeAnyHeldLock':True}

def hold_prepared_hardlink_directory(path,prepared):
    path=local(path)
    if not isinstance(prepared,dict) or prepared.get('beforeAnyHeldLock') is not True:
        raise Blocked('HARDLINK_DIRECTORY_PREPARATION_MISSING')
    expected=[item for item in prepared.get('directories',[]) if item['path']==path]
    if len(expected)!=1 or path not in (str(ROOT/'fixtures'),str(ROOT/'fixtures'/'L18')):
        raise Blocked('HARDLINK_DIRECTORY_EXACT_PREPARED_PATH_REQUIRED')
    h=Held(path)
    try:
        item=expected[0]
        if h.info['volume']!=item['volume'] or h.info['fileId']!=item['fileId'] or h.security()!=item['descriptor']:
            raise Blocked('HARDLINK_DIRECTORY_IDENTITY_CHANGED')
        h.created=True
        return h
    except BaseException:h.close();raise

def hardlink_raw_identity(handle,expected_links):
    # This returns evidence, never path admission. Held.identity retains its
    # unchanged production link-count rejection.
    info=Info()
    if not GetInfo(handle,C.byref(info)):failure('HARDLINK_SENTINEL_ID')
    if info.attributes&0x410:raise Blocked('HARDLINK_SENTINEL_REPARSE_OR_DIRECTORY')
    if info.links!=expected_links:raise Blocked('HARDLINK_SENTINEL_UNEXPECTED_LINK_COUNT')
    size=(int(info.sizeHigh)<<32)|int(info.sizeLow)
    if size>1024**2:raise Blocked('HARDLINK_SENTINEL_BYTE_BOUND')
    return {'volume':int(info.volume),'fileId':f'{info.indexHigh:08x}{info.indexLow:08x}',
            'links':int(info.links),'attributes':int(info.attributes),'bytes':size,
            'creationFileTime':(info.creation.dwHighDateTime<<32)|info.creation.dwLowDateTime}

def hardlink_snapshot(handle,path,expected_links):
    """Same-handle hash/descriptor/identity sentinel. Never a Held or approval."""
    before=hardlink_raw_identity(handle,expected_links);security=descriptor_from_handle(handle)
    if not SetPointer(handle,0,None,0):failure('HARDLINK_SENTINEL_SEEK')
    digest=hashlib.sha256();buf=C.create_string_buffer(65536);count=DWORD();total=0
    while True:
        if not ReadFile(handle,buf,len(buf),C.byref(count),None):failure('HARDLINK_SENTINEL_READ')
        if not count.value:break
        total+=count.value
        if total>1024**2:raise Blocked('HARDLINK_SENTINEL_BYTE_BOUND')
        digest.update(buf.raw[:count.value])
    after=hardlink_raw_identity(handle,expected_links)
    if before!=after or descriptor_from_handle(handle)!=security or total!=before['bytes']:
        raise Blocked('HARDLINK_SENTINEL_OBSERVED_DRIFT')
    return {'path':path,'identity':before,'descriptor':security,'sha256':digest.hexdigest(),
            'observationOnly':True,'pathApproval':False,'untrustedObserverContinuity':'UNQUALIFIED'}

def prepare_hardlink_fixture(original,alias,data):
    """CREATE_NEW -> write/flush/readback -> close -> CreateHardLink.

    No Held file is constructed before link creation. There is no retry, reopen
    for write, overwrite, unlink, broad cleanup, or operational-path capability.
    The caller invokes this before any Held ancestor locks. This supplies no
    adversarial parent-directory or creation-window proof.
    """
    original=hardlink_fixture_path(original);alias=hardlink_fixture_path(alias)
    if original!=str(ROOT/'fixtures'/'L18'/'original.txt') or alias!=str(ROOT/'fixtures'/'L18'/'alias.txt'):
        raise Blocked('HARDLINK_SENTINEL_EXACT_PAIR_ONLY')
    if not isinstance(data,bytes) or len(data)>1024**2:raise Blocked('HARDLINK_SENTINEL_BYTE_BOUND')
    handle=None
    try:
        with Descriptor(PROTECTED) as descriptor:
            sa=SA(C.sizeof(SA),descriptor.ptr,False)
            handle=CreateFile(original,0x12019f,0,C.byref(sa),1,0x80200000,None)
            if handle in (None,C.c_void_p(-1).value):handle=None;failure('BLOCKED_COLLISION_OR_FILE_CREATE')
        written=DWORD();buffer=C.create_string_buffer(data)
        if not WriteFile(handle,buffer,len(data),C.byref(written),None) or written.value!=len(data):failure('OWNED_WRITE')
        if not Flush(handle):failure('DURABLE_FLUSH')
        initial=hardlink_snapshot(handle,original,1)
        verify_created_security(initial['descriptor'])
        if initial['sha256']!=hashlib.sha256(data).hexdigest():raise Blocked('HARDLINK_CREATED_BYTE_MISMATCH')
        closing=handle;handle=None
        if not cleanup_close(closing,'hardlink exclusive close'):raise Blocked('HARDLINK_EXCLUSIVE_HANDLE_CLOSE')
    finally:
        if handle:cleanup_close(handle,'hardlink creation exceptional close')
    # The exclusive creation handle is closed before the only link attempt.
    # Held is first invoked by the caller after both raw post-link sentinels.
    if not CreateHardLink(alias,original,None):failure('HARDLINK_FIXTURE_UNAVAILABLE')
    return initial

def hardlink_fixture_sentinel(path):
    path=hardlink_fixture_path(path)
    # Permissive sharing is evidence only. No operational gate consumes this as
    # admission, and Held still rejects every regular file whose links != 1.
    handle=CreateFile(path,0x20081,7,None,3,0x02200000,None)
    if handle in (None,C.c_void_p(-1).value):failure('HARDLINK_SENTINEL_OPEN')
    try:return hardlink_snapshot(handle,path,2)
    finally:
        cleanup_close(handle,'hardlink sentinel close')

def require_hardlink_same_object(initial,sentinels):
    if set(sentinels)!={'original.txt','alias.txt'} or initial['identity']['links']!=1:
        raise Blocked('HARDLINK_SENTINEL_PAIR_INCOMPLETE')
    stable=lambda value:{key:item for key,item in value['identity'].items() if key!='links'}
    for name,value in sentinels.items():
        if (value['path']!=str(ROOT/'fixtures'/'L18'/name) or value['identity']['links']!=2 or
            stable(value)!=stable(initial) or value['descriptor']!=initial['descriptor'] or value['sha256']!=initial['sha256'] or
            value.get('pathApproval') is not False):
            raise Blocked('HARDLINK_SAME_IDENTITY_SENTINEL_CHANGED')
    return None

def new_directory(path):
    path=local(path)
    chain=Chain(str(Path(path).parent))
    try:
        with Descriptor(PROTECTED) as d:
            sa=SA(C.sizeof(SA),d.ptr,False)
            if not CreateDirectory(path,C.byref(sa)):failure('BLOCKED_COLLISION_OR_DIRECTORY_CREATE')
            # Same trusted writer/admin concurrency is out of scope. Full lower-privilege
            # parent authority has NOT been proved: observation, never continuity PASS.
            h=Held(path);h.created=True;h.parent_chain=chain
            try:verify_created(h);return h
            except BaseException:h.close();raise
    except BaseException:chain.close();raise

class Luid(C.Structure):_fields_=[('low',DWORD),('high',W.LONG)]
class SIDATTR(C.Structure):_fields_=[('sid',PTR),('attributes',DWORD)]
class Request(C.Structure):_fields_=[('desired',DWORD),('selfSid',PTR),('objectTypes',PTR),('objectCount',DWORD),('optional',PTR)]
class Reply(C.Structure):_fields_=[('count',DWORD),('granted',C.POINTER(DWORD)),('sacl',C.POINTER(DWORD)),('errors',C.POINTER(DWORD))]
InitRM=bind(Z,'AuthzInitializeResourceManager',[DWORD,PTR,PTR,PTR,W.LPCWSTR,C.POINTER(HANDLE)],W.BOOL)
InitContext=bind(Z,'AuthzInitializeContextFromSid',[DWORD,PTR,HANDLE,PTR,Luid,PTR,C.POINTER(HANDLE)],W.BOOL)
AddSids=bind(Z,'AuthzAddSidsToContext',[HANDLE,PTR,DWORD,PTR,DWORD,C.POINTER(HANDLE)],W.BOOL)
AuthzCheck=bind(Z,'AuthzAccessCheck',[DWORD,HANDLE,C.POINTER(Request),HANDLE,PTR,PTR,DWORD,C.POINTER(Reply),PTR],W.BOOL)
FreeContext=bind(Z,'AuthzFreeContext',[HANDLE],W.BOOL)
FreeRM=bind(Z,'AuthzFreeResourceManager',[HANDLE],W.BOOL)
StringSid=bind(A,'ConvertStringSidToSidW',[W.LPCWSTR,C.POINTER(PTR)],W.BOOL)
class GenericMapping(C.Structure):_fields_=[('read',DWORD),('write',DWORD),('execute',DWORD),('all',DWORD)]
MapGeneric=bind(A,'MapGenericMask',[C.POINTER(DWORD),C.POINTER(GenericMapping)],None)
GetDacl=bind(A,'GetSecurityDescriptorDacl',[PTR,C.POINTER(W.BOOL),C.POINTER(PTR),C.POINTER(W.BOOL)],W.BOOL)
GetAce=bind(A,'GetAce',[PTR,DWORD,C.POINTER(PTR)],W.BOOL)

def reference_map_dacl(sd):
    # Windows maps common ACE generic masks independently of the gate parser.
    # Callback/object/unknown ACE layouts are not decoded or silently accepted.
    present,defaulted=W.BOOL(),W.BOOL();acl=PTR()
    if not GetDacl(sd,C.byref(present),C.byref(acl),C.byref(defaulted)):failure('REFERENCE_GET_DACL')
    if not present or not acl:return
    count=C.c_ushort.from_address(acl.value+4).value
    mapping=GenericMapping(0x120089,0x120116,0x1200a0,0x1f01ff)
    for i in range(count):
        ace=PTR()
        if not GetAce(acl,i,C.byref(ace)):failure('REFERENCE_GET_ACE')
        kind=C.c_ubyte.from_address(ace.value).value
        if kind not in (0,1):raise Blocked('REFERENCE_UNSUPPORTED_ACE_LAYOUT')
        access=DWORD.from_address(ace.value+4)
        MapGeneric(C.byref(access),C.byref(mapping))

def sidptr(s):
    p=PTR()
    if not StringSid(s,C.byref(p)):failure('SID_PARSE')
    return p

def reference(sddl,context,mask):
    """Independent Windows Authz, concrete-mask DACL-only synthetic reference.
    Does not call/import gate logic. MIC/privileges/restricted tokens explicitly unsupported.
    """
    if mask<=0 or mask&(mask-1) or mask&0xf0000000:raise Blocked('REFERENCE_INDIVIDUAL_CONCRETE_MASK_ONLY')
    if 'S:' in sddl or context.get('restricted') or context.get('privileges'):raise Blocked('REFERENCE_MIC_RESTRICTED_PRIVILEGES_UNQUALIFIED')
    rm,ctx,aug=HANDLE(),HANDLE(),HANDLE();alloc=[]
    try:
        if not InitRM(1,None,None,None,'PG-R1 offline synthetic',C.byref(rm)):failure('AUTHZ_RM')
        p=sidptr(context['user']);alloc.append(p)
        if not InitContext(2,p,rm,None,Luid(),None,C.byref(ctx)):failure('AUTHZ_CONTEXT_SKIP_TOKEN_GROUPS')
        entries=[]
        for name,attr in [('enabled',4),('denyOnly',0x10)]:
            for s in context.get(name,[]):
                p=sidptr(s);alloc.append(p);entries.append(SIDATTR(p,attr))
        use=ctx
        if entries:
            arr=(SIDATTR*len(entries))(*entries)
            if not AddSids(ctx,arr,len(entries),None,0,C.byref(aug)):failure('AUTHZ_ADD_SIDS')
            use=aug
        granted,error=DWORD(),DWORD();req=Request(mask,None,None,0,None);reply=Reply(1,C.pointer(granted),None,C.pointer(error))
        with Descriptor(sddl) as d:
            reference_map_dacl(d.ptr)
            if not AuthzCheck(0,use,C.byref(req),None,d.ptr,None,0,C.byref(reply),None):failure('AUTHZ_ACCESS_CHECK')
        outcome='ALLOWED' if error.value==0 and granted.value&mask==mask else 'DENIED' if error.value==5 else 'UNQUALIFIED'
        return {'engine':'Windows AuthzAccessCheck','requested':mask,'granted':granted.value,'win32Error':error.value,'outcome':outcome,'actual':True,'synthetic':True,'actualToken':False,'operationalEvidence':False,'context':context,'scope':'DACL_ONLY_SKIP_TOKEN_GROUPS'}
    finally:
        if aug:FreeContext(aug)
        if ctx:FreeContext(ctx)
        if rm:FreeRM(rm)
        for p in alloc:LocalFree(p)

class Job:
    """Observe membership in the parent's pre-resume assigned runner job.

    Never creates, configures, adopts control of, or assigns a process to a job.
    Query handles are temporary so the runner does not retain a second lifetime
    owner for the parent's KILL_ON_JOB_CLOSE containment boundary.
    """
    def __init__(self,parent_job_name):
        self.name='PG-R1-'+ROOT.name+'-runner';self.closed=False
        if parent_job_name!=self.name:raise Blocked('EXACT_PARENT_OWNED_JOB_REQUIRED')
        self.pids()
        a,b,c,d=W.FILETIME(),W.FILETIME(),W.FILETIME(),W.FILETIME()
        if not GetProcessTimes(GetCurrentProcess(),C.byref(a),C.byref(b),C.byref(c),C.byref(d)):failure('BLOCKED_PROCESS_START_ID')
        import sys
        self.identity={'pid':os.getpid(),'startFileTime':(a.dwHighDateTime<<32)|a.dwLowDateTime,'executable':sys.executable,'job':self.name,'jobHandle':'PARENT_OWNED_NOT_RETAINED_BY_RUNNER','role':'sole runner; no children allowed','jobActiveProcessLimit':1,'killOnJobClose':True,'membershipObservation':'QUERY_ONLY_NO_SELF_ASSIGNMENT','preResumeAssignment':'PARENT_LAUNCH_RECEIPT_REQUIRED'}
    def pids(self):
        if self.closed:raise Blocked('BLOCKED_CONTAINMENT_QUERY_AFTER_CLOSE')
        handle=OpenJob(4,False,self.name)
        if not handle:failure('BLOCKED_PARENT_JOB_OPEN_QUERY')
        # JOBOBJECT_BASIC_PROCESS_ID_LIST: DWORD counts then ULONG_PTR PID array.
        class Pids(C.Structure):_fields_=[('assigned',DWORD),('count',DWORD),('ids',C.c_size_t*8)]
        try:
            member=W.BOOL()
            if not IsInJob(GetCurrentProcess(),handle,C.byref(member)):failure('BLOCKED_PARENT_JOB_MEMBERSHIP_QUERY')
            if not member.value:raise Blocked('BLOCKED_RUNNER_NOT_IN_PARENT_JOB')
            limits=ExtendedJobLimits()
            if not QueryJob(handle,9,C.byref(limits),C.sizeof(limits),None):failure('BLOCKED_PARENT_JOB_LIMIT_QUERY')
            if limits.basic.flags!=0x2008 or limits.basic.activeProcesses!=1:
                raise Blocked('BLOCKED_PARENT_JOB_LIMITS_NOT_EXACT')
            p=Pids()
            if not QueryJob(handle,3,C.byref(p),C.sizeof(p),None):failure('BLOCKED_CONTAINMENT_QUERY')
            if p.assigned!=1 or p.count!=1 or list(p.ids[:p.count])!=[os.getpid()]:
                raise Blocked('BLOCKED_CONTAINMENT_UNEXPECTED_JOB_MEMBER')
            return list(p.ids[:p.count])
        finally:
            cleanup_close(handle,'parent job query close')
    def ensure_only_runner(self):
        p=self.pids()
        if p!=[os.getpid()]:raise Blocked('BLOCKED_CONTAINMENT_UNEXPECTED_JOB_MEMBER')
        return {'runner':self.identity,'ownedChildren':[],'jobMembers':p,'survivorsExcludingRunningHarness':0,'finalRunnerExit':'PARENT_MUST_VERIFY'}
    def close(self):
        self.closed=True
