"""PG-R1 read-only policy machinery. SOURCE ONLY, UNTESTED, no entry point.

This implements rejecting predicates and exact capability ceilings. A ceiling is
not an ACL grant. Installed closure, SCM and loader attestations are unavailable;
check_chain therefore cannot issue a policy PASS in this delivery. No caller
boolean or synthetic receipt can discharge those blockers.
"""
import hashlib
import json
import ntpath
import os
import re
from collections import Counter

import windows_api as win
import permission_check as access

T = r'C:\Program Files\MCVQ5-Staging-20261029'
K = T + r'\candidate-b9e20e88'
CODE = r'C:\Program Files\MCVQ5-20261029'
STATE = r'C:\Program Files\MCVQ5-State-20261029'
REJECTED_ROOT = r'C:\ProgramData\MCVQ5-20261029'
ANCHOR = 'b9e20e88febac511fc0e30db258da6d7708c504aa06f1979b335ed32cdb25a8c'
MAP_SHA256 = '6f37ef601c5dcd52b75d4142f41be498fd6e57a3dd969392874a32e00b9172c1'
REVISION_SHA256 = '19867043a03c15a7e9f010f53369b8c6d3adefe15878db1852338966e283f3b3'
SYSTEM = 'S-1-5-18'
ADMINS = 'S-1-5-32-544'
TRUSTED_INSTALLER = 'S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464'
SERVICE_NAMES = {
    'postgres': r'NT SERVICE\MCVQ5Postgres1029',
    'provider': r'NT SERVICE\MCVQ5Provider1029',
    'tunnel': r'NT SERVICE\MCVQ5Tunnel1029',
}
READ = 0x120089
RX = 0x1200a9
TRAVERSE_RX = 0x1200a9
MODIFY = 0x1301bf
FILE_RIGHTS = (1, 2, 4, 8, 0x10, 0x20, 0x80, 0x100,
               0x10000, 0x20000, 0x40000, 0x80000, 0x100000)
DIRECTORY_RIGHTS = FILE_RIGHTS + (0x40,)
MUTATION = frozenset((2, 4, 0x10, 0x40, 0x100, 0x10000, 0x40000, 0x80000))
SECURITY_RIGHTS = frozenset((0x40000, 0x80000))
REQUIRED_TOKEN_CLASSES = frozenset(('ordinary', 'filtered-admin', 'restricted-deny-only',
                                    'postgres', 'provider', 'tunnel'))


def blocked(reason, outcome='BLOCKED_UNKNOWN', **fields):
    return dict(outcome=outcome, qualified=False, operationalEvidence=False,
                reason=reason, **fields)


def exact_path(value):
    """Canonical spelling is required, including case and no short-name aliases."""
    value = win.canonical(value)
    if value == REJECTED_ROOT or value.startswith(REJECTED_ROOT + '\\'):
        raise win.Blocked('REJECTED_PROGRAMDATA_COMPATIBILITY_ROOT')
    return value


def relative_name(value):
    if (not isinstance(value, str) or not value or value.startswith('/') or
            '\\' in value or ':' in value or '//' in value):
        raise win.Blocked('INVENTORY_RELATIVE_PATH')
    for part in value.split('/'):
        if (part in ('', '.', '..') or part.endswith(('.', ' ')) or
                re.search(r'[~*?"<>|\x00-\x1f]', part) or
                re.match(r'^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(?:\.|$)', part, re.I)):
            raise win.Blocked('INVENTORY_PATH_ALIAS')
    return value


def pinned_json(raw, expected):
    if not isinstance(raw, bytes) or hashlib.sha256(raw).hexdigest() != expected:
        raise win.Blocked('REVIEWED_REFERENCE_PIN_MISMATCH')
    def unique_pairs(pairs):
        answer = {}
        for key, value in pairs:
            if key in answer:
                raise win.Blocked('DUPLICATE_JSON_KEY')
            answer[key] = value
        return answer
    return json.loads(raw, object_pairs_hook=unique_pairs)


def staging_pins(map_raw, revision_raw):
    """Validate original 52 + manifest + 1638 and revised map with no fallback.

    Source path fields are inert provenance: this function never opens them.
    The original packet's own manifest digest must retain the original anchor.
    """
    source_map = pinned_json(map_raw, MAP_SHA256)
    revision = pinned_json(revision_raw, REVISION_SHA256)
    if (source_map.get('originalManifestSha256') != ANCHOR or
            revision.get('originalManifestSha256') != ANCHOR or
            source_map.get('counts') != {'packet': 52, 'external': 1638, 'manifest': 1}):
        raise win.Blocked('ORIGINAL_ANCHOR_OR_COUNTS')
    entries = source_map.get('entries', [])
    if (len(entries) != 1691 or
            Counter(p.get('kind') for p in entries) !=
            Counter({'packet': 52, 'external': 1638, 'packet-manifest': 1})):
        raise win.Blocked('EXACT_1691_MAP_REQUIRED')
    pins = {}
    casefolded = set()
    def add(name, pin):
        name = relative_name(name)
        if name.casefold() in casefolded:
            raise win.Blocked('INVENTORY_CASE_COLLISION')
        if (type(pin.get('bytes')) is not int or pin['bytes'] < 0 or
                not re.fullmatch('[a-f0-9]{64}', str(pin.get('sha256', '')))):
            raise win.Blocked('INVENTORY_INVALID_PIN')
        casefolded.add(name.casefold())
        pins[name] = {'bytes': pin['bytes'], 'sha256': pin['sha256']}
    for entry in entries:
        if entry['kind'] == 'packet-manifest' and entry['sha256'] != ANCHOR:
            raise win.Blocked('ORIGINAL_PACKET_MANIFEST_PIN')
        add(entry['destination'], entry)
    for entry in revision.get('files', []):
        # SOURCE-MAP is itself installed, never a substitute for the 1691 entries.
        add(entry['path'], entry)
    directories = set()
    for name in pins:
        parent = name.rpartition('/')[0]
        while parent:
            if parent.casefold() in casefolded:
                raise win.Blocked('INVENTORY_FILE_DIRECTORY_COLLISION')
            directories.add(parent)
            parent = parent.rpartition('/')[0]
    return pins, directories


class ExactStagingInventory:
    """Held read-only complete inventory observation; no staging or copying.

    A pathname reopen remains a continuity limitation. The observation never
    certifies relative creation or an atomic ancestor-relative binding.
    """
    def __init__(self, root, map_raw, revision_raw):
        if exact_path(root) != K:
            raise win.Blocked('EXACT_STAGING_ROOT_REQUIRED')
        self.root = root
        self.pins, self.directories = staging_pins(map_raw, revision_raw)
        self.chain = None
        self.held = []
        self.records = []

    def inspect(self):
        try:
            self.chain = win.Chain(self.root)
            seen_files, seen_dirs, folded = set(), set(), set()
            pending = [self.root]
            root_volume = self.chain.held[0].info['volume']
            while pending:
                directory = pending.pop()
                with os.scandir(directory) as scan:
                    for item in scan:
                        path = exact_path(item.path)
                        rel = relative_name(path[len(self.root) + 1:].replace('\\', '/'))
                        if rel.casefold() in folded:
                            raise win.Blocked('INVENTORY_CASE_COLLISION')
                        folded.add(rel.casefold())
                        # Held rejects every reparse tag and protected-file hardlink.
                        held = win.Held(path)
                        self.held.append(held)
                        if held.info['volume'] != root_volume:
                            raise win.Blocked('BLOCKED_VOLUME_TRANSITION')
                        is_directory = bool(held.info['attributes'] & 0x10)
                        if is_directory:
                            if rel not in self.directories:
                                raise win.Blocked('EXTRA_STAGED_DIRECTORY')
                            seen_dirs.add(rel)
                            pending.append(path)
                        else:
                            if rel not in self.pins:
                                raise win.Blocked('EXTRA_STAGED_FILE')
                            pin = self.pins[rel]
                            if held.info['bytes'] != pin['bytes'] or held.hash() != pin['sha256']:
                                raise win.Blocked('STAGED_BYTES_DRIFT')
                            seen_files.add(rel)
                        self.records.append(held.record())
            if seen_files != set(self.pins) or seen_dirs != self.directories:
                raise win.Blocked('MISSING_STAGED_INVENTORY')
            for held in self.chain.held + self.held:
                held.verify()
            return blocked('Exact held inventory observed; parent-relative binding and '
                           'protected source/loader provenance remain unqualified',
                           outcome='BLOCKED_CONTINUITY', inventoryExact=True,
                           files=len(seen_files), directories=len(seen_dirs),
                           originalMapEntries=1691, originalPacketEntries=52,
                           handles=self.records)
        except win.Blocked as error:
            return blocked(error.reason, handles=self.records, win32=error.win32)

    def close(self):
        for held in reversed(self.held):
            held.close()
        self.held = []
        if self.chain:
            self.chain.close()
            self.chain = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def capability_ceiling(path, service, is_directory):
    """Exact named capability, never recursive service grants or an approval.

    Postgres data is a normative subtree exception. It still needs a complete
    real inventory, no external tablespace/config/preload path, and actual token
    proof. No installed binary RX is guessed from its parent directory.
    """
    path = exact_path(path)
    if service not in SERVICE_NAMES:
        return 0, 'UNRECOGNIZED_SERVICE'
    if path in (STATE, STATE + r'\tunnel') and is_directory:
        if path == STATE or service == 'tunnel':
            return TRAVERSE_RX, 'EXACT_CONTROL_DIRECTORY_TRAVERSAL'
    if service == 'postgres' and (path == STATE + r'\postgres' or
                                 path.startswith(STATE + r'\postgres\')):
        return MODIFY, 'POSTGRES_OWN_DATA_ONLY_EXTERNAL_PATHS_UNQUALIFIED'
    if service == 'provider':
        if path in (STATE + r'\provider-slots', STATE + r'\provider-logs') and is_directory:
            return MODIFY, 'EXACT_PROVIDER_DIRECTORY_REVIEWED_NAMES_REQUIRED'
        parent, leaf = ntpath.split(path)
        if (not is_directory and parent == STATE + r'\provider-slots' and
                leaf in {f'{n:02}.slot' for n in range(1, 49)}):
            return MODIFY, 'EXACT_PROVIDER_SLOT_NAME_NO_ATTEMPT_AUTHORIZATION'
        if (not is_directory and parent == STATE + r'\provider-logs' and
                leaf in {'events.lock', *(f'events.{n}.jsonl' for n in range(4))}):
            return MODIFY, 'EXACT_PROVIDER_LOG_NAME_ROTATION_ONLY'
        if path == STATE + r'\provider-secrets.json' and not is_directory:
            return READ, 'EXACT_PROVIDER_SECRET_READ'
    if (service == 'tunnel' and not is_directory and
            path in (STATE + r'\tunnel\config.yml', STATE + r'\tunnel\credentials.json')):
        return READ, 'EXACT_TUNNEL_CONFIG_CREDENTIAL_READ'
    if path == CODE or path.startswith(CODE + '\\'):
        return 0, 'BLOCKED_INSTALLED_PER_SERVICE_EXECUTABLE_CLOSURE_MISSING'
    return 0, 'NO_NAMED_SERVICE_CAPABILITY'


def removal_routes(child_results, parent_results):
    """DELETE and parent DELETE_CHILD are alternative removal authorities."""
    def granted(rows, right):
        return any(row.get('requested') == right and row.get('qualified') is True and
                   row.get('outcome') == 'ALLOWED' for row in rows)
    child_delete = granted(child_results, 0x10000)
    parent_delete_child = granted(parent_results, 0x40)
    return {'deleteOnChild': child_delete, 'deleteChildOnParent': parent_delete_child,
            'removalPossible': child_delete or parent_delete_child,
            'renameMoveReplacement': 'BLOCKED' if child_delete or parent_delete_child
            else 'UNQUALIFIED_DESTINATION_INSERTION_AND_VOLUME_SEMANTICS',
            'replacementMayNotBeInferredFromCreateAlone': True}


def descriptor_principal_routes(held, descriptor):
    """Conservative global grant ceiling, independent of representative tokens.

    Every standard ALLOW trustee is considered even if absent from all supplied
    tokens. We do not assume a DENY cancels an unsafe ALLOW for every possible
    group/owner/claim combination. This rejects uncertain ACLs, never approves
    universal access semantics. Service SID resolution is native and exact, not
    a dictionary/approval flag provided by the caller.
    """
    path = exact_path(held.path)
    directory = bool(held.info['attributes'] & 0x10)
    dedicated = any(path == root or path.startswith(root + '\\')
                    for root in (T, CODE, STATE))
    violations, records = [], []
    if descriptor.get('unsupported'):
        violations.append('UNSUPPORTED_DESCRIPTOR_SEMANTICS')
    owner = descriptor.get('ownerSid')
    if owner not in (SYSTEM, ADMINS):
        violations.append('OWNER_AUTHORITY_NOT_QUALIFIED:' + str(owner))
    dacl = descriptor.get('dacl', {})
    if not dacl.get('present') or dacl.get('null'):
        violations.append('NULL_OR_ABSENT_DACL')
    # Do not suppress all analysis because service identities are unavailable.
    # Available definite non-service unsafe routes still appear in evidence.
    resolved_services = None
    resolution_error = None
    for ace in dacl.get('aces', []):
        record = {'ace': ace, 'decision': 'OBSERVED'}
        records.append(record)
        if ace.get('kind') != 'ALLOW':
            continue
        if ace.get('inheritOnly'):
            record['decision'] = 'BLOCKED_FUTURE_CHILD_INHERITANCE_UNQUALIFIED'
            violations.append('INHERIT_ONLY_FUTURE_CHILD_GRANT_UNQUALIFIED')
            continue
        sid, mask = ace.get('sid'), ace.get('mappedMask')
        if not isinstance(mask, int):
            violations.append('UNDECODABLE_ALLOW_MASK')
            continue
        if sid in (SYSTEM, ADMINS):
            record['decision'] = 'TRUSTED_WRITER_SID_CEILING_ONLY'
            continue
        principal = ace.get('principal', {})
        if principal.get('resolved') is not True:
            violations.append('UNRESOLVED_ACE_PRINCIPAL:' + str(sid))
            record['decision'] = 'BLOCKED_UNRESOLVED'
            continue
        if resolved_services is None and resolution_error is None:
            try:
                resolved_services = access.resolve_service_sids()
            except win.Blocked as error:
                resolution_error = error.reason
        service = next((name for name, value in (resolved_services or {}).items()
                        if value['sid'] == sid), None)
        ceiling, scope = capability_ceiling(path, service, directory)
        if not dedicated:
            # Existing shared ancestors may have broad READ, but no untrusted
            # mutation route qualifies. The sibling-create refinement remains
            # unsupported and is conservatively rejected.
            ceiling = READ | 0x20
            scope = 'EXISTING_ANCESTOR_READ_ONLY_NO_SIBLING_APPROVAL'
        if mask & ~ceiling:
            violations.append('ALLOW_EXCEEDS_EXACT_PATH_CEILING:' + str(sid))
            record['decision'] = 'BLOCKED_EFFECTIVE_ACCESS_OR_UNCERTAIN_GROUP_ROUTE'
        else:
            record['decision'] = 'WITHIN_CEILING_NOT_UNIVERSAL_QUALIFICATION'
        record.update(capabilityCeiling=ceiling, service=service, scope=scope)
        # Inheritance must not widen a service's exact named path ceiling. No
        # structural proof of every future inherited child is supplied here.
        if (sid not in (SYSTEM, ADMINS) and
                (ace.get('objectInherit') or ace.get('containerInherit'))):
            violations.append('UNTRUSTED_INHERITED_SCOPE_UNQUALIFIED:' + str(sid))
    return {'principals': records, 'violations': violations,
            'serviceResolution': resolved_services,
            'serviceResolutionError': resolution_error,
            'universalClosure': 'BLOCKED_GROUP_CLAIM_OWNER_AND_FUTURE_CHILD_SEMANTICS',
            'operationalEvidence': False}


def inspect_component(held, parent, tokens):
    """Check every individual concrete right on actual retained objects/tokens.

    Actual token classes are labels for required coverage, never evidence of
    trust. The native checker determines token state itself. Representative
    denials do not close arbitrary-principal descriptor analysis.
    """
    if not isinstance(held, win.Held) or (parent is not None and not isinstance(parent, win.Held)):
        return blocked('ACTUAL_HELD_COMPONENT_AND_PARENT_REQUIRED')
    if not isinstance(tokens, dict):
        return blocked('ACTUAL_NATIVE_TOKEN_COVERAGE_REQUIRED')
    rows, blockers = [], []
    path = exact_path(held.path)
    directory = bool(held.info['attributes'] & 0x10)
    try:
        before = held.record()
        descriptor = access.inspect_descriptor(held)
        principal_routes = descriptor_principal_routes(held, descriptor)
        blockers.extend(principal_routes['violations'])
    except win.Blocked as error:
        return blocked(error.reason)
    if set(tokens) != REQUIRED_TOKEN_CLASSES:
        blockers.append('MISSING_OR_EXTRA_REAL_TOKEN_CLASSES')
    for label, token in tokens.items():
        if label not in REQUIRED_TOKEN_CLASSES:
            blockers.append('UNRECOGNIZED_TOKEN_CLASS:' + str(label))
            continue
        if not isinstance(token, access.NativeToken):
            blockers.append('ACTUAL_NATIVE_TOKEN_REQUIRED:' + label)
            continue
        own, parent_rows = [], []
        for right in DIRECTORY_RIGHTS if directory else FILE_RIGHTS:
            result = access.inspect_access(held, token, right,
                                          object_type='directory' if directory else 'file')
            own.append(result)
        if parent is not None:
            for right in DIRECTORY_RIGHTS:
                parent_rows.append(access.inspect_access(parent, token, right,
                                                         object_type='directory'))
        ceiling, scope = capability_ceiling(path, label, directory)
        # Principals ordinary/filtered/restricted have no service exception.
        forbidden = [row for row in own if row.get('requested') in MUTATION and
                     not (row['requested'] & ceiling) and row.get('qualified') is True and
                     row.get('outcome') == 'ALLOWED']
        if forbidden:
            blockers.append('FORBIDDEN_EFFECTIVE_ACCESS:' + label)
        if any(row.get('qualified') is not True for row in own + parent_rows):
            blockers.append('UNQUALIFIED_INDIVIDUAL_RIGHT:' + label)
        removal = removal_routes(own, parent_rows)
        # A service's data capability never excuses mutation of its protected parent.
        if removal['deleteChildOnParent']:
            parent_ceiling, _ = capability_ceiling(parent.path, label, True)
            if not parent_ceiling & 0x40:
                blockers.append('PARENT_DELETE_CHILD_ROUTE:' + label)
        required = [bit for bit in FILE_RIGHTS if ceiling & bit]
        if any(not any(row['requested'] == bit and row.get('qualified') is True and
                       row.get('outcome') == 'ALLOWED' for row in own) for bit in required):
            blockers.append('INTENDED_SERVICE_RIGHT_UNQUALIFIED_OR_DENIED:' + label)
        rows.append({'tokenClass': label, 'capabilityCeiling': ceiling, 'scope': scope,
                     'individualRights': own, 'parentIndividualRights': parent_rows,
                     'removalRoutes': removal})
    try:
        after = held.record()
        if before != after:
            blockers.append('SAME_HANDLE_IDENTITY_OR_DESCRIPTOR_DRIFT')
    except win.Blocked as error:
        blockers.append(error.reason)
        after = None
    # These are source gaps, not caller-supplied attestation slots. No public flag
    # can make arbitrary-principal coverage or a pathname binding complete.
    blockers.extend(('ARBITRARY_PRINCIPAL_GROUP_CLAIM_CLOSURE_UNQUALIFIED',
                     'PARENT_RELATIVE_BINDING_UNQUALIFIED',
                     'REDIRECT_VOLUME_REPARSE_MUTATION_SEMANTICS_UNQUALIFIED'))
    outcome = 'BLOCKED_EFFECTIVE_ACCESS' if any(
        b.startswith(('FORBIDDEN_EFFECTIVE_ACCESS', 'PARENT_DELETE_CHILD_ROUTE'))
        for b in blockers) else 'BLOCKED_UNKNOWN'
    return blocked(';'.join(blockers), outcome=outcome, path=path,
                   parentPath=parent.path if parent else None,
                   handles=[before, after], descriptor=descriptor,
                   principalRoutes=principal_routes, tokenChecks=rows, blockers=blockers)


def check_chain(chain, tokens):
    """Actual read-only per-component checks, with irrevocable delivery blockers.

    No installed-root creation, grants, SCM, secret read, copying or Setup exists
    here. An absent root never qualifies through an ancestor observation.
    """
    if not isinstance(chain, win.Chain) or not chain.held:
        return blocked('ACTUAL_COMPLETE_HELD_CHAIN_REQUIRED')
    if not isinstance(tokens, dict):
        return blocked('ACTUAL_NATIVE_TOKEN_COVERAGE_REQUIRED')
    leaf = exact_path(chain.held[-1].path)
    if not any(leaf == root or leaf.startswith(root + '\\') for root in (T, CODE, STATE)):
        return blocked('EXACT_OPERATIONAL_ALLOWLIST_REQUIRED')
    components = []
    parent = None
    for held in chain.held:
        if parent is not None and ntpath.dirname(held.path) != parent.path:
            return blocked('CHAIN_PARENT_RELATION_MISMATCH', outcome='BLOCKED_CONTINUITY')
        if held.info['volume'] != chain.held[0].info['volume']:
            return blocked('BLOCKED_VOLUME_TRANSITION', outcome='BLOCKED_CONTINUITY')
        components.append(inspect_component(held, parent, tokens))
        parent = held
    return blocked('SOURCE_IMPLEMENTATION_PARTIAL_OPERATIONAL_INPUTS_UNAVAILABLE',
                   outcome='BLOCKED_LAUNCH_CHAIN_UNQUALIFIED', components=components,
                   sourceBlockers=['ARBITRARY_PRINCIPAL_CLOSURE', 'HANDLE_RELATIVE_BINDING',
                                   'RENAME_REDIRECT_VOLUME_AUTHORITY',
                                   'RESTRICTED_MIC_PRIVILEGE_UNSUPPORTED_CONDITIONS'],
                   operationalPrerequisites=['ACTUAL_SERVICE_SIDS_AND_TOKENS',
                       'INSTALLED_PER_SERVICE_EXECUTABLE_CONFIG_DEPENDENCY_INVENTORY',
                       'SCM_NSSM_REGISTRY_AND_ENVIRONMENT_AUTHORITY',
                       'PROTECTED_BOOTSTRAP_INTERPRETER_DLL_STDLIB_TEMP_PATH_CHAIN',
                       'COMPLETE_52_FILE_1691_MAP_STAGE_AND_INSTALLED_READBACK',
                       'CREATION_OBSERVER_AND_PARENT_RELATIVE_CONTINUITY'])
