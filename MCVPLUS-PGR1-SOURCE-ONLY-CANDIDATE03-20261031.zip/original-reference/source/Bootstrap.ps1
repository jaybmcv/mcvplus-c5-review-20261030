[CmdletBinding()]
param(
 [Parameter(Mandatory)][ValidateSet('LocalValidation','ProtectedStage','Apply','Setup')][string]$Mode,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedSourceManifestSha256,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedBootstrapSha256,
 [Parameter(Mandatory)][string]$PythonExecutable,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedPythonSha256
)
if ($Mode -ne 'LocalValidation') {throw 'UNCONDITIONAL_OPERATIONAL_ADMISSION_BLOCK'}
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$clock=[Diagnostics.Stopwatch]::StartNew()
$root='D:\OpenClaw-workspace\artifacts\mcvplus-c5-path-gate-validation-20261030\run-5e810f64956a463593a4ec00c4a610f2'
$source=$root+'\source'
if ($PSCommandPath -cne ($source+'\Bootstrap.ps1')) {throw 'EXACT_LOCAL_NAMESPACE_REQUIRED'}
$locks=New-Object 'Collections.Generic.List[IDisposable]';$p=$null;$ownedStarted=$false;$terminationAttempted=$false;$childClock=$null
try {
 function Read-C5PinnedStream([string]$Path,[string]$ExpectedHash,[bool]$ReadBytes=$false) {
  # Same retained stream for hash and any parse bytes. FileShare.Read denies
  # write/delete sharing for manifest, executing bootstrap, interpreter and sources.
  $s=[IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read);$locks.Add($s)
  $sha=[Security.Cryptography.SHA256]::Create()
  try {$hash=[BitConverter]::ToString($sha.ComputeHash($s)).Replace('-','').ToLowerInvariant()} finally {$sha.Dispose()}
  if ($hash -cne $ExpectedHash) {throw ('EXTERNAL_OR_SOURCE_PIN_MISMATCH: '+$Path)}
  $bytes=$null
  if ($ReadBytes) {
   $s.Position=0;$memory=New-Object IO.MemoryStream
   try {$s.CopyTo($memory);$bytes=$memory.ToArray()} finally {$memory.Dispose()}
  }
  return @{stream=$s;bytes=$bytes;hash=$hash;length=$s.Length}
 }
 $bootstrapHeld=Read-C5PinnedStream $PSCommandPath $ExpectedBootstrapSha256
 if ($PythonExecutable -notmatch '^[A-Z]:\\' -or $PythonExecutable -match '["\r\n]' -or [IO.Path]::GetFullPath($PythonExecutable) -cne $PythonExecutable) {throw 'EXACT_INTERPRETER_PATH_REQUIRED'}
 $interpreterHeld=Read-C5PinnedStream $PythonExecutable $ExpectedPythonSha256
 $manifestHeld=Read-C5PinnedStream ($source+'\SOURCE-MANIFEST.json') $ExpectedSourceManifestSha256 $true
 $manifest=[Text.Encoding]::UTF8.GetString($manifestHeld.bytes)|ConvertFrom-Json
 if ($manifest.namespace -cne $root -or $manifest.sourceDirectory -cne $source -or $manifest.reviewedHead -cne '98eeddabbd66b4227d1f832898aa3477ebe7d270') {throw 'SOURCE_IDENTITY'}
 $expected=@{'SOURCE-MANIFEST.json'=$true};$dirs=@{};$pins=@{}
 foreach ($pin in $manifest.files) {
  $rel=[string]$pin.path
  if (!$rel -or $rel -match '[^A-Za-z0-9_./-]|(^|/)\.{1,2}(/|$)|^/|//|[. ](/|$)|(^|/)(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])([./]|$)' -or $expected.ContainsKey($rel)) {throw 'SOURCE_PATH_OR_COLLISION'}
  $expected[$rel]=$true;$pins[$rel]=$pin;$d=Split-Path -Parent $rel
  while ($d) {$dirs[$d.Replace('\','/')]=$true;$d=Split-Path -Parent $d}
 }
 foreach ($required in @('Bootstrap.ps1','run.py','windows_api.py','gate.py','FIXTURE-MATRIX.json','policy/PATH-SPECIFIC-GATE-REVISION.md','policy/BOUNDED-LOCAL-VALIDATION-PLAN.md','policy/STATE-ROOT-BINDINGS.md','policy/LOCAL-POLICY.json')) {if (!$pins.ContainsKey($required)) {throw 'REQUIRED_SOURCE_MISSING'}}
 if ($pins['Bootstrap.ps1'].sha256 -cne $ExpectedBootstrapSha256) {throw 'BOOTSTRAP_MANIFEST_BINDING'}
 $queue=New-Object 'Collections.Generic.Queue[string]';$queue.Enqueue($source)
 while ($queue.Count) {
  $dir=$queue.Dequeue()
  if ((Get-Item -LiteralPath $dir -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'SOURCE_REPARSE'}
  foreach ($i in Get-ChildItem -LiteralPath $dir -Force) {
   if ($i.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'SOURCE_REPARSE'}
   $rel=$i.FullName.Substring($source.Length+1).Replace('\','/')
   if ($i.PSIsContainer) {if (!$dirs.ContainsKey($rel)) {throw 'EXTRA_SOURCE_DIRECTORY'};$queue.Enqueue($i.FullName)}
   elseif (!$expected.ContainsKey($rel)) {throw 'EXTRA_SOURCE_FILE'}
  }
 }
 foreach ($pin in $manifest.files) {
  if ($pin.sha256 -cnotmatch '^[a-f0-9]{64}$' -or $pin.bytes -lt 0) {throw 'INVALID_PIN'}
  $heldSource=Read-C5PinnedStream ($source+'\'+$pin.path.Replace('/','\')) $pin.sha256
  if ($heldSource.length -ne $pin.bytes) {throw 'SOURCE_SIZE_DRIFT'}
 }
 $policyHeld=Read-C5PinnedStream ($source+'\policy\LOCAL-POLICY.json') $pins['policy/LOCAL-POLICY.json'].sha256 $true
 $localPolicy=[Text.Encoding]::UTF8.GetString($policyHeld.bytes)|ConvertFrom-Json
 if ($localPolicy.nativeLaunchEnabled -ne $true -or $localPolicy.compilationEnabled -ne $false -or $localPolicy.bounds.nativeChildSeconds -ne 30) {throw 'BLOCKED_LOCAL_POLICY_ADMISSION'}
 # No compile/Add-Type. Python self-assigns the sole runner to a new owned job
 # before fixtures. Failure to assign blocks activity. Local interpreter/dependency
 # loading is NOT qualified as a protected operational launcher.
 if (Test-Path -LiteralPath ($root+'\receipts')) {throw 'RECEIPT_NAMESPACE_COLLISION_NO_RETRY'}
 if (Test-Path -LiteralPath ($root+'\fixtures')) {throw 'FIXTURE_NAMESPACE_COLLISION_NO_RETRY'}
 if ($clock.Elapsed.TotalSeconds -ge 865) {throw 'TOTAL_BOUND_STOP_BEFORE_NATIVE_LAUNCH'}
 $deadline=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()/1000.0 + 28
 $psi=New-Object Diagnostics.ProcessStartInfo
 $psi.FileName=$PythonExecutable
 $psi.Arguments='-I -B "'+$source+'\run.py" --mode=LocalValidation --manifest='+$ExpectedSourceManifestSha256+' --bootstrap='+$ExpectedBootstrapSha256+' --deadline='+$deadline.ToString('R',[Globalization.CultureInfo]::InvariantCulture)
 $psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.WorkingDirectory=$source
 $p=New-Object Diagnostics.Process;$p.StartInfo=$psi
 $childClock=[Diagnostics.Stopwatch]::StartNew();$started=$p.Start()
 if (!$started) {throw 'BLOCKED_CONTAINMENT_RUNNER_START'}
 $ownedStarted=$true
 $ownedNativeHandle=$p.Handle;$ownedPid=$p.Id;$ownedStart=$p.StartTime.ToUniversalTime().ToString('o')
 $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
 # One sole native/check child, including all cases: 28-second wait plus
 # at most the remainder of its 30-second lifetime for one termination attempt.
 $remaining=[Math]::Max(0,[int]((28-$childClock.Elapsed.TotalSeconds)*1000))
 $timeout=!$p.WaitForExit($remaining)
 if ($timeout) {
  # Exact Process instance created here, never a name/shared-process sweep.
  $terminationAttempted=$true;$p.Kill()
  $killWait=[Math]::Max(0,[int]((30-$childClock.Elapsed.TotalSeconds)*1000));$p.WaitForExit($killWait)|Out-Null
 }
 $exit=if($p.HasExited){$p.ExitCode}else{$null}
 if (!$p.HasExited) {throw 'BLOCKED_CONTAINMENT_OWNED_RUNNER_DID_NOT_EXIT'}
 $childObservedSeconds=$childClock.Elapsed.TotalSeconds
 # Parent captures these streams. Never write into collided destinations here.
 $captureComplete=$true
 foreach ($capture in @(@{name='stdout';task=$stdout},@{name='stderr';task=$stderr})) {
  $captureWait=[Math]::Max(0,[Math]::Min(1000,[int]((900-$clock.Elapsed.TotalSeconds)*1000)))
  if (!$capture.task.Wait($captureWait)) {$captureComplete=$false;Write-Warning ('BLOCKED_CAPTURE_INCOMPLETE: '+$capture.name);continue}
  # Result is read only after finite successful completion, never unbounded GetResult.
  $text=[string]$capture.task.Result
  if ([Text.Encoding]::UTF8.GetByteCount($text) -gt 8388608) {$captureComplete=$false;Write-Warning ('BLOCKED_CAPTURE_SIZE: '+$capture.name);continue}
  if ($capture.name -eq 'stdout') {Write-Output $text} else {[Console]::Error.Write($text)}
 }
 [pscustomobject]@{status=$(if($childObservedSeconds -gt 30){'BLOCKED_CHILD_BOUND'}elseif($timeout){'BLOCKED_CHILD_TIMEOUT'}elseif(!$captureComplete){'BLOCKED_CAPTURE'}elseif($exit -ne 0){'BLOCKED_RUNNER_EXIT'}else{'LOCAL_RUNNER_EXITED_NOT_OPERATIONAL_QUALIFICATION'});pid=$ownedPid;startUtc=$ownedStart;executable=$PythonExecutable;executableSha256=$ExpectedPythonSha256;exitCode=$exit;hasExited=$p.HasExited;timeout=$timeout;childLifetimeBoundSeconds=30;childObservedSeconds=$childObservedSeconds;captureComplete=$captureComplete;preStartupJobContainment='UNQUALIFIED_NOT_ESTABLISHED';sourceManifestSha256=$ExpectedSourceManifestSha256;bootstrapSha256=$ExpectedBootstrapSha256;elapsedSeconds=$clock.Elapsed.TotalSeconds;job='PG-R1-run-5e810f64956a463593a4ec00c4a610f2; actual self-assignment/query in receipts';postExitJobQuery='UNQUALIFIED_PARENT_INDEPENDENT_REVIEW_REQUIRED'}|ConvertTo-Json
} finally {
 if ($ownedStarted -and !$p.HasExited -and !$terminationAttempted) {
  try {$terminationAttempted=$true;$p.Kill();$killWait=[Math]::Max(0,[int]((30-$childClock.Elapsed.TotalSeconds)*1000));if (!$p.WaitForExit($killWait)) {[Console]::Error.WriteLine('BLOCKED_CONTAINMENT_OWNED_RUNNER_SURVIVES')}} catch {[Console]::Error.WriteLine('BLOCKED_CONTAINMENT_TERMINATION_ERROR: '+$_.Exception.Message)}
 }
 foreach ($lock in $locks) {$lock.Dispose()}
}
