# PRE-FREEZE-CORRECTION-MATRIX - R01-R10

Status: PREPARED, NOT FROZEN/ACCEPTED. Zero validation consumed. No source import, gate/native API, token probe, compilation, fixture or case execution. Only edits, static parsing and SHA256 sealing.

The four requested notes were read completely. The b52d6850 seal is superseded. Fixed means a source correction, not runtime success. BLOCKED means implementation/evidence absent; no full policy/launch/containment qualification is claimed.

| Finding | Disposition | Correction / missing proof |
| --- | --- | --- |
| R01 | FIXED source-byte/stream acceptance; protected launcher remains BLOCKED | Bootstrap Read-C5PinnedStream hashes and parses the same manifest stream; bootstrap/interpreter/source streams retained across child/capture. run.py executes verified helper bytes. Direct entry is unauthorized, no protected identity/ancestor claim. |
| R02 | FIXED mode acceptance and specific static predicate | Exact-one/literal/local guard before helpers and immediately after parse; argparse abbreviation disabled. L26 compares initial/post-parse AST predicates, rejection bodies and placement plus exact Bootstrap prefix. No guard/case invoked during preparation. |
| R03 | FIXED unsafe component acceptance; exact capability engine BLOCKED | No scoped/sibling arguments and no component PASS path. Individual child mutations include 0x40; parent delete/security/metadata grants can reject independently. Empty/incomplete/combined cases fall back BLOCKED_UNKNOWN. L02-L05 classifier observations reference actual synthetic right results. Operational decision always blocked. |
| R04 | FIXED false PASS; rejection/injection implementation remains BLOCKED | L21/L23/L24/L27 now BLOCKED limited observations, not actual drift/substitution/pin/native-failure rejection tests. No identityMismatchBlocks claim. L17 bare duplicate observation and L25 absent compiler path also cannot claim rejection PASS. No additional execution/case added. |
| R05 | PARTIALLY FIXED; full containment/deadline proof BLOCKED | Sole child wait 28s plus one termination wait limited by remaining 30s; capture waits <=1000ms each. Monotonic per-case deadline. Existing-job error183 rejected and active-process limit1 retained. No pre-startup job proof, independent post-exit handle/query or guaranteed interruptible OS/preflight calls; parent outer900s watchdog/envelope required. L27 remains BLOCKED. |
| R06 | PARTIALLY FIXED; authority/directory continuity BLOCKED | Full parent chain retained through child close. Fixed creation descriptor, exact BA owner/protected BA+SYSTEM OICI/full-control DACL readback and same-held descriptor drift checks. No caller SDDL. Absolute-path resolution, parent mutation-authority analysis, handle-relative directories and untrusted-token observer/window closure missing; no protection approval. |
| R07 | FIXED broad negative-control acceptance | Structured Blocked.reason/win32; exact create collision80/183, BLOCKED_REPARSE or BLOCKED_HARDLINK required respectively. Unrelated errors BLOCKED and retained; prior observations/source errors and available sentinels preserved. Hardlink full post-preservation stays UNQUALIFIED. |
| R08 | BLOCKED unsupported semantics/operational proof; partial synthetic definitions extended | Generic-read and deny-only service-shaped contexts added to existing IDs. Supported common-ACE Authz comparisons remain synthetic only. Actual tokens/service SIDs, MIC/restricted/privilege/owner/claims/closure and exact path/service capability engine are unsupported and BLOCKED. No accounts/services/SCM or token acquisition. |
| R09 | FIXED misleading fields; complete preservation/accounting/envelope BLOCKED | NOT_RUN subchecks remain NOT_RUN; simulation propagated. L19 trusted-owner observer, baseline hash and root readback without full comparison remain BLOCKED; read failures UNQUALIFIED. Runner membership not empty-job proof. Accounting explicitly pre-aggregate snapshot; receipt budget reserves32MiB logs; parent final census/envelope still required. |
| R10 | FIXED bundle/docs consistency; NOT FROZEN/ACCEPTED | Active source-only manifest includes code, helper/reference, matrix, normative/root-binding policy, docs and this source matrix. Admission enforces local policy flags/bound; docs state actual <=30s child and missing proof. Old root drafts superseded. Fresh independent static review/freeze required. |

## Exact prepared source-byte hashes

All hashes below identify source bytes after corrections, not executed results. This source copy omits its own hash and final manifest hash to avoid a circular seal. The manifest binds this matrix; the root copy carries the final pin appendix for parent review only. Neither is external approval.

| Source-relative file | Bytes | SHA256 |
| --- | ---: | --- |
| Bootstrap.ps1 | 9079 | `da02652997db32f73b8ba0fa80f89087761a8bae6613bbd6fbf3b5919ddd3569` |
| FIXTURE-MATRIX.json | 44324 | `cfb8e2f7a9d0d1d49eb8e6475363f8d1b6df419856a92b25080fb2f1e056601d` |
| gate.py | 4775 | `5b4bcabc1aca1a9b856b263e903ac18b0eeb0f07863f603c366c8a7beb8d3bba` |
| IMPLEMENTATION-NOTES.md | 10003 | `29ae0c0c4d82f8efe1a7839dd7562361d5a975918ab44af98ecd8ce70732d31f` |
| policy/BOUNDED-LOCAL-VALIDATION-PLAN.md | 10983 | `03af329888c2fd680660def9dc0301690876ed1a42256a3448bbc75606d35149` |
| policy/LOCAL-POLICY.json | 2681 | `fec2b6264654502f69ff79d803a0174a6d521c2e6cbac5e26cb517ad8436fc36` |
| policy/PATH-SPECIFIC-GATE-REVISION.md | 14406 | `50764c09bddd0c6891d2ccd97195c94f16508c8436a0bbb17641cf04d17718b2` |
| policy/STATE-ROOT-BINDINGS.md | 10043 | `12af2adfdf81ce8c1953dcf40f711506d473ba8f9233ad265fd1101364c06715` |
| reference/REVIEWED-REVISION-MANIFEST.json.txt | 2448 | `19867043a03c15a7e9f010f53369b8c6d3adefe15878db1852338966e283f3b3` |
| reference/REVIEWED-SOURCE-MAP.json.txt | 731936 | `6f37ef601c5dcd52b75d4142f41be498fd6e57a3dd969392874a32e00b9172c1` |
| reference/TRUST-LAUNCH.md.txt | 5263 | `6b1c48b18af401f343d366d31d1b682abd2aef0e3257b563e526dc2879d65ecd` |
| RUN-INSTRUCTIONS.md | 6177 | `0ca5eb810aee66b0f06440af4239d33df352201141b0feb90d3f3babc3125114` |
| run.py | 32048 | `ff222f501d1c4c2d37e0fd02342ccc5c316c1ac0b09628e64f6c0d113ce66289` |
| windows_api.py | 18164 | `9b4b3a0478658f71771fd9cd3425d6ca75467cbc668f887773738576a8a951b1` |
