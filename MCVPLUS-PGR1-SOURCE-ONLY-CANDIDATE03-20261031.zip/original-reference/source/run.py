"""Single authorized future 28-ID run. NOT executed during preparation.
Parent must freeze external source/bootstrap pins before invoking Bootstrap.ps1.
"""
import sys
if sys.argv.count('--mode=LocalValidation')!=1 or any(x.startswith('--mode') and x!='--mode=LocalValidation' for x in sys.argv):
    raise SystemExit('UNCONDITIONAL_OPERATIONAL_ADMISSION_BLOCK')
import argparse
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import threading
import time
import traceback

ROOT=Path(r'D:\OpenClaw-workspace\artifacts\mcvplus-c5-path-gate-validation-20261030\run-5e810f64956a463593a4ec00c4a610f2')
SOURCE=ROOT/'source'
def digest(data):return hashlib.sha256(data).hexdigest()
def utc():
    import datetime
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
parser=argparse.ArgumentParser(allow_abbrev=False)
parser.add_argument('--mode',required=True);parser.add_argument('--manifest',required=True);parser.add_argument('--bootstrap',required=True);parser.add_argument('--deadline',type=float,required=True)
args=parser.parse_args()
if args.mode!='LocalValidation' or sys.argv.count('--mode=LocalValidation')!=1 or any(x.startswith('--mode') and x!='--mode=LocalValidation' for x in sys.argv):
    raise SystemExit('UNCONDITIONAL_OPERATIONAL_ADMISSION_BLOCK')
if Path(__file__)!=SOURCE/'run.py':raise SystemExit('EXACT_LOCAL_NAMESPACE_ONLY')
if len(args.manifest)!=64 or len(args.bootstrap)!=64:raise SystemExit('EXTERNAL_PINS_REQUIRED')
raw=(SOURCE/'SOURCE-MANIFEST.json').read_bytes()
if digest(raw)!=args.manifest or digest((SOURCE/'Bootstrap.ps1').read_bytes())!=args.bootstrap:raise SystemExit('EXTERNAL_PIN_MISMATCH')
manifest=json.loads(raw);pins={p['path']:p for p in manifest['files']}
if len(pins)!=len(manifest['files']):raise SystemExit('MANIFEST_COLLISION')
allowed=set(pins)|{'SOURCE-MANIFEST.json'}
actual=set()
for directory,dirs,files in os.walk(SOURCE,followlinks=False):
    for name in dirs+files:
        p=Path(directory)/name
        if p.is_symlink() or (p.stat(follow_symlinks=False).st_file_attributes&0x400):raise SystemExit('SOURCE_REPARSE')
    for name in files:actual.add((Path(directory)/name).relative_to(SOURCE).as_posix())
if actual!=allowed:raise SystemExit('EXTRA_OR_MISSING_SOURCE')
verified_bytes={}
for rel,pin in pins.items():
    if rel.startswith('/') or '\\' in rel or ':' in rel or '..' in rel.split('/'):raise SystemExit('SOURCE_PATH')
    data=(SOURCE/rel).read_bytes()
    if len(data)!=pin['bytes'] or digest(data)!=pin['sha256']:raise SystemExit('SOURCE_DRIFT')
    verified_bytes[rel]=data
# Only after independent pins and exact source inventory do candidate modules load.
policy=json.loads(verified_bytes['policy/LOCAL-POLICY.json'])
if (policy.get('helperLoadEnabled') is not True or policy.get('fixtureCreationEnabled') is not True or
    policy.get('nativeLaunchEnabled') is not True or policy.get('compilationEnabled') is not False or
    policy.get('bounds',{}).get('nativeChildSeconds')!=30):
    raise SystemExit('BLOCKED_LOCAL_POLICY_ADMISSION')
def load(name):
    spec=importlib.util.spec_from_file_location(name,SOURCE/(name+'.py'))
    module=importlib.util.module_from_spec(spec)
    # Execute exactly the bytes already externally pinned; never reread candidate
    # helper by pathname after verification. Python bytecode is in-memory only.
    exec(compile(verified_bytes[name+'.py'],str(SOURCE/(name+'.py')),'exec'),module.__dict__)
    return module
win=load('windows_api');gate=load('gate')
matrix=json.loads(verified_bytes['FIXTURE-MATRIX.json'])
if [c['id'] for c in matrix['cases']]!=[f'L{i:02}' for i in range(1,29)]:raise SystemExit('EXACT_28_IDS_ONCE')
# Wall-clock launcher budget is converted once; in-process deadlines are monotonic.
deadline=time.monotonic()+max(0,min(30,args.deadline-time.time()))
active_deadline=deadline
finished=False
def watchdog():
    while not finished:
        if time.monotonic()>min(deadline,active_deadline):os._exit(124)
        time.sleep(.05)
threading.Thread(target=watchdog,daemon=True).start()

job=None;out=None;held=[];rows=[];evidence=[];payload=0;output_bytes=0
stop=None;start=utc();run_out=ROOT/'receipts';fixture_root=ROOT/'fixtures'
def create_dir(p):
    h=win.new_directory(str(p));held.append(h);return h
def create_file(p,data=b'synthetic, not a credential or ledger entry\n'):
    global payload
    if payload+len(data)>512*1024*1024:raise win.Blocked('FIXTURE_PAYLOAD_BOUND')
    h=win.new_file(str(p),data);held.append(h);payload+=len(data);return h
def write_evidence(name,value):
    global output_bytes
    data=json.dumps(value,indent=2,sort_keys=True).encode()
    if output_bytes+len(data)>2*1024**3-32*1024**2:raise win.Blocked('RETAINED_RECEIPT_BOUND_WITH_LOG_RESERVE')
    h=win.new_file(str(run_out/name),data);held.append(h);output_bytes+=len(data)
    evidence.append({'path':'receipts/'+name,'bytes':len(data),'sha256':h.hash(),'held':h.record()})
def observation(name,status,detail,actual=True,simulated=False):
    return {'name':name,'status':status,'detail':detail,'actual':actual,'simulated':simulated,'operationalEvidence':False}
def planned(case,done,status='BLOCKED'):
    names={x['name'] for x in done}
    return done+[observation(s['name'],status,'Not attempted after stop' if status=='NOT_RUN' else 'Unsupported or no actual token/continuity demonstration; not inferred from synthetic checks',False) for s in case['subchecks'] if s['name'] not in names]

def semantic(case,row):
    mismatch=False;checks=[];rights=[]
    row['subchecks']=checks
    for text in case['descriptors']:
        for name in case['contexts']:
            context=matrix['syntheticContextDefinitions'][name]
            for right in matrix['individualRights']:
                requested=int(right['mask'],16)
                if mismatch:
                    rights.append({'descriptor':text,'tokenContext':context,'contextName':name,'name':right['name'],'desiredAccess':requested,'reference':{'outcome':'NOT_RUN'},'gate':{'outcome':'NOT_RUN'},'comparison':'NOT_RUN','reason':'SEMANTIC_MISMATCH_STOP'})
                    continue
                g=gate.evaluate(text,context,requested)
                try:r=win.reference(text,context,requested)
                except win.Blocked as e:r={'outcome':'UNQUALIFIED','resultProduced':False,'attempted':True,'nativeInvocation':'NOT_COMPLETED_OR_NOT_REACHED_SEE_ERROR','reason':str(e),'actualToken':False,'synthetic':True}
                comparison='NOT_COMPARABLE'
                if g.get('qualified') and r['outcome'] in ('ALLOWED','DENIED'):
                    comparison='MATCH' if g['outcome']==r['outcome'] else 'MISMATCH'
                    mismatch|=comparison=='MISMATCH'
                rights.append({'descriptor':text,'tokenContext':context,'contextName':name,'name':right['name'],'desiredAccess':requested,'reference':r,'gate':g,'comparison':comparison})
    row['individualRights']=rights
    row['fixtureDescriptors']=case['descriptors']
    row['tokenProvenance']={'syntheticContexts':matrix['syntheticContextDefinitions'],'actualTokenAcquisitions':0,'realTokenClasses':{n:'UNQUALIFIED_NOT_ACQUIRED_NO_RETRY' for n in matrix['realTokenClassesRequired']},'privilegeEnablement':False,'duplicateTokenCalls':0}
    comparable=[r for r in rights if r['comparison'] in ('MATCH','MISMATCH')]
    checks.append(observation('supported-common-ace-authz-comparison','FAIL' if mismatch else 'PASS' if comparable else 'BLOCKED',{'comparisonCount':len(comparable),'unqualifiedCount':len(rights)-len(comparable)},True,True))
    # Every named PASS must cite its own exact invoked right and expected result.
    normal='synthetic-ordinary';filtered='synthetic-filtered-admin'
    pg='synthetic-postgres';provider='synthetic-provider';tunnel='synthetic-tunnel'
    mutation=[2,4,0x10,0x40,0x100,0x10000,0x40000,0x80000]
    tests={
      'L01':[('ordinary-mutation-denials',0,normal,mutation,'DENIED'),('filtered-admin-not-trusted',0,filtered,mutation,'DENIED'),('intended-read-execute',0,normal,[1,0x20,0x20000],'ALLOWED')],
      'L02':[('ancestor-add-subdirectory-only',0,normal,[4],'ALLOWED'),('delete-and-parent-delete-child-negative',0,normal,[0x40,0x10000],'DENIED'),('write-dac-owner-ea-attribute-negative',0,normal,[0x10,0x100,0x40000,0x80000],'DENIED')],
      'L03':[('parent-delete-child-allowed',0,normal,[0x40],'ALLOWED'),('child-delete-denied',1,normal,[0x10000],'DENIED')],
      'L04':[('child-delete-allowed',1,normal,[0x10000],'ALLOWED'),('parent-delete-child-denied',0,normal,[0x40],'DENIED')],
      'L05':[('file-write-data',0,normal,[2],'ALLOWED'),('file-append-data',1,normal,[4],'ALLOWED'),('directory-add-file',0,normal,[2],'ALLOWED'),('directory-add-subdirectory',1,normal,[4],'ALLOWED')],
      'L06':[('write-dac',0,normal,[0x40000],'ALLOWED'),('write-owner',1,normal,[0x80000],'ALLOWED')],
      'L07':[('file-write-ea',0,normal,[0x10],'ALLOWED'),('file-write-attributes',1,normal,[0x100],'ALLOWED'),('directory-write-ea',0,normal,[0x10],'ALLOWED'),('directory-write-attributes',1,normal,[0x100],'ALLOWED')],
      'L08':[('generic-write-map',0,normal,[2,4,0x10,0x100],'ALLOWED'),('generic-all-map',1,normal,mutation,'ALLOWED'),('inherit-only-ace',2,normal,[2],'DENIED'),('inherited-effective-ace',3,normal,[2],'ALLOWED'),('deny-before-allow',4,normal,[2],'DENIED'),('allow-before-deny-noncanonical',5,normal,[2],'ALLOWED')],
      'L09':[('deny-only-grant-ineffective',0,filtered,mutation,'DENIED')],
      'L11':[('postgres-modify-own-subtree',0,pg,[2,4,0x10,0x100,0x10000],'ALLOWED'),('cross-service-denied',0,provider,mutation,'DENIED'),('code-denied',1,pg,mutation,'DENIED')],
      'L12':[('provider-slots-modify-dummy-names-only',0,provider,[2,4,0x10,0x100,0x10000],'ALLOWED'),('tunnel-read-only',1,tunnel,mutation,'DENIED'),('operator-slots-denied',2,provider,mutation,'DENIED')],
      'L13':[('provider-secret-write-denied',0,provider,mutation,'DENIED'),('tunnel-config-write-denied',1,tunnel,mutation,'DENIED'),('install-receipt-write-denied',2,provider,mutation,'DENIED'),('intended-service-read',0,provider,[1,0x20000],'ALLOWED')],
      'L14':[('service-modify-on-state-root',0,provider,[2,4,0x10000],'ALLOWED'),('inherited-service-modify',0,provider,[2],'ALLOWED')]}
    tests['L08'].append(('generic-read-map',6,normal,[1,8,0x80,0x20000,0x100000],'ALLOWED'))
    tests['L14'].append(('deny-only-service-group',0,'synthetic-deny-only-service',mutation,'DENIED'))
    for name,index,ctx,masks,expected in tests.get(case['id'],[]):
        selected=[x for x in rights if x['descriptor']==case['descriptors'][index] and x['contextName']==ctx and x['desiredAccess'] in masks]
        complete=len(selected)==len(masks) and all(x['comparison'] in ('MATCH','MISMATCH') for x in selected)
        valid=complete and all(x['gate']['outcome']==x['reference']['outcome']==expected for x in selected)
        if complete and not valid:mismatch=True
        checks.append(observation(name,'PASS' if valid else 'FAIL' if complete else 'BLOCKED',{'scope':'SYNTHETIC_DACL_ONLY','descriptorIndex':index,'context':ctx,'requestedMasks':masks,'expected':expected,'results':selected,'noActualPathOrTokenQualification':True},True,True))
    if case['id'] in ('L02','L03','L04','L05') and not mismatch:
        child_indexes=[1] if case['id'] in ('L02','L03','L04') else [0,1]
        for index in child_indexes:
            selected_child=[x for x in rights if x['descriptor']==case['descriptors'][index] and x['contextName']==normal]
            selected_parent=[x for x in rights if x['descriptor']==case['descriptors'][0] and x['contextName']==normal] if case['id']!='L05' else []
            child=[x['gate'] for x in selected_child];parent=[x['gate'] for x in selected_parent]
            decision=gate.classify_component(child,parent)
            # Reference-confirmed concrete grants justify a rejection observation.
            danger_child={2,4,0x10,0x40,0x100,0x10000,0x40000,0x80000}
            danger_parent={0x10,0x40,0x100,0x10000,0x40000,0x80000}
            demonstrated=any(x['comparison']=='MATCH' and x['reference']['outcome']=='ALLOWED' and x['desiredAccess'] in masks for selected,masks in ((selected_child,danger_child),(selected_parent,danger_parent)) for x in selected)
            expected='BLOCKED_EFFECTIVE_ACCESS' if demonstrated else 'BLOCKED_UNKNOWN'
            if decision!=expected:mismatch=True
            checks.append(observation('parent-child-route-classification-'+str(index),'FAIL' if decision!=expected else 'PASS' if demonstrated else 'BLOCKED',{'decision':decision,'expectedRejection':expected,'referenceConfirmedForbiddenGrant':demonstrated,'scope':'SYNTHETIC_REJECTION_ONLY_NO_SIBLING_OR_SCOPED_APPROVAL'},True,True))
    # Each normative named scenario stays blocked unless its specific proof exists.
    # Synthetic matches alone cannot close real tokens, owner/MIC or full-chain proof.
    row['subchecks']=planned(case,checks)
    row['status']='FAIL' if mismatch else 'BLOCKED'
    row['gateResult']='BLOCKED_UNKNOWN' if not comparable else 'SYNTHETIC_SEMANTICS_OBSERVED_NOT_PATH_QUALIFICATION'
    row['reason']='REFERENCE_GATE_MISMATCH' if mismatch else 'Supported synthetic DACL results recorded; required actual-token/unsupported/full-chain subchecks remain unqualified'
    return mismatch

def sentinel(h):return {'hash':h.hash(),'held':h.record()}
def fixtures(case,row):
    n=int(case['id'][1:]);done=[];base=fixture_root/case['id']
    row['subchecks']=done
    create_dir(base)
    row['handles'].append(held[-1].record())
    if n in (15,22):
        h=create_file(base/'collision.txt');before=sentinel(h);row['preSentinel']=before
        try:
            win.new_file(str(base/'collision.txt'),b'forbidden overwrite')
            raise RuntimeError('EXCLUSIVE_CREATE_UNEXPECTED_SUCCESS')
        except win.Blocked as e:
            row['postSentinel']=sentinel(h)
            if before!=row['postSentinel']:raise RuntimeError('COLLISION_SENTINEL_CHANGED')
            expected=e.reason=='BLOCKED_COLLISION_OR_FILE_CREATE' and e.win32 in (80,183)
            done.append(observation('preexisting-file' if n==15 else 'receipt-collision','PASS' if expected else 'BLOCKED',{'error':str(e),'reason':e.reason,'win32':e.win32,'exactCollisionGuardReached':expected,'sentinelUnchanged':True,'destinationWriteProof':'CREATE_NEW failed at collision before write' if expected else 'UNQUALIFIED_UNRELATED_FAILURE'}))
        if n==15:
            directory_before=next(x for x in held if x.path==str(base)).record()
            try:win.new_directory(str(base))
            except win.Blocked as e:
                expected=e.reason=='BLOCKED_COLLISION_OR_DIRECTORY_CREATE' and e.win32 in (80,183)
                directory_after=next(x for x in held if x.path==str(base)).record()
                if directory_before!=directory_after:raise RuntimeError('DIRECTORY_COLLISION_SENTINEL_CHANGED')
                done.append(observation('preexisting-directory','PASS' if expected else 'BLOCKED',{'error':str(e),'reason':e.reason,'win32':e.win32,'before':directory_before,'after':directory_after,'exactCollisionGuardReached':expected}))
            else:raise RuntimeError('DIRECTORY_COLLISION_UNEXPECTED_SUCCESS')
        row['gateResult']='BLOCKED_COLLISION'
    elif n==16:
        target=create_file(base/'target.txt');row['preSentinel']=sentinel(target)
        # Single supported CreateSymbolicLink attempt with no privilege retry.
        path=base/'link.txt'
        if not win.CreateSymbolicLink(str(path),str(base/'target.txt'),0):
            done.append(observation('symlink','BLOCKED',f'CreateSymbolicLink unavailable WIN32_{win.C.get_last_error()}'))
        else:
            try:
                unexpected=win.Held(str(path));unexpected.close()
            except win.Blocked as e:done.append(observation('symlink','PASS' if e.reason=='BLOCKED_REPARSE' else 'BLOCKED',{'error':str(e),'reason':e.reason,'win32':e.win32,'exactReparseGuardReached':e.reason=='BLOCKED_REPARSE'}))
            else:raise RuntimeError('REPARSE_NOT_REJECTED')
        row['postSentinel']=sentinel(target)
        if row['preSentinel']!=row['postSentinel']:raise RuntimeError('REPARSE_TARGET_CHANGED')
        row['gateResult']='BLOCKED_REPARSE'
    elif n==17:
        # No filesystem API is called on rejected path candidates.
        bad=[str(base/'..'/'escape'),str(base)+':ads',r'\\server\share\x',r'\\?\C:\x',str(base/'x.'),str(base/'x '),str(base/'FOO~1'),str(base/'NUL')]
        for value in bad:
            try:win.canonical(value)
            except win.Blocked as e:done.append(observation('path-'+value,'PASS' if e.reason=='BLOCKED_NAMESPACE_ALIAS' else 'BLOCKED',str(e)))
            else:raise RuntimeError('ALIAS_ACCEPTED:'+value)
        duplicate=['a.txt','A.txt'];collision=len({s.casefold() for s in duplicate})!=len(duplicate)
        if not collision:raise RuntimeError('CASE_COLLISION_NOT_DETECTED')
        done.append(observation('case-collision','BLOCKED','Limited casefold equality observation; actual duplicate-inventory admission rejection not exercised.'));row['gateResult']='BLOCKED_ALIAS'
    elif n==18:
        h=create_file(base/'original.txt');before=sentinel(h);row['preSentinel']=before;h.close()
        if not win.CreateHardLink(str(base/'alias.txt'),str(base/'original.txt'),None):win.failure('HARDLINK_FIXTURE_UNAVAILABLE')
        try:
            unexpected=win.Held(str(base/'original.txt'));unexpected.close()
        except win.Blocked as e:done.append(observation('link-count-greater-than-one','PASS' if e.reason=='BLOCKED_HARDLINK' else 'BLOCKED',{'error':str(e),'reason':e.reason,'win32':e.win32,'exactLinkCountGuardReached':e.reason=='BLOCKED_HARDLINK'}))
        else:raise RuntimeError('HARDLINK_ACCEPTED')
        row['preSentinel']=before;row['postSentinel']={'status':'UNQUALIFIED','reason':'Hardlink creation intentionally changes link count. Rejected held open is not a complete descriptor/hash preservation readback.'};row['gateResult']='BLOCKED_HARDLINK'
    elif n==19:
        h=create_file(base/'at-create.txt');record=h.record();row['handles'].append(record)
        verified=win.verify_created(h)
        done.append(observation('exclusive-create','PASS',record))
        done.append(observation('explicit-protected-descriptor-at-create','PASS',{'nativeCreateNew':True,'saAtCreation':True,'exactReadbackVerification':verified,'scope':'CURRENT_HELD_OBJECT_OBSERVATION_ONLY'}))
        done.append(observation('trusted-owner','BLOCKED',{'ownerSidObserved':record['descriptor']['ownerSid'],'reason':'Expected owner verified on held object; no independent untrusted-token observer/creation-window proof.'}))
        row['gateResult']='BLOCKED_CONTINUITY'
    elif n==20:
        h=create_file(base/'held.txt');row['handles'].append(h.record());row['gateResult']='BLOCKED_CONTINUITY'
        done.append(observation('no-malicious-admin-resistance-claim','PASS','No untrusted OS token acquired; no substitution or parent rename attempted.'))
    elif n==21:
        h=create_file(base/'held.txt');replacement=create_file(base/'different.txt')
        if h.info['fileId']==replacement.info['fileId']:raise RuntimeError('IDENTITY_FIXTURE_NOT_DISTINCT')
        row['handles'] += [h.record(),replacement.record()]
        done.append(observation('path-handle-drift-injection','BLOCKED',{'differentObjectIdObserved':replacement.info,'heldIdObserved':h.verify(),'reason':'Limited identity observation only; no drift injected into an admission rejection function.'},True,True))
        row['preSentinel']=sentinel(h);row['postSentinel']=sentinel(h)
        done.append(observation('descriptor-from-same-handle','PASS',h.descriptor))
        done.append(observation('hash-from-same-handle','PASS',row['postSentinel']))
        row['gateResult']='BLOCKED_CONTINUITY'
    elif n==23:
        h=create_file(base/'pinned.txt',b'one pinned dummy byte sequence');same=create_file(base/'same-bytes.txt',b'one pinned dummy byte sequence')
        a,b=sentinel(h),sentinel(same)
        if a['hash']!=b['hash'] or a['held']['identity']['fileId']==b['held']['identity']['fileId']:raise RuntimeError('SAME_BYTE_FIXTURE_WRONG')
        done.append(observation('same-byte-untrusted-substitution','BLOCKED',{'heldSourceObserved':a,'otherObjectObserved':b,'reason':'Limited equal-byte/different-ID observation only; no untrusted substitution/rejection adapter exercised.'},True,True))
        row['gateResult']='BLOCKED_CONTINUITY'
    row['subchecks']=planned(case,done);row['status']='BLOCKED';row['reason']='Implemented local observations retained; required unavailable adversarial/token/continuity subchecks remain BLOCKED'

def static_cases(case,row):
    n=int(case['id'][1:]);done=[]
    row['subchecks']=done
    if n==24:
        # In-memory negative controls; never load wrong candidate or rewrite frozen source.
        controls={'wrong-external-manifest-pin':digest(raw)!='0'*64,'wrong-external-bootstrap-pin':digest(verified_bytes['Bootstrap.ps1'])!='0'*64}
        for k,v in controls.items():
            if not v:raise RuntimeError('PIN_NEGATIVE_CONTROL')
            done.append(observation(k,'BLOCKED','Limited in-memory digest inequality only; no rejection through actual bootstrap admission was exercised.',True,True))
        for name in ('gate.py','windows_api.py','run.py'):
            changed=verified_bytes[name]+b'\n# simulated stale byte\n'
            if digest(changed)==pins[name]['sha256']:raise RuntimeError('STALE_PIN_NOT_DETECTED')
            done.append(observation('stale-'+name,'BLOCKED','Limited changed-byte hash observation; admission rejection not exercised and no candidate loaded.',True,True))
        extra=allowed|{'adjacent-approval.json'}
        if extra==allowed:raise RuntimeError('EXTRA_CONTROL')
        done.append(observation('extra-manifest-entry','BLOCKED','Limited unequal-set observation; extra-inventory rejection not exercised.',True,True))
        row['gateResult']='BLOCKED_EXTERNAL_PIN_OR_EXTRA'
    elif n==25:
        done.append(observation('block-before-add-type-native-launch','BLOCKED','No compiler/Add-Type path exists; no protected dependency-rejection adapter or qualified launch chain demonstrated.'))
        row['gateResult']='BLOCKED_LAUNCH_CHAIN_UNQUALIFIED'
    elif n==26:
        text=verified_bytes['Bootstrap.ps1'].decode('utf-8')
        expected_prefix="""[CmdletBinding()]
param(
 [Parameter(Mandatory)][ValidateSet('LocalValidation','ProtectedStage','Apply','Setup')][string]$Mode,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedSourceManifestSha256,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedBootstrapSha256,
 [Parameter(Mandatory)][string]$PythonExecutable,
 [Parameter(Mandatory)][ValidatePattern('^[a-f0-9]{64}$')][string]$ExpectedPythonSha256
)
if ($Mode -ne 'LocalValidation') {throw 'UNCONDITIONAL_OPERATIONAL_ADMISSION_BLOCK'}"""
        if text.replace('\r\n','\n').split("$ErrorActionPreference='Stop'",1)[0].strip()!=expected_prefix:
            raise RuntimeError('STATIC_BOOTSTRAP_EXACT_ADMISSION_PREFIX')
        py=verified_bytes['run.py'].decode('utf-8');tree=ast.parse(py)
        initial=ast.parse("""if sys.argv.count('--mode=LocalValidation')!=1 or any(x.startswith('--mode') and x!='--mode=LocalValidation' for x in sys.argv):
    raise SystemExit('UNCONDITIONAL_OPERATIONAL_ADMISSION_BLOCK')""").body[0]
        parsed=ast.parse("""if args.mode!='LocalValidation' or sys.argv.count('--mode=LocalValidation')!=1 or any(x.startswith('--mode') and x!='--mode=LocalValidation' for x in sys.argv):
    raise SystemExit('UNCONDITIONAL_OPERATIONAL_ADMISSION_BLOCK')""").body[0]
        dump=lambda node:ast.dump(node,include_attributes=False)
        if (not isinstance(tree.body[0],ast.Expr) or not isinstance(tree.body[0].value,ast.Constant) or
            not isinstance(tree.body[0].value.value,str) or dump(tree.body[1])!=dump(ast.parse('import sys').body[0]) or
            dump(tree.body[2])!=dump(initial)):
            raise RuntimeError('STATIC_PYTHON_EXACT_INITIAL_GUARD')
        parse_node=ast.parse('args=parser.parse_args()').body[0]
        positions=[i for i,node in enumerate(tree.body) if dump(node)==dump(parse_node)]
        if len(positions)!=1 or dump(tree.body[positions[0]+1])!=dump(parsed):
            raise RuntimeError('STATIC_PYTHON_EXACT_PARSED_GUARD')
        done.append(observation('unconditional-admission','PASS',{'admittedAdapters':['Bootstrap.ps1','run.py'],'modeGuard':'exact initial and post-parse predicates plus exact rejection bodies','method':'STATIC_AST_AND_EXACT_BOOTSTRAP_PREFIX_ONLY; no operational entrypoint invoked'}))
        row['gateResult']='UNCONDITIONAL_ADMISSION_REJECTION_STATIC';row['status']='PASS'
    elif n==27:
        # Avoid spawning a native child merely to claim containment. Timeout/nonzero
        # controls below are explicitly inert simulations, not native process evidence.
        done.append(observation('timeout-injection','BLOCKED',{'reason':'Inert literal observation only; no native timeout injected','nativeChildLaunched':False},True,True))
        done.append(observation('nonzero-child-injection','BLOCKED',{'reason':'Inert literal observation only; no native nonzero child injected'},True,True))
        done.append(observation('containment-failure-injection','BLOCKED',{'reason':'No native containment failure injected','limitedActualJobObservation':job.ensure_only_runner()},True,True))
        row['gateResult']='BLOCKED_CONTAINMENT_NATIVE_INJECTION_UNQUALIFIED'
    elif n==28:
        done.append(observation('sole-runner-job-membership','PASS',job.ensure_only_runner()))
        done.append(observation('owned-job-empty','BLOCKED','Runner is still executing. Parent must verify its exit and zero owned survivors; no post-exit proof from inside runner.'))
        # Parent supplied baseline remains unmodified and is hashed, not reinterpreted as our run.
        baseline=ROOT/'preservation-before.json'
        if baseline.exists():
            done.append(observation('parent-preservation-baseline','BLOCKED',{'observedSha256':digest(baseline.read_bytes()),'role':'parent evidence not externally bound or compared by this harness; limited hash observation only'}))
        metadata=[]
        for path in [r'C:\Program Files\MCVQ5-Staging-20261029',r'C:\Program Files\MCVQ5-20261029',r'C:\Program Files\MCVQ5-State-20261029',r'C:\ProgramData\MCVQ5-20261029']:
            try:
                try:os.lstat(path)
                except FileNotFoundError:metadata.append({'path':path,'exists':False})
                else:
                    with win.Chain(path) as chain:metadata.append({'path':path,'exists':True,'held':chain.record()})
            except (win.Blocked,OSError) as e:metadata.append({'path':path,'status':'UNQUALIFIED','error':str(e)})
        done.append(observation('roots-readonly-metadata-if-accessible','BLOCKED',{'limitedReadback':metadata,'reason':'UNQUALIFIED: no complete before/after comparison; individual denied/failed reads remain unqualified.'}))
        # No SCM route implemented: no mutation or substitute enumeration.
        row['preservationDelta']['services']='UNQUALIFIED_PARENT_READBACK_REQUIRED'
        row['gateResult']='BLOCKED_PRESERVATION_PARTIAL'
    row['subchecks']=planned(case,done)
    if n!=26:row['status']='BLOCKED'
    row['reason']='Static/inert or limited actual observations only; unimplemented required proof remains BLOCKED'

try:
    job=win.Job();job.ensure_only_runner()
    # Exclusive top-level destinations; preexisting receipts/fixtures are collisions.
    create_dir(run_out);create_dir(fixture_root)
    for case in matrix['cases']:
        active_deadline=min(deadline,time.monotonic()+30)
        row={'caseId':case['id'],'utcStart':utc(),'status':'NOT_RUN','reason':stop,'sourceManifestSha256':args.manifest,'bootstrapSha256':args.bootstrap,'policySha256':pins['policy/PATH-SPECIFIC-GATE-REVISION.md']['sha256'],'harnessSha256':pins['run.py']['sha256'],'fixtureNamespace':str(fixture_root/case['id']),'fixtureDescriptors':case['descriptors'],'individualRights':[],'tokenProvenance':{'actualTokens':'UNQUALIFIED_NOT_ACQUIRED'},'handles':[],'preSentinel':{'status':'NOT_APPLICABLE_OR_NOT_CAPTURED'},'postSentinel':{'status':'NOT_APPLICABLE_OR_NOT_CAPTURED'},'actual':False,'simulated':False,'operationalEvidence':False,'preservationDelta':{'operational':'NOT_INDEPENDENTLY_PROVEN','scmCalls':0,'credentialsAccessed':False,'hostedAttemptsSpent':0},'subchecks':[]}
        row['gateResult']='NOT_RUN'
        row['individualRights']=[{'tokenContext':ctx,'name':r['name'],'desiredAccess':int(r['mask'],16),'reference':{'outcome':'UNQUALIFIED' if not stop else 'NOT_RUN','reason':'No token/reference requested by this fixture or prerequisite unavailable'},'gate':{'outcome':'NOT_RUN'},'comparison':'NOT_RUN'} for ctx in case['contexts'] for r in matrix['individualRights']]
        if stop:row['subchecks']=planned(case,[],status='NOT_RUN')
        else:
            try:
                row['actual']=True
                if case['id']<='L14':
                    row['simulated']=True
                    if semantic(case,row):stop='SEMANTIC_REFERENCE_GATE_MISMATCH_STOP'
                elif case['id']<='L23':fixtures(case,row)
                else:static_cases(case,row)
            except win.Blocked as e:
                row.update(status='BLOCKED',gateResult='BLOCKED_UNKNOWN',reason=str(e),sourceError={'reason':e.reason,'win32':e.win32,'details':e.details},subchecks=planned(case,row['subchecks']))
            except BaseException as e:
                row.update(status='FAIL',reason=str(e),traceback=traceback.format_exc(),subchecks=planned(case,row['subchecks']))
                if case['id']<='L14':stop='SEMANTIC_CHECK_ERROR_STOP'
        row['utcEnd']=utc();row['processOutcome']=job.ensure_only_runner()
        row['simulated']=row['simulated'] or any(s.get('simulated',False) for s in row['subchecks'])
        rows.append(row);write_evidence(case['id']+'.json',row)
        if time.monotonic()>deadline-5:stop='CHILD_LIFETIME_BOUND_STOP'
    active_deadline=min(deadline,time.monotonic()+30)
    report={'schema':1,'status':'BLOCKED','mode':'UNTRUSTED_LOCAL_SYNTHETIC_NOT_OPERATIONAL','utcStart':start,'utcEnd':utc(),'sourceManifestSha256':args.manifest,'cases':[{'id':r['caseId'],'status':r['status'],'receipt':'receipts/'+r['caseId']+'.json'} for r in rows],'counts':{s:sum(r['status']==s for r in rows) for s in ('PASS','FAIL','BLOCKED','NOT_RUN')},'performed':sum(r['actual'] for r in rows),'total':len(rows),'processOutcome':job.ensure_only_runner(),'payloadBytes':payload,'receiptBytesBeforeAggregate':output_bytes,'retainedOutputBytes':{'status':'UNQUALIFIED_PARENT_FINAL_CENSUS_REQUIRED','reason':'Snapshot excludes this aggregate, evidence manifest, launcher streams and fixture bytes; no complete output census claimed.'},'hostedAttemptsRemaining':48,'setupAuthorization':False,'operationalQualification':False,'knownGaps':['actual token classes','MIC/owner/privilege/restricted analysis','exact scoped path/service engine','handle-relative creation/untrusted observer continuity','native child failure injection','pre-startup and post-exit containment','full staging/launch proof','complete preservation readback','actual L21/L23/L24 admission rejection adapters']}
    write_evidence('AGGREGATE.json',report)
    # Bundle covers every emitted receipt; self hash is for parent to record externally.
    write_evidence('EVIDENCE-MANIFEST.json',{'schema':1,'sourceManifestSha256':args.manifest,'files':list(evidence),'stdoutStderr':'parent must retain launcher streams separately and include in parent envelope','runnerExitVerification':'parent must record exact runner exit and zero job survivors'})
    stdout_report=json.dumps(report)
    if len(stdout_report.encode('utf-8'))>1024**2:raise win.Blocked('STDOUT_REPORT_BOUND')
    print(stdout_report)
finally:
    finished=True
    for h in reversed(held):h.close()
    if job:job.close()
