$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$out=Join-Path $root 'POST-RUN-CONTAINMENT.json'
if(Test-Path -LiteralPath $out){throw 'CONTAINMENT_EVIDENCE_COLLISION'}
$launch=Get-Content -LiteralPath (Join-Path $root 'LAUNCH-RESULT.json') -Raw|ConvertFrom-Json
$jobText=@(& 'C:\Users\HENRI\AppData\Local\Programs\Python\Python312\python.exe' -B (Join-Path $root 'inspect-owned-job.py'))
if($LASTEXITCODE -ne 0){throw 'POST_RUN_JOB_INSPECTOR_FAILED_NO_RETRY'}
$job=($jobText -join [Environment]::NewLine)|ConvertFrom-Json
$identities=@()
foreach($owned in @(@{role='bootstrap';pid=$launch.parentPid;start=$launch.parentStartUtc},@{role='runner';pid=$launch.launch.pid;start=$launch.launch.startUtc})){
 try{
  $process=[Diagnostics.Process]::GetProcessById([int]$owned.pid)
  try{
   $currentStart=$process.StartTime.ToUniversalTime().ToString('o')
   $same=([DateTime]::Parse($currentStart).ToUniversalTime().Ticks -eq [DateTime]::Parse($owned.start).ToUniversalTime().Ticks)
   $identities+=@{role=$owned.role;pid=$owned.pid;expectedStartUtc=$owned.start;currentStartUtc=$currentStart;status=$(if($same){'BLOCKED_OWNED_PROCESS_STILL_PRESENT'}else{'PID_REUSED_ORIGINAL_IDENTITY_ABSENT'});hasExited=$process.HasExited}
  }finally{$process.Dispose()}
 }catch [ArgumentException] {
  $identities+=@{role=$owned.role;pid=$owned.pid;expectedStartUtc=$owned.start;status='OWNED_PID_ABSENT'}
 }catch{
  $identities+=@{role=$owned.role;pid=$owned.pid;expectedStartUtc=$owned.start;status='UNQUALIFIED_PROCESS_READ';error=$_.Exception.Message}
 }
}
$result=[ordered]@{schema=1;utc=[DateTime]::UtcNow.ToString('o');job=$job;exactProcessReadbacks=$identities;scope='Post-run task-owned job and exact PID/start identities only; no shared process sweep or process mutation.';preStartupContainment='UNQUALIFIED_NOT_CLOSED_BY_POSTEXIT_READBACK';sourceCasesRerun=0}
$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($result|ConvertTo-Json -Depth 12))
$stream=[IO.File]::Open($out,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
$result|ConvertTo-Json -Depth 12
