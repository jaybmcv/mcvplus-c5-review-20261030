$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$taskRoot=$PSScriptRoot
$timer=[Diagnostics.Stopwatch]::StartNew()
$startedUtc=[DateTime]::UtcNow.ToString('o')
function Write-NewText([string]$Name,[string]$Text){
 $bytes=[Text.UTF8Encoding]::new($false).GetBytes($Text)
 $s=[IO.File]::Open((Join-Path $taskRoot $Name),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
 try{$s.Write($bytes,0,$bytes.Length);$s.Flush($true)}finally{$s.Dispose()}
}
foreach($n in @('LAUNCH-RESULT.json','LAUNCH-STDOUT.txt','LAUNCH-STDERR.txt')){
 if(Test-Path -LiteralPath (Join-Path $taskRoot $n)){throw 'SINGLE_RUN_OUTPUT_COLLISION_NO_RETRY'}
}
$frozen=Get-Content -LiteralPath (Join-Path $taskRoot 'FROZEN-SOURCE-PINS.json') -Raw|ConvertFrom-Json
$source=Join-Path $taskRoot 'source'
if((Get-FileHash -LiteralPath (Join-Path $source 'SOURCE-MANIFEST.json') -Algorithm SHA256).Hash.ToLowerInvariant() -cne $frozen.sourceManifestSha256){throw 'PARENT_FROZEN_MANIFEST_DRIFT'}
if((Get-FileHash -LiteralPath (Join-Path $source 'Bootstrap.ps1') -Algorithm SHA256).Hash.ToLowerInvariant() -cne $frozen.bootstrapSha256){throw 'PARENT_FROZEN_BOOTSTRAP_DRIFT'}
$errors=New-Object IO.StringWriter
$originalError=[Console]::Error
$records=@();$launch=$null;$failure=$null
try{
 [Console]::SetError($errors)
 $records=@(& (Join-Path $source 'Bootstrap.ps1') -Mode LocalValidation -ExpectedSourceManifestSha256 $frozen.sourceManifestSha256 -ExpectedBootstrapSha256 $frozen.bootstrapSha256 -PythonExecutable $frozen.pythonExecutable -ExpectedPythonSha256 $frozen.pythonSha256 3>&1 4>&1 5>&1 6>&1)
 if($records.Count){try{$launch=$records[-1]|ConvertFrom-Json}catch{$failure='LAUNCH_METADATA_PARSE_FAILED: '+$_.Exception.Message}}
}catch{
 $failure=$_.Exception.ToString()
 $errors.WriteLine($_.ToString())
}finally{
 [Console]::SetError($originalError)
}
$result=[ordered]@{schema=1;parentPid=$PID;parentStartUtc=(Get-Process -Id $PID).StartTime.ToUniversalTime().ToString('o');parentExecutable=(Get-Process -Id $PID).Path;utcStart=$startedUtc;utcEnd=[DateTime]::UtcNow.ToString('o');elapsedSeconds=$timer.Elapsed.TotalSeconds;sourceManifestSha256=$frozen.sourceManifestSha256;bootstrapSha256=$frozen.bootstrapSha256;launch=$launch;failure=$failure;reruns=0;retryPolicy='No rerun; preserve failures and all later NOT_RUN cases';hostedAttemptsSpent=0}
Write-NewText 'LAUNCH-STDOUT.txt' (($records|ForEach-Object {[string]$_}) -join [Environment]::NewLine)
Write-NewText 'LAUNCH-STDERR.txt' ($errors.ToString())
Write-NewText 'LAUNCH-RESULT.json' ($result|ConvertTo-Json -Depth 16)
$errors.Dispose()
$result|ConvertTo-Json -Depth 16
