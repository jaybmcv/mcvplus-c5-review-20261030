# Independent final source and evidence review

Review date: 2026-10-30 local / 2026-10-31 UTC. Base review commit: `98eeddabbd66b4227d1f832898aa3477ebe7d270`. Task directory: `D:\OpenClaw-workspace\artifacts\mcvplus-c5-path-gate-validation-20261030\run-5e810f64956a463593a4ec00c4a610f2`.

**Verdict: accepted as a limited, explicitly untrusted local evidence package, with the exceptions and unqualified areas below. Full PG-R1 implementation and operational qualification remain BLOCKED.** This is not a passing policy qualification, permission to rerun, or approval to stage, Setup, deploy or contact hosted services.

The reviewer performed source/evidence reads, JSON parsing, byte hashes, inventory and metadata comparisons only. No candidate source was imported, compiled or executed; no gate/case/native/token/SCM probe, subprocess code test, network request, git mutation or deletion was performed. No case was rerun. Only this report and INDEPENDENT-FINAL-SUMMARY.txt were written. Existing source, receipts and earlier reviews were not modified.

## Frozen source and admission provenance

The actual current source manifest hashes to **414a4572fb327540a55fef9d8713f3478810c8e07ed2a0ff7cda8c651a6001e8**, matching FROZEN-SOURCE-PINS.json and every case/aggregate/launcher manifest binding. All 15 manifest-listed files match their exact lengths and hashes; source inventory has no missing or extra files/directories. SOURCE-MANIFEST.json is the intended unlisted manifest itself. The current four code files match the corrected source reviewed previously; the original pre-freeze report's evolving hashes are not final candidate identifiers.

FROZEN-SOURCE-PINS.json records freeze at 2026-10-31T03:11:27.288962Z, before launcher start at 03:11:35.5824796Z. It binds bootstrap, interpreter, source entries, corrected delivery overlay, parent launcher and corrective review. Run-Once.ps1 matches its frozen launcher hash, passes the frozen pins, and has exclusive output collision checks and no retry loop.

Current Bootstrap rejects nonlocal Mode before its file work; it hashes/parses the same retained manifest stream, retains bootstrap/interpreter/source read streams with write/delete sharing denied, and checks inventory/pins before Process.Start. Current run.py requires exactly one literal local mode before helpers and immediately after parsing, disables argparse abbreviation, verifies source/policy, and executes helpers from verified in-memory bytes. The independent Authz reference and finite gate reside in separately sealed source files. The policy, root bindings, exact matrix and harness are bound by the manifest. No obsolete root C#/generators were used as final implementation evidence.

These facts support the recorded local launch chain. They do not establish protected interpreter/DLL/stdlib/ancestor/TEMP/PATH trust or atomic parent-relative execution. No separate trace of every stream lock is supplied; lock order is established by the frozen source and successful pinned launch evidence, not a new reviewer invocation.

## Case and comparison audit

Exactly L01–L28 occur once in the source matrix, aggregate and receipt filenames. All 28 actual receipt byte hashes/lengths match their EVIDENCE-MANIFEST entries. That manifest has 29 entries: 28 case receipts plus AGGREGATE.json. No extra or missing receipt file was found after accounting for EVIDENCE-MANIFEST.json itself. Aggregate case statuses agree with individual receipts. Launcher stdout's aggregate manifest, case IDs/statuses and start/end fields agree with the retained aggregate; stderr is supplied and empty.

Outcomes: **27 BLOCKED, 1 PASS, 0 FAIL, 0 NOT_RUN**. All 28 adapters were entered; this does not mean every planned subcheck ran. The sole PASS, L26, is static admission-source inspection only, with no token/access assertion and no operational entrypoint invocation. Its placeholder reference fields must not be interpreted as unavailable real tokens passing access checks.

Comparison accounting, independently counted from individualRight records:

- 2,744 semantic per-right records in L01–L14 represent calls to gate.evaluate and attempts to obtain a reference result.
- 2,478 completed Windows AuthzAccessCheck reference results: 543 ALLOWED and 1,935 DENIED. Every such result is explicitly synthetic, actualToken=false and operationalEvidence=false.
- 2,114 qualified gate/reference comparisons: **2,114 MATCH, 0 MISMATCH**.
- 364 additional completed Authz results have an unqualified gate result: L06 owner/OWNER RIGHTS and L10 null/unresolved-principal and L14 CREATOR OWNER coverage. They are NOT_COMPARABLE, not matches.
- 266 semantic reference attempts produced no result: 126 blocked MIC/restricted/privilege requests and 140 unsupported ACE-layout requests. Some native descriptor/context work can precede rejection; these are not completed AuthzAccessCheck results. Gate results for these requests are also unqualified.
- Thus semantic NOT_COMPARABLE totals 630 = 364 + 266.
- L15–L28 add 196 placeholder per-right records with reference UNQUALIFIED, gate NOT_RUN and comparison NOT_RUN; no Authz call is claimed for them. Total per-right records across receipts: 2,940. Total reference UNQUALIFIED fields: 462 = 266 semantic attempts + 196 placeholders.
- Qualified gate outcomes total 469 ALLOWED and 1,645 DENIED; gate BLOCKED_UNKNOWN totals 630, with 196 placeholder NOT_RUN entries.

The word “invoked” must not turn the 462 unqualified fields into actual Windows reference calls. No actual OS token was acquired: ordinary, filtered admin, restricted/deny-only and all three named service token classes remain UNQUALIFIED_NOT_ACQUIRED_NO_RETRY. Invented service-shaped SIDs and SKIP_TOKEN_GROUPS Authz contexts are semantic fixtures only.

No mismatch or expected-result failure occurred, so the semantic-stop condition was not triggered. Source stops later execution on mismatch and can emit NOT_RUN records; that branch was not exercised in this run. Absence of a mismatch is not a successful stop-injection test.

## Planned subchecks and actual predicate assertions

All **185 planned required subcheck names** appear exactly once in their respective receipts: 51 PASS and 134 BLOCKED. There are also 32 additional observations, giving **217 total subchecks: 77 PASS and 140 BLOCKED**, with no duplicate subcheck names per row. No missing required name or inconsistent claimed expected-mask PASS was found. Conservative required BLOCKED entries were not upgraded from similarly named extra observations: for example L03/L04 have passing extra classifier observations while their original combined/independent route subchecks remain BLOCKED. L17's eight actually invoked canonical-path negatives also coexist with conservative planned BLOCKED placeholders. This under-qualification does not justify promoting the rows.

Actual predicate routes were inspected against the frozen source and receipt data, without replaying them:

- Semantic expected-result assertions select exact recorded descriptor/context/masks, require complete comparable results, and compare gate and independent Windows reference with the specified expected outcome. Their passing selected records agree; no digest inequality substitutes for these gate calls.
- L02–L05 invoke the actual rejection-only classifier. L02 returns BLOCKED_UNKNOWN, not a sibling approval. L03/L04 and both L05 classifier observations reject reference-confirmed forbidden grants. The classifier has no scoped/sibling caller flags and no PASS return path; empty/incomplete input cannot approve protection.
- L15 and L22 call exclusive file creation; their PASS negatives require exact creation reasons and Win32 80. L15's directory negative requires its exact creation reason and Win32 183. Applicable file/directory identity, descriptor and byte sentinels are compared.
- L16 invokes Held on the created symlink and records exactly BLOCKED_REPARSE; target sentinel comparison is present. This does not cover junctions, every reparse tag or mount transitions.
- L17 invokes canonical() on eight rejected aliases; bare casefold equality remains BLOCKED as an inventory rejection test.
- L19 invokes the fixed descriptor-at-create primitive and verify_created; passing observations refer only to the current held object's exclusive creation and exact descriptor readback. Its trusted-owner/observer/window proof remains BLOCKED. L20's “no malicious administrator resistance claim” PASS is a declaration of scope, not an adversarial security test.
- L21 calls same-handle descriptor/hash primitives but its drift injection remains BLOCKED. L23 equal-byte/different-ID observations remain BLOCKED; they do not invoke a substitution-rejection adapter.
- L24's zero-digest/changed-byte/set comparisons remain BLOCKED, not actual negative bootstrap rejection evidence. L25 remains BLOCKED for protected loader qualification.
- L26 performs exact static Python AST/Bootstrap prefix inspection. L27's inert literal outcomes remain BLOCKED; no native failure injection occurred. L28's live-runner membership observation is distinct from its BLOCKED empty-job/baseline/root-preservation proofs.

No unsafe operational acceptance was found. The aggregate remains BLOCKED and operational_decision always blocks. Unsupported required predicates prevent policy qualification even where a limited actual observation passes.

## Exceptions, safety and containment limitations

**F01 — HIGH completeness blocker, fail-closed: L18 hardlink scenario did not reach rejection.** receipts/L18.json records sourceError HARDLINK_FIXTURE_UNAVAILABLE, Win32 32 (sharing violation). CreateHardLink failed, so no link-count>1 rejection or complete post-link preservation proof was obtained. The row and its required subchecks are BLOCKED with zero PASS; source error and pre-sentinel were retained. Do not interpret this as a successful hardlink guard. No retry is authorized or recommended here.

**F02 — MEDIUM evidence/bounds gap: the separate post-run inspector is incompletely bounded/identified.** Finalize-Containment.ps1 launches inspect-owned-job.py synchronously. Its source supplies no explicit 30-second timeout or precise inspector PID/start/lifetime record. POST-RUN-CONTAINMENT.json contains the query result timestamp, but not that inspector child's start/duration. It also does not bind the inspector/helper hash in the pre-run frozen manifest. Their current hashes are recorded below. This limits exact process-bound/provenance claims for the entire evidence-collection pipeline; it does not negate the timed, identified main runner result. No inspector overrun, mutation or survivor is demonstrated by the supplied evidence. Do not infer its <=30-second compliance or expand the proven concurrency census from missing timestamps.

**F03 — HIGH implementation/operational blockers still open:** exact path/service capabilities and installed executable/config/environment/SCM closure; actual service SID/token availability; arbitrary-principal/group/claim analysis; restricted intersection, MIC, privileges and complete owner/OWNER RIGHTS/CREATOR OWNER semantics; parent mutation authority and relative creation; untrusted observer and directory creation-to-held continuity; full 52-file/1,691-entry staging; protected bootstrap/interpreter/dependency chain; native timeout/nonzero/containment-failure injections. The 134 planned BLOCKED subchecks remain visible. Synthetic success cannot close any of these.

**F04 — MEDIUM containment proof gap, not an observed containment failure:** interpreter/helper/native DLL startup precedes runner self-assignment to the job. The job active-process limit is one and the source rejects named-job collision. Every case process record names the same runner and no owned child. Post-exit absence closes the observed main-run endpoint, but cannot retroactively prove suspended-create/assign-before-resume containment, all startup descendants, or failed-containment termination behavior. There was no actual timeout/termination failure in this run.

No additional unsafe acceptance or observed shared-object mutation was found. Fail-closed incompleteness is not reported as completed PG-R1 implementation.

## Time, process and storage bounds

The main PowerShell coordinator PID is 79888, executable C:\WINDOWS\System32\WindowsPowerShell\v1.0\powershell.exe, start 03:11:35.3741097Z. LAUNCH-RESULT records its validation interval 03:11:35.5824796Z–03:11:36.6872261Z, elapsed 1.1125777 seconds. Coordinator duration is not used to exempt the Python child.

The exact Python runner PID is 47856, executable C:\Users\HENRI\AppData\Local\Programs\Python\Python312\python.exe, frozen executable hash 4d6f5f81a4bca11191c4c7c6b43632694d0a4ce74e068619d8fdc161d469859a. Start 03:11:35.9349215Z agrees with receipt FILETIME 134378898959349215. Launcher records childObservedSeconds=0.7099304, exitCode=0, hasExited=true, timeout=false and captureComplete=true. This observed main child is below 30 seconds. Aggregate adapter interval is 03:11:36.074409Z–03:11:36.597266Z; the maximum recorded case duration is L21's 0.048547 seconds. Some timestamp differences are zero; they establish recorded precision, not zero work. No full-inventory 180-second exception was used.

Main runner membership is [47856], job PG-R1-run-5e810f64956a463593a4ec00c4a610f2, active-process limit 1, no additional owned child. The main coordinator/runner pair is within two concurrent processes; no broader historical process census is inferred. POST-RUN-CONTAINMENT at 03:12:36.6198504Z records exact parent and runner PIDs absent and JOB_OBJECT_ABSENT with OpenJobObject error 2. The recorded query targets that job and those two identities; source contains no shared-process sweep. This is job-gone endpoint evidence plus runner exit, not a claim that a still-running job was empty. F02/F04 remain.

The supplied validation interval is well below 900 seconds. Freeze through final containment evidence spans about 69.331 seconds. An external outer-watchdog configuration/receipt is not supplied as an independently timed process record; I do not certify uninterruptible-call guarantees or every auxiliary child lifetime from those timestamps. Preparation and the earlier baseline were separate from the measured main validation interval.

Aggregate payloadBytes=412; read-only current fixture enumeration finds 11 file entries with logical lengths totaling 412 bytes, including the retained symlink entry. This is below 512 MiB; no physical allocation or all-alias proof is claimed. The 28 receipt bytes sum to 4,277,024, exactly receiptBytesBeforeAggregate. Before writing this report/summary, a conservative whole-task file census counted 115 files and 6,700,030 logical bytes, including source/preparation documents, far below 2 GiB. This is a current logical-byte census, not proof of historical peak allocation. Retained fixture symlink target is the task's L16 target.txt, not a shared destination. No deletion/cleanup was performed.

EVIDENCE-MANIFEST covers cases/aggregate; it does not self-hash or include launcher, preservation, final containment or fixtures as a complete standalone parent envelope. Their hashes and current census are independently recorded here. No missing named required evidence file was concealed; auxiliary lifetime/outer-watchdog records are unavailable as described.

## Preservation and historical delivery

I parsed before/after snapshots and independently compared complete sharedAndOperationalObjects, services and reviewFiles arrays. They are identical: ten shared/root records, five service records and 76 historical checkout file records. All 76 current checkout bytes/lengths also match the baseline hashes. The ten records cover six shared/ancestor descriptor/metadata entries and four proposed roots. All four proposed roots are absent in both snapshots; shared owner/SDDL/metadata are unchanged. All five existing MCVTest services remain Stopped/Disabled with PID 0 and identical recorded path/account strings. Service read errors are null in both snapshots. This supports the exact supplied local metadata census, not complete registry/SCM authority or every NSSM parameter. No actual MCVQ5 service token is established.

Snapshot times are 02:47:41.2675564Z before and 03:12:01.4768917Z after. Snapshot gap includes preparation; it is not the main child's runtime. preservation-before.json still has its earlier recorded hash. Corrective review bytes match the hash frozen before launch; the initial pre-run review still has its earlier contents/hash recorded below. Current source exactly matches the frozen entries. No claim that mutable preparation drafts were always frozen is made.

The corrected delivery overlay still hashes to 5b588c0029baec51258d3c8fa46cbd4626ef8b0b472b0c54ca2f0d8fbe038e56. For each of seven historical receipts, I independently checked current raw checkout bytes against originalHistoricalBytes and normalized CRLF-to-LF bytes against publishedGitBlob. **All seven original and published lengths/hashes match.** The original UTF-8 BOM was retained in byte-level normalization; text decoding that strips it would give an incorrect comparison. Original CRLF and published Git LF hashes remain separate. These historical receipts are not revised-gate results.

No cloud/deployment/financial/credential readback is supplied or claimed. Reviewed source and action records show no hosted attempt consumption and report zero spent, 48 remaining (42 primary + 6 reserved). No fresh remote census is inferred. Supported Vercel restoration remains separate and was not checked or restored by this review.

## Prior findings: final status

R01/R02 source-byte and mode admission defects are corrected in the exact frozen source. R03 unsafe component PASS flags/empty-PASS behavior are removed. R04 inert rejection/injection PASS defects are corrected to BLOCKED. R07 exact exception reasons are required; L18 demonstrates the corrected fail-closed handling of an unrelated Win32 failure. R09 misleading empty-job/root/accounting acceptance is corrected, while parent preservation and main endpoint evidence supplement rather than rewrite BLOCKED harness rows. R10 active source bundle/seal is complete and exact.

R05 bounded main-child success is observed, but startup/failure-injection/auxiliary-process proof is incomplete. R06 same-held child descriptors/hash, parent retention and descriptor readback exist, but parent authority/directory continuity are not proven. R08 unsupported policy semantics and real identities remain BLOCKED. These open items retain high implementation/operational importance and do not become passes because the local sequence returned exit 0.

## Exact receipt audit

Each row below is one actual case receipt; Authz is completed reference results, Match is qualified comparison count. No row has a mismatch. All rows retain their planned required subcheck names.

| ID | Outcome | Authz | Match | SHA256 of receipts/ID.json |
| --- | --- | ---: | ---: | --- |
| L01 | BLOCKED | 70 | 70 | cea70b4d491e0ba53c7cafebb7f165f0f916fc6ef1635db6d10bd8561643e12e |
| L02 | BLOCKED | 140 | 140 | d0c14395ecf5bb23effe7f786c2970d0ed81fb94aec3057ea08bd7785dbf1e98 |
| L03 | BLOCKED | 140 | 140 | 53595c4653f2b2854b6e8836cd638182892d9abff03d6fd5befcb807dde894b0 |
| L04 | BLOCKED | 140 | 140 | 01887de24e7dfbfb63c166ef916faa5cb9de193d3c4a2a71f2bca8c485400f23 |
| L05 | BLOCKED | 140 | 140 | a79250039214316674eefc5f3b3d199895cebf74635131817fa8fbaa51fb4b35 |
| L06 | BLOCKED | 280 | 140 | fd17200af30ee7699c3d53d7ff3978168b6e33629fe403a74a30ff2c21a764c0 |
| L07 | BLOCKED | 140 | 140 | a85eb1c17364efa7f1ef39eb4297ab730aa4a8450102981125b1fd47bdd27e38 |
| L08 | BLOCKED | 490 | 490 | bfd5e77ce28704b5e47d855e5b632f36208d04ef6a8bae1169d084afab779f84 |
| L09 | BLOCKED | 70 | 70 | 0c7def0d0d21f632b68ad4e81a589dfe24024ede14a2b85cdab7fa5309617dc5 |
| L10 | BLOCKED | 140 | 0 | 1993effbb05be738b69f4563dfed584e25a936a788398c210d0cd51a6867e092 |
| L11 | BLOCKED | 140 | 140 | 84d95a98f5b875d56b688c26f01ce23dae664cd5fb32caff7a1ece363087fb1e |
| L12 | BLOCKED | 210 | 210 | ea31366ea673d4173b7aa648ce2a6a6877a7d3bd5763d3166f811d19a6fdd081 |
| L13 | BLOCKED | 210 | 210 | 065d42b96d66a0a620ce417cf27666f7f0338a0c00a838f80d045db566c4d984 |
| L14 | BLOCKED | 168 | 84 | 597e82db06481b1bb823245db8510fbf110d71bf0dae8d14432223af6278766b |
| L15 | BLOCKED | 0 | 0 | e42803ff34b56958175c460063926cab8d2c9cc3304ef3f8ff7c25aa1e248cad |
| L16 | BLOCKED | 0 | 0 | ade20ae404b0269bcd74bf619b39d72b5a98670e30f694ea9557e826b3af1b6e |
| L17 | BLOCKED | 0 | 0 | b2d0a1d61ef51cfa26141b6bb5601c886954e775365d52be70b12a178683e611 |
| L18 | BLOCKED | 0 | 0 | c9852f1a389566b975f663d9f405da21e8da129f412250fdd1764cc4d37ba997 |
| L19 | BLOCKED | 0 | 0 | 14fc3afce3a974d2bf6295ba1319c944093b9019949c6a944d264399ca08c617 |
| L20 | BLOCKED | 0 | 0 | f8ba9b450d9970b6cfbea6d3cbb4ff46fe182c822f86b12a1c7942df56da1617 |
| L21 | BLOCKED | 0 | 0 | d29077ba8b6addff25d8224fbbfa41e708f281a12c1129c5ec24e29a2662b78e |
| L22 | BLOCKED | 0 | 0 | 7ce30443a40adb7b961fb9b496b4d8897a0ae5fefb72fbe08aee2a5040089d0d |
| L23 | BLOCKED | 0 | 0 | b6d591e6754e2e2fc1ed12ae01276523585ac442ae88d289b873d87a23805ddf |
| L24 | BLOCKED | 0 | 0 | 67bf6fd2508c2c77669c6a9801521d2e31a8cc9aac24dd749bd192001d16b73c |
| L25 | BLOCKED | 0 | 0 | 5bb9b99165f46df340910a5c308f99fad59e07d6ee7b6a22e56217d8ef279405 |
| L26 | PASS — STATIC ONLY | 0 | 0 | 455f40ac1f870df41f308d1f4cde85d3c3fc14bc122a37eff9221a83ca760ddc |
| L27 | BLOCKED | 0 | 0 | 3fc1f9d81613e0d8e3e387b4f054f846295aa6dd34e2a22ad5aebf310e76ba90 |
| L28 | BLOCKED | 0 | 0 | b822ec61a3df074ded08a1dcf2f53c91a5b2bad2922147169212d8940fc9fcea |

## Exact frozen source hashes

Paths are relative to source/. All entries were checked against actual bytes, lengths, manifest and frozen source list.

| File | Bytes | SHA256 |
| --- | ---: | --- |
| SOURCE-MANIFEST.json | 3050 | 414a4572fb327540a55fef9d8713f3478810c8e07ed2a0ff7cda8c651a6001e8 |
| Bootstrap.ps1 | 9079 | da02652997db32f73b8ba0fa80f89087761a8bae6613bbd6fbf3b5919ddd3569 |
| FIXTURE-MATRIX.json | 44324 | cfb8e2f7a9d0d1d49eb8e6475363f8d1b6df419856a92b25080fb2f1e056601d |
| gate.py | 4775 | 5b4bcabc1aca1a9b856b263e903ac18b0eeb0f07863f603c366c8a7beb8d3bba |
| IMPLEMENTATION-NOTES.md | 10003 | 29ae0c0c4d82f8efe1a7839dd7562361d5a975918ab44af98ecd8ce70732d31f |
| policy/BOUNDED-LOCAL-VALIDATION-PLAN.md | 10983 | 03af329888c2fd680660def9dc0301690876ed1a42256a3448bbc75606d35149 |
| policy/LOCAL-POLICY.json | 2681 | fec2b6264654502f69ff79d803a0174a6d521c2e6cbac5e26cb517ad8436fc36 |
| policy/PATH-SPECIFIC-GATE-REVISION.md | 14406 | 50764c09bddd0c6891d2ccd97195c94f16508c8436a0bbb17641cf04d17718b2 |
| policy/STATE-ROOT-BINDINGS.md | 10043 | 12af2adfdf81ce8c1953dcf40f711506d473ba8f9233ad265fd1101364c06715 |
| PRE-FREEZE-CORRECTION-MATRIX.md | 6299 | 672b8372a0dab1e5f4c10e3902197c6d4357675aef3da84b708d522ec56fe34d |
| reference/REVIEWED-REVISION-MANIFEST.json.txt | 2448 | 19867043a03c15a7e9f010f53369b8c6d3adefe15878db1852338966e283f3b3 |
| reference/REVIEWED-SOURCE-MAP.json.txt | 731936 | 6f37ef601c5dcd52b75d4142f41be498fd6e57a3dd969392874a32e00b9172c1 |
| reference/TRUST-LAUNCH.md.txt | 5263 | 6b1c48b18af401f343d366d31d1b682abd2aef0e3257b563e526dc2879d65ecd |
| RUN-INSTRUCTIONS.md | 6177 | 0ca5eb810aee66b0f06440af4239d33df352201141b0feb90d3f3babc3125114 |
| run.py | 32048 | ff222f501d1c4c2d37e0fd02342ccc5c316c1ac0b09628e64f6c0d113ce66289 |
| windows_api.py | 18164 | 9b4b3a0478658f71771fd9cd3425d6ca75467cbc668f887773738576a8a951b1 |

## Supporting evidence hashes

Paths are task-relative. These identifiers do not turn unfrozen auxiliary helpers into pre-run-approved source.

| File | SHA256 |
| --- | --- |
| FROZEN-SOURCE-PINS.json | 762224133833dfe2f88eb5e63cec145bdb3621f0afbb022a9aeab6a9329e272a |
| receipts/AGGREGATE.json | 47c6ba18e514f2fc7735e540af0b67b73eb7808d1fbab5d5d233f1b197efbfa7 |
| receipts/EVIDENCE-MANIFEST.json | 5bcc26240dcf95708447c6560ddc024152562488d2114352f4828abbb46d3c7c |
| LAUNCH-RESULT.json | 9722b906c84de8b448793fafb9c14b6dfed91119fa46bc20d3860e57f2ef8f1d |
| LAUNCH-STDOUT.txt | 4a2b60b833102a541985d7d881019352eac34107e94fcee514107b3798566361 |
| LAUNCH-STDERR.txt | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| preservation-before.json | 12f30dbda6df38722ed81a54e71f260d594b76db6fcfa2dc80fa504fd96f4672 |
| preservation-after.json | 5613dbb7de6fc49aa2ffc33352963695c7fc9dd89764ed07bdf8cf112c4d3d78 |
| PRESERVATION-COMPARISON.json | 95771c8e34c615a16915ebdd75d05fde063e567036d6994eb788ae33c32f83d5 |
| POST-RUN-CONTAINMENT.json | d961e466f24c1f731725cedf3d0b52e1a2527426ad57592f6fee69476789bea8 |
| CORRECTED-DELIVERY-MANIFEST.json | 5b588c0029baec51258d3c8fa46cbd4626ef8b0b472b0c54ca2f0d8fbe038e56 |
| INDEPENDENT-PRE-RUN-REVIEW.md | 2737ffd610e3ad97b4c3164024c5f3acfacc7f752d3a107e9a980ea846f33dd9 |
| INDEPENDENT-CORRECTIONS-REVIEW.md | 98e535515286ae95ede8751e67b5d825ba8cfaa5d95f661dc3b2ae46702e514b |
| Run-Once.ps1 | 9089479f6f557b3a7898d79e881edecd01d4cff4b521f0c090638c6d8ac39788 |
| Finalize-Containment.ps1 | eb11e2930bd4e5944a56dc62715616ea407e46c6d0a16fe97a81144ea4f651b8 |
| inspect-owned-job.py | fd02dd920e0e4e16837a37ebe23b69826e74362bc64cfcd0132972672359d122 |
| PARENT-EVIDENCE-AUDIT.json | b5887b30c425d59733715dbc87c14f895d1313181620e8344de80ead075441b4 |

## Seven historical original/published pairs

Names abbreviate documents/05 through 11 in the reviewed checkout; full mappings are in the bound corrected overlay. Both lengths and hashes were verified independently while preserving the original BOM. No historical receipt was edited or reclassified as a new test.

| Historical receipt | Original CRLF SHA256 | Published LF SHA256 |
| --- | --- | --- |
| 01-Success | f381fc574b0d2e4e3973972fa6c6e5f6c98ed87fdd821d8718142904235ababf | b0a712ddcc4bea72725e1f2190fb06fdb2faf4508fbfc55895481b12fa976fee |
| 02-AfterCodeRoot | 05fef7c82e9b757843a172aef1638980b409e7540e69a306f7043c6df6fae282 | 397b366dbd5b48777843b2386365e3ccc7aaa774327eae6ce5432653fe5f5c65 |
| 03-AfterDataRoot | 5949b3898f75e32eb6e31ee008167ca198768ca02b1b539b9dabdd90d3c165b3 | af12b1932d5b5b3b406fb66c27146da603f3fba2d45f6a8555975aa0b7dc10bb |
| 04-AfterFirstCopy | 7abd21a87831ae21c9495f593b9a4c15f76f2002dd292c99a74ae831194cfdf1 | 5b83f0cad9d77c0c94ca859c82437798dd165c3a7cf880af9c8891b48ae068de |
| 05-AfterServiceCreate | e70c2ca1904c04fd1cb5b98b71943656ef36a338fc06c68aa542b59f22fccd32 | 4fc208401a4506666b07ac802543f64097d297e146291f76f811780662fedaf2 |
| 06-AfterGrant | 329d1e5edbdce1b9ab08ad28c66b57d2ac4d7a77fbca75020fb077ed7fd0f9e2 | 17a12d66d7f16214ba55f655ef84cd32fecd9a87eeaf77b8f6def2cf7275a69b |
| 07-ContainmentFailure | f38f777d3d8807e697793504c6b6c9fcd63a90fe0f88853ec29c12480e7fff17 | b1d08c65a59580a68b88605f8a59c69e243d503f8fcaf7d780a229c47ca57e53 |

Final disposition: retain this once-only evidence and every BLOCKED limitation. No unsafe operational approval or demonstrated main-run survivor failure was found; no completed PG-R1 qualification is established. Auxiliary process-bound evidence, hardlink coverage and all listed implementation/operational blockers remain open. No rerun, new test plan or operational action is authorized. All 48 hosted attempts remain unspent; Vercel restoration is separate.

REVIEW COMPLETE
