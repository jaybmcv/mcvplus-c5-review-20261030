"""Post-run containment evidence only; not a gate test, no process mutation."""
import ctypes as c,json,datetime
from ctypes import wintypes as w
k=c.WinDLL('kernel32',use_last_error=True)
OpenJob=k.OpenJobObjectW;OpenJob.argtypes=[w.DWORD,w.BOOL,w.LPCWSTR];OpenJob.restype=w.HANDLE
Query=k.QueryInformationJobObject;Query.argtypes=[w.HANDLE,c.c_int,c.c_void_p,w.DWORD,c.POINTER(w.DWORD)];Query.restype=w.BOOL
Close=k.CloseHandle;Close.argtypes=[w.HANDLE];Close.restype=w.BOOL
name='PG-R1-run-5e810f64956a463593a4ec00c4a610f2'
class Pids(c.Structure):_fields_=[('assigned',w.DWORD),('count',w.DWORD),('ids',c.c_size_t*16)]
h=OpenJob(4,False,name)
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'job':name,'method':'OpenJobObject JOB_OBJECT_QUERY / QueryInformationJobObject basic PID list; no process sweep','mutation':False}
if not h:
 e=c.get_last_error()
 result.update(openError=e,status='JOB_OBJECT_ABSENT' if e==2 else 'UNQUALIFIED_JOB_QUERY')
else:
 try:
  p=Pids()
  if not Query(h,3,c.byref(p),c.sizeof(p),None):result.update(status='UNQUALIFIED_JOB_QUERY',queryError=c.get_last_error())
  elif p.count>16:result.update(status='BLOCKED_CONTAINMENT',reportedCount=p.count)
  else:result.update(status='EMPTY' if p.count==0 else 'BLOCKED_CONTAINMENT',pids=list(p.ids[:p.count]),assigned=p.assigned)
 finally:Close(h)
print(json.dumps(result,indent=2))
