# Independent source review

**Verdict: UNTESTED. Partial source corrections; full PG-R1 implementation and operational qualification remain BLOCKED.** No source review implies a passing test or authorization.

Reviewed manifest: D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\SOURCE-MANIFEST.json.
Exact identity: **12,324 bytes; SHA256 10556d4e568f86777a579863b0d9efaa7bb67951222d1775338916c633ac5859**, matching the requester-supplied digest. Historical reviewedHead 98eeddabbd66b4227d1f832898aa3477ebe7d270 is provenance, not candidate acceptance.

Reviewer: Codex, independent source reviewer, not implementer; agent /root; computer label openclaw-pc. Reviewer-generated session UUID 9e635dab-0597-4097-bbd8-1a2fb533e296; UTC 2026-10-31T18:35:05.3752634Z. This UUID identifies these artifacts; a platform session identifier was not exposed.

## Scope and inventory

Read absolute task/authorization, copied independent final review, normative policy/root bindings/bounded plan/trust-launch, actual relevant Python/PowerShell/C# source, reference maps and historical names. Only text reads/searches, JSON metadata processing, inventory, byte lengths and SHA256 were used. No candidate execution, compilation, import, syntax/AST parsing, fixtures, tests, probes, retries, token/ACL/SCM inspection, network or SCM action. Original external directory was not accessed. Only this report and identity JSON were written.

Independently checked **25 source files, 1,113,324 source bytes, 4 supporting documents and 5 exact source directories**. Every listed length/hash matches. Missing/extra source files: 0/0. Length/hash mismatches: 0/0. Duplicate paths: 0. Missing/extra directories: 0/0. No source reparse entries observed. Identity JSON records each independently observed length/hash. These checks are inventory verification, not candidate tests.

All 22 copied references match provenance lengths/hashes and corresponding baseline entries. All 7 normative policy/reference copies match their declared pins and copied counterparts. Baseline SHA256: ff3a255190c8132d0ff0a4b5476b039beb6c905815fdafb550829a8f020e6390. This checks local copies, not the inaccessible original run.

Source-map JSON has exactly 1,691 entries: 52 packet, 1 packet-manifest, 1,638 external, anchor b9e20e88febac511fc0e30db258da6d7708c504aa06f1979b335ed32cdb25a8c. This is map metadata, not a full staged payload/readback. Root manifest intentionally excludes itself; source/SOURCE-MANIFEST.json is an independently listed historical file, hash 414a4572fb327540a55fef9d8713f3478810c8e07ed2a0ff7cda8c651a6001e8. No self-hash cycle.

## Findings

### F01 — HIGH historical coverage blocker; source ordering corrected; verification OPEN

D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\windows_api.py:296 prepares the fixed dummy pair; line 321 closes exclusive creation before the single CreateHardLink at line 326. Raw directory observation handles close at line 246. D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:350 prepares before first Held-backed creation at line 353. The production predicate at D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\windows_api.py:132 still rejects every nondirectory with links != 1 as exactly BLOCKED_HARDLINK, matching copied original D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\original-reference\source\windows_api.py:108.

Raw sentinel code is restricted to the fixed pair (windows_api.py:221), captures same-handle identity/creation-time/size/descriptor/hash (line 279), and compares both aliases against the exclusively created identity with links=2 (line 339). D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:241 invokes unchanged Held, requires exact reason/no unrelated Win32 error, compares both before/after sentinels, and leaves exhaustive alias proof BLOCKED. No production guard weakening found.

Disposition: intended structural correction present, no actual guard/sharing/sentinel verification. Parent authority, adversarial creation window and exhaustive aliases remain unproven. F05 also remains. Historical L18 stays BLOCKED.

### F02 — MEDIUM auxiliary provenance/bounds gap; partial source correction; OPEN

D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\Bootstrap.ps1:44 retains bootstrap/interpreter pins; lines 50–89 bind manifest, all helper/inspector sources and independently pinned assembly before proposed child launch. Lines 101–114 launch runner then inspector through the same native helper, in separate exact jobs. No helper binary/build provenance is supplied.

D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\native\ContainedLaunch.cs:18 records PID/native creation FILETIME/executable/hash/path/lifetime/timeout/exit/capture/cleanup fields. Lines 124–129 hash a retained image stream; lines 197–205 obtain native time/image. Explicit stdio inheritance is bounded at line 167. Capture has 8 MiB/stream limit (line 86), bounded PeekNamedPipe/ReadFile bursts (line 327), 28-second timeout and 30-second capture/lifetime checks (lines 230, 237, 246, 264), rather than unbounded ReadToEnd. Exact-owned termination is at line 290.

D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\auxiliary\inspect_owned_job.py:43 queries held job/exact PID/start, distinguishes PID reuse and rejects absence/query errors; Bootstrap.ps1:119 verifies returned bindings. This does not retroactively close historical inspector evidence.

Remaining source blocker: no independent outer supervisor bounds synchronous preflight/CreateProcess/native/cleanup calls or the total 900 seconds. Measuring >30 seconds after return is not an enforceable limit during a blocked call. Complete durable parent envelope is also absent (F06). All identity/bounds/timeout/exit/capture/cleanup behavior remains UNTESTED.

### F03 — HIGH incomplete source implementation AND separate operational prerequisites; OPEN

D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\path_policy.py:441 always blocks chain qualification, explicitly naming source gaps. D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\gate.py:56 is rejection-only, not complete successful PG-R1 classification.

Token trust at D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\permission_check.py:388 requires enabled/non-deny-only Administrators, elevation/high integrity and no restrictions. Filtered/deny-only admin is not trusted. SYSTEM has its own unrestricted/system-integrity predicate. NativeToken.from_handle at line 431 retains an actual kernel token and one impersonation duplicate, compares snapshots/fingerprints, but line 401 leaves operational origin unqualified. Caller role at line 738 is diagnostic only. Six dictionary labels at path_policy.py:358 cannot prove genuine representative classes or service origins: provenance admission adapter is missing, not simply an absent run.

D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\permission_check.py:498 retains and blocks unknown/object/callback/conditional/special owner/CREATOR OWNER/OWNER RIGHTS ACEs and unresolved principals; token claims/device/unsupported conditions block at line 340. Native AccessCheck at line 681 is narrow; upward MIC blocks at line 783; untrusted enabled privileges beyond SeChangeNotifyPrivilege block at line 772. General owner/restricted/MIC/privilege/claim support is incomplete. qualified=True at line 804 means supported individual-right observation only, always operationalEvidence=false.

D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\path_policy.py:258 examines every standard ALLOW trustee independently of sampled tokens and conservatively rejects uncertain scope/inheritance. Arbitrary group/claim/owner/future-child closure remains explicit blocker at lines 333 and 407; representative denials do not prove universality.

capability_ceiling at D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\path_policy.py:208 expresses named state traversal/Postgres own subtree/provider slot-log names/read-only secret-tunnel ceilings, grants nothing, and blocks missing CODE RX closure at line 239. Directory Modify does not enforce a finite future filename set. Provider rotation/name enforcement and Postgres external tablespace/preload/config/library/loader closure remain absent. Full installed spec/SCM/NSSM/account/SID-type/registry/environment authority adapters and operational consumer integration are missing. permission_check.py:829 resolves exact service SIDs but explicitly does not prove installation/token provenance.

Child DELETE and parent DELETE_CHILD are separate at path_policy.py:244 and :385. Full rename destination/replacement/redirect/volume authority and sibling-create exception remain unsupported. D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\windows_api.py:167 holds ancestors through absolute opens. new_directory at line 350 is CreateDirectoryW followed by pathname Held; no reviewed parent-relative primitive or lower-privilege creation-window proof is supplied.

D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\path_policy.py:85 validates original map counts/pins; ExactStagingInventory at line 131 is read-only and explicitly returns BLOCKED_CONTINUITY at line 184. Full protected copying/staging, actual payloads and installed readback are absent. Protected pre-script loader/bootstrap/interpreter/DLL/stdlib/TEMP/PATH/cwd admission remains unavailable/unimplemented.

All 134 historical blocked names occur exactly once in matching matrix cases. F03-REQUIREMENT-MAP.md is grouped; it does not individually map all 134 names to symbols/blockers. Generic planned() placeholders (D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:113) are not explicit dispositions. This review supplies an exhaustive appendix without repairing candidate source.

Disposition: source remains incomplete even if operational inputs become available. Hardcoded blockers cannot be discharged by caller booleans. Missing semantics/adapters must not be relabeled solely as environment/token/installed-state limitations.

### F04 — MEDIUM startup containment gap; intended source sequence corrected; verification OPEN

D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\native\ContainedLaunch.cs:131 rejects job collision and configures/readbacks KILL_ON_JOB_CLOSE plus active-process limit one before creation. Lines 186–190 create suspended; lines 206–213 assign/verify exact PID membership before ResumeThread at line 217. Explicit stdio-only inherited handles are supplied. D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\windows_api.py:433 observes the parent job without self-assignment.

Created-process failures invoke TerminateExact at line 256. Assignment failure still terminates the owned suspended process at line 301 before handle release at line 275. Collision handle closes without termination of the preexisting job. Failed termination/exit/job-empty/close confirmation remains BLOCKED, not guaranteed cleanup. No broad process sweep or retry found.

Disposition: intended ordering present in text; native ABI/layouts, nested jobs, collision/assign/resume/inheritance/termination failures are unverified. Outer supervisor remains missing. No failure injection or zero-survivor proof occurred.

### F05 — MEDIUM additional source blocker: pre-case preparation violates semantic stop ordering and bypasses failure receipts

D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:350 mutates the hardlink fixture before the loop at line 355 and semantics at line 366. This conflicts with semantic-first ordering at D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\policy\BOUNDED-LOCAL-VALIDATION-PLAN.md:64: later semantic mismatch cannot prevent these earlier writes.

Preparation failure is outside per-case catches at run.py:369 and precedes receipts creation at line 353. Outer finally at line 386 only closes handles. No L18 BLOCKED receipt/28-case NOT_RUN aggregate covers that failure; a captured traceback/nonzero exit is not the missing case envelope.

Future source work: defer fixture preparation until semantic stop permits it while preserving close-before-link order; retain preparation failure and honest NOT_RUN accounting in separately owned evidence/parent envelope. No candidate edits made.

### F06 — MEDIUM additional source blocker: durable complete parent envelope and Python cleanup-error reporting absent

D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\Bootstrap.ps1:127 serializes proposed results to stdout but supplies no durable exclusive parent envelope for every preflight/launch/failure path. Earlier exceptions can escape finally without structured results. D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:382 explicitly leaves stdout/stderr/exit-envelope closure external. No supplied coordinator completes preservation/output-census coverage required at D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\policy\BOUNDED-LOCAL-VALIDATION-PLAN.md:70.

Python helpers discard CloseHandle results (D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\windows_api.py:161; D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\permission_check.py:469), unlike native launch cleanup records. This is a source/evidence completeness gap, not demonstrated process leakage or current unsafe acceptance.

Future source/adaptor work: preserve original failures, close errors, exact owned exit/cleanup/empty-job records and complete independently hashed parent envelope without writes into rejected destinations. Operational before/after readbacks remain separately authorized.

## Admission, namespace and historical limits

Unconditional guards remain at D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\Bootstrap.ps1:13 and :17; D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:6; D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\auxiliary\inspect_owned_job.py:7; D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\native\ContainedLaunch.cs:88. No delivered flag/argument enables these entrypoints. Helper import-time native bindings are not import authorization.

RUN-INSTRUCTIONS explicitly prohibit current execution. Historical enablement/commands in preserved normative references remain subordinate to CURRENT-AUTHORIZATION. No operational consumer was patched/enabled. No reviewed mutation path targets original external namespace: output literals bind new exact namespace, mutation helpers require local(), and original map paths are inert metadata. Raw native bindings are internal primitives, not authorized standalone interfaces or a sandbox guarantee.

Historical results remain **1 static PASS (L26), 27 BLOCKED; all 134 required blocked subchecks unchanged**. Revised L26 borrows no historical pass. New runtime results **ZERO**. **48 attempts unspent: 42 primary + 6 reserve**, preserved accounting rather than new remote census. Vercel restoration separate/unverified.

Task permits only these two writes and excludes network/SCM work, so no shared communication repository access/sync/note/publication occurred. Lightweight later opportunity: operator/builder draft showing exact-manifest review and distinction between authored corrections and qualified security behavior; ask reviewers which missing evidence most affects their confidence. This suggestion is not a published or synchronized draft.

## Consolidated future prerequisites — not authorization

LOCAL source/build prerequisites: finish supported semantics/fail-closed coverage, real-token class/provenance adapter, parent-relative creation/authority/rename/redirect model, exact capability/consumer adapters and full protected copy/staging; correct F05 ordering/failure accounting; F06 complete durable parent preservation/envelope and close-error propagation; independently reviewed outer supervisor.

LOCAL verification only under new exact-revision authorization: independently build/review/pin helper binary and source-build provenance under protected toolchain; native signatures/layouts and every collision/assign/resume/timeout/nonzero/capture/termination/close-failure path; actual hardlink guard/sentinels; independent Windows comparisons with permitted real tokens; unsupported-condition rejection; actual bootstrap pin/inventory/substitution controls; lower-privilege observer/continuity; complete case/failure/output-budget/evidence/final-process accounting. No synthetic token/inert literal substitutes for actual checks.

OPERATIONAL source/evidence prerequisites: missing installed spec/SCM/NSSM/registry/environment/consumer adapters first, then separately authorized supported readbacks for exact services/SIDs/accounts/SID types/real tokens; quoted ImagePath/pg_ctl -D/NSSM arguments/cwd/environment; per-service executable/config/module/dependency closure; protected pre-script bootstrap/PowerShell/.NET/native/Python/DLL/stdlib/compiler/TEMP/TMP/PATH/PGSYSCONFDIR and ancestor chain; actual T/K/C/S creation continuity and complete original 52/1691 stage/installed readback; Postgres external/config trust-domain limits; provider adjacent config/disabled secret/slot-log names/rotation; tunnel exact config/credentials; external operator-driver binding; exact receipts/evidence/failure/owned-grant/cluster containment. Do not create services/accounts/roots to fill evidence gaps. Credential/ledger/hosted/financial work remains excluded; Vercel/remote preservation are separate.

Any candidate change, including guard change, requires a new manifest and independent re-review. No update or execution authorized here.

## Exhaustive historical blocked-name dispositions

Input: D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\HISTORICAL-REQUIRED-BLOCKED-SUBCHECKS.json, SHA256 328053f6908d64f565e7ace56105a2884861c472c3dbcf0d3bb0f641182caeb5. Every row below is **UNTESTED; historical BLOCKED unchanged**. Codes bind exact absolute citations/symbols:

| Code | Source citations |
| --- | --- |
| TOK | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\permission_check.py:340 (_snapshot_token), :431 (NativeToken.from_handle), :738 (inspect_access) |
| DESC | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\permission_check.py:498 (_acl_records), :574 (_decode_descriptor), :654 (inspect_descriptor) |
| PATH | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\path_policy.py:258 (descriptor_principal_routes), :337 (inspect_component), :419 (check_chain) |
| CAP | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\path_policy.py:208 (capability_ceiling), :244 (removal_routes) |
| HELD | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\windows_api.py:116 (Held), :167 (Chain), :350 (new_directory) |
| CREATE | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\windows_api.py:189 (verify_created), :207 (new_file); D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:197 (collision adapters) |
| ALIAS | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\windows_api.py:71 (canonical); D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\path_policy.py:60 (relative_name), :85 (staging_pins) |
| LINK | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\windows_api.py:296 (prepare_hardlink_fixture), :339 (require_hardlink_same_object); D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:241 (L18) |
| INVENTORY | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\path_policy.py:85 (staging_pins), :131 (ExactStagingInventory); D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:285 (L23) |
| PIN | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\Bootstrap.ps1:28 (Read-C5PinnedStream), :50 (manifest), :77 (pins); D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:296 (L24) |
| LOADER | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\Bootstrap.ps1:85 (binary provenance); D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\path_policy.py:441 (blockers); D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:310 (L25) |
| NATIVE | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\native\ContainedLaunch.cs:131 (job), :186 (suspended create), :206 (assign), :217 (resume), :290 (TerminateExact), :327 (Drain) |
| FINAL | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:323 (L28), :355 (accounting), :379 (aggregate), :382 (external parent envelope); D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\Bootstrap.ps1:107 (inspector) |
| SYNTH | D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\run.py:117 (semantic), :113 (planned placeholders); D:\OpenClaw-workspace\artifacts\mcvplus-pgr1-source-only-20261031-candidate01\source\gate.py:56 (rejection-only classifier) |

| Case | Exact required historical blocked name | Source mapping and unresolved disposition |
| --- | --- | --- |
| L01 | parent-and-child-descriptors | TOK, DESC, PATH: machinery authored; real representative provenance/full path proof absent. |
| L01 | real-token-provenance | TOK: kernel handle required but origin/class admission missing; labels do not qualify provenance. |
| L02 | existing-protected-branch | PATH, HELD: rejection/chain source authored; sibling exception, redirect authority/relative continuity incomplete. |
| L02 | no-redirect-route | PATH, HELD: rejection/chain source authored; sibling exception, redirect authority/relative continuity incomplete. |
| L02 | full-chain-held-identity | PATH, HELD: rejection/chain source authored; sibling exception, redirect authority/relative continuity incomplete. |
| L03 | combined-delete-route-blocks | CAP, PATH, SYNTH: DELETE/parent DELETE_CHILD rejection authored; actual combined-route adversarial/reference proof absent. |
| L04 | independent-delete-route-blocks | CAP, PATH, SYNTH: independent removal routes authored; actual adversarial/reference proof absent. |
| L05 | code-loader-insertion | PATH, CAP, SYNTH: per-right rejection authored; installed loader insertion closure/actual controls absent. |
| L06 | untrusted-owner-implicit-authority | TOK, DESC, PATH: trust inspection authored; owner/privilege semantics and actual coverage incomplete. |
| L06 | owner-rights-grant | TOK, DESC, PATH: trust inspection authored; owner/privilege semantics and actual coverage incomplete. |
| L06 | owner-rights-deny | TOK, DESC, PATH: trust inspection authored; owner/privilege semantics and actual coverage incomplete. |
| L06 | enabled-vs-deny-only-admin | TOK: enabled/non-deny-only/elevated/high-IL/unrestricted trust predicate authored; actual coverage unverified. |
| L06 | enabled-security-privileges | TOK, DESC, PATH: trust inspection authored; owner/privilege semantics and actual coverage incomplete. |
| L07 | reparse-relevance-unresolved | PATH, HELD: EA/attribute rejection authored; complete redirect relevance/authority semantics absent. |
| L08 | file-vs-directory-type | TOK, DESC: held type/generic mapping authored; actual file/directory native comparison absent. |
| L09 | normal-restricted-intersection | TOK, DESC: snapshot/native restricted route authored; upward MIC/privilege/unsupported conditions block; actual coverage absent. |
| L09 | deny-only-deny-effective | TOK, DESC: snapshot/native restricted route authored; upward MIC/privilege/unsupported conditions block; actual coverage absent. |
| L09 | low-vs-medium-mandatory-integrity | TOK, DESC: snapshot/native restricted route authored; upward MIC/privilege/unsupported conditions block; actual coverage absent. |
| L09 | enabled-privileges-captured | TOK, DESC: snapshot/native restricted route authored; upward MIC/privilege/unsupported conditions block; actual coverage absent. |
| L09 | no-privilege-enablement | TOK: no privilege-enablement API supplied; source untested; no acquisition authorization. |
| L09 | real-token-unavailable-no-substitute | TOK: unavailable real tokens block; synthetic context cannot establish representative provenance. |
| L10 | null-dacl | DESC: absent/null DACL explicitly unsupported; rejection untested. |
| L10 | callback-ace | DESC, TOK, PATH: unsupported/null/unresolved conditions reject; general group/claim/ACE semantics incomplete. |
| L10 | conditional-ace | DESC, TOK, PATH: unsupported/null/unresolved conditions reject; general group/claim/ACE semantics incomplete. |
| L10 | object-ace | DESC, TOK, PATH: unsupported/null/unresolved conditions reject; general group/claim/ACE semantics incomplete. |
| L10 | unresolved-sid | DESC, TOK, PATH: unsupported/null/unresolved conditions reject; general group/claim/ACE semantics incomplete. |
| L10 | unresolved-group | DESC, TOK, PATH: unsupported/null/unresolved conditions reject; general group/claim/ACE semantics incomplete. |
| L10 | unresolved-claim | DESC, TOK, PATH: unsupported/null/unresolved conditions reject; general group/claim/ACE semantics incomplete. |
| L11 | postgres-denied-parent-add-child | CAP, PATH, TOK: Postgres own-subtree ceiling authored; actual token/installed separation/external loader closure absent. |
| L11 | evidence-denied | CAP, PATH, TOK: Postgres own-subtree ceiling authored; actual token/installed separation/external loader closure absent. |
| L11 | secrets-denied | CAP, PATH, TOK: Postgres own-subtree ceiling authored; actual token/installed separation/external loader closure absent. |
| L11 | cluster-config-mutable-not-code-proof | CAP: own mutable data/config is not immutable-code proof; external/config/loader closure absent. |
| L11 | external-preload-tablespace-config-blocked | CAP, PATH, TOK: Postgres own-subtree ceiling authored; actual token/installed separation/external loader closure absent. |
| L11 | real-postgres-token-unavailable | TOK, CAP: actual Postgres token and installed SCM provenance unavailable. |
| L12 | provider-logs-rotation-rename | CAP, PATH, TOK: ceilings authored; rotation/destination/name authority and actual installed/token separation absent. |
| L12 | state-root-delete-add-denied | CAP, PATH, TOK: ceilings authored; rotation/destination/name authority and actual installed/token separation absent. |
| L12 | cross-service-denied | CAP, PATH, TOK: ceilings authored; rotation/destination/name authority and actual installed/token separation absent. |
| L12 | no-real-slot-or-log | CAP, SYNTH: disabled dummy fixtures only; no real slot/log/attempt or any execution. |
| L12 | real-service-tokens-unavailable | TOK: actual qualified service-token corpus/SCM binding evidence absent. |
| L13 | provider-binding-write-denied | CAP, PATH, TOK: read-only ceilings authored; installed per-service/cross-service actual-right evidence absent. |
| L13 | tunnel-credential-write-denied | CAP, PATH, TOK: read-only ceilings authored; installed per-service/cross-service actual-right evidence absent. |
| L13 | cross-service-all-mutation-masks | CAP, PATH, TOK: read-only ceilings authored; installed per-service/cross-service actual-right evidence absent. |
| L14 | service-modify-on-code | DESC, PATH, CAP: mutation/inheritance rejects; CREATOR OWNER semantics incomplete; actual contamination control absent. |
| L14 | creator-owner-contamination | DESC, PATH, CAP: mutation/inheritance rejects; CREATOR OWNER semantics incomplete; actual contamination control absent. |
| L14 | child-deny-does-not-fix-parent | DESC, PATH, CAP: mutation/inheritance rejects; CREATOR OWNER semantics incomplete; actual contamination control absent. |
| L15 | service-name-inert-observation-no-scm | CREATE: service-name observation inert; no SCM collision adapter/action. |
| L15 | sentinel-bytes-identical | CREATE, HELD: collision/sentinel source authored; independent negative/failure/preservation verification absent; no SCM adapter. |
| L15 | sentinel-acl-identical | CREATE, HELD: collision/sentinel source authored; independent negative/failure/preservation verification absent; no SCM adapter. |
| L15 | sentinel-id-identical | CREATE, HELD: collision/sentinel source authored; independent negative/failure/preservation verification absent; no SCM adapter. |
| L15 | zero-destination-writes | CREATE, HELD: collision/sentinel source authored; independent negative/failure/preservation verification absent; no SCM adapter. |
| L15 | no-acl-repair | CREATE, HELD: collision/sentinel source authored; independent negative/failure/preservation verification absent; no SCM adapter. |
| L16 | preplanted-junction | HELD, PATH: observed reparse/volume changes reject; junction/tag/traversal/target/adversarial controls unverified. |
| L16 | other-reparse-tag | HELD, PATH: observed reparse/volume changes reject; junction/tag/traversal/target/adversarial controls unverified. |
| L16 | unexpected-volume-transition | HELD, PATH: observed reparse/volume changes reject; junction/tag/traversal/target/adversarial controls unverified. |
| L16 | reject-before-traversal | HELD, PATH: observed reparse/volume changes reject; junction/tag/traversal/target/adversarial controls unverified. |
| L16 | target-sentinel-unchanged | HELD, PATH: observed reparse/volume changes reject; junction/tag/traversal/target/adversarial controls unverified. |
| L16 | no-shared-junction-modification | HELD, PATH: observed reparse/volume changes reject; junction/tag/traversal/target/adversarial controls unverified. |
| L17 | traversal | ALIAS, INVENTORY: lexical/collision rejection authored; actual inventory/admission negative controls absent. |
| L17 | ads | ALIAS, INVENTORY: lexical/collision rejection authored; actual inventory/admission negative controls absent. |
| L17 | unc | ALIAS, INVENTORY: lexical/collision rejection authored; actual inventory/admission negative controls absent. |
| L17 | device-namespace | ALIAS, INVENTORY: lexical/collision rejection authored; actual inventory/admission negative controls absent. |
| L17 | case-collision | ALIAS, INVENTORY: lexical/collision rejection authored; actual inventory/admission negative controls absent. |
| L17 | trailing-dot | ALIAS, INVENTORY: lexical/collision rejection authored; actual inventory/admission negative controls absent. |
| L17 | trailing-space | ALIAS, INVENTORY: lexical/collision rejection authored; actual inventory/admission negative controls absent. |
| L17 | short-alias | ALIAS, INVENTORY: lexical/collision rejection authored; actual inventory/admission negative controls absent. |
| L17 | reserved-name | ALIAS, INVENTORY: lexical/collision rejection authored; actual inventory/admission negative controls absent. |
| L17 | duplicate-inventory | ALIAS, INVENTORY: lexical/collision rejection authored; actual inventory/admission negative controls absent. |
| L18 | link-count-greater-than-one | LINK, HELD: F01 ordering/guard/sentinels authored; no actual hardlink/identity verification; F05 remains. |
| L18 | held-file-id | LINK, HELD: F01 ordering/guard/sentinels authored; no actual hardlink/identity verification; F05 remains. |
| L18 | same-bytes-insufficient | LINK, HELD: F01 ordering/guard/sentinels authored; no actual hardlink/identity verification; F05 remains. |
| L18 | all-alias-proof-unavailable | LINK: only two fixed names observed by proposed sentinels; no exhaustive alias/parent/observer proof or production exception. |
| L19 | trusted-owner | CREATE, HELD, PATH: at-create descriptor/readback authored; observer/owner/creation-window continuity absent. |
| L19 | no-inherited-untrusted-grant | CREATE, HELD, PATH: at-create descriptor/readback authored; observer/owner/creation-window continuity absent. |
| L19 | immediate-untrusted-observer | CREATE, HELD, PATH: at-create descriptor/readback authored; observer/owner/creation-window continuity absent. |
| L19 | no-postcreate-repair | CREATE, HELD, PATH: at-create descriptor/readback authored; observer/owner/creation-window continuity absent. |
| L20 | untrusted-substitution-attempt | HELD, CREATE, PATH: absolute create/open remains; no relative primitive/substitution/rename/lower-privilege proof. |
| L20 | untrusted-parent-rename-attempt | HELD, CREATE, PATH: absolute create/open remains; no relative primitive/substitution/rename/lower-privilege proof. |
| L20 | exclusive-create-held-object-equivalence | HELD, CREATE, PATH: absolute create/open remains; no relative primitive/substitution/rename/lower-privilege proof. |
| L20 | lower-privilege-window-proof | HELD, CREATE, PATH: absolute create/open remains; no relative primitive/substitution/rename/lower-privilege proof. |
| L21 | parents-no-delete-share | HELD: no-delete-share/identity authored; actual drift injection/parent-relative binding proof absent. |
| L21 | leaf-no-delete-share | HELD: no-delete-share/identity authored; actual drift injection/parent-relative binding proof absent. |
| L21 | volume-file-id-recorded | HELD: no-delete-share/identity authored; actual drift injection/parent-relative binding proof absent. |
| L21 | path-handle-drift-injection | HELD: no-delete-share/identity authored; actual drift injection/parent-relative binding proof absent. |
| L22 | receipt-create-new | CREATE, FINAL: exclusive writes authored; complete failure-before-destination/original-error/envelope verification absent. |
| L22 | failure-before-owned-destination | CREATE, FINAL: exclusive writes authored; complete failure-before-destination/original-error/envelope verification absent. |
| L22 | no-finally-write-rejected-path | CREATE, FINAL: exclusive writes authored; complete failure-before-destination/original-error/envelope verification absent. |
| L22 | no-overwrite | CREATE, FINAL: exclusive writes authored; complete failure-before-destination/original-error/envelope verification absent. |
| L22 | original-failure-preserved | CREATE, FINAL: exclusive writes authored; complete failure-before-destination/original-error/envelope verification absent. |
| L23 | same-byte-untrusted-substitution | INVENTORY, HELD: map/inventory source authored; protected copy/real payload absent; substitution controls inert. |
| L23 | source-identity-drift | INVENTORY, HELD: map/inventory source authored; protected copy/real payload absent; substitution controls inert. |
| L23 | missing-file | INVENTORY, HELD: map/inventory source authored; protected copy/real payload absent; substitution controls inert. |
| L23 | extra-file | INVENTORY, HELD: map/inventory source authored; protected copy/real payload absent; substitution controls inert. |
| L23 | extra-directory | INVENTORY, HELD: map/inventory source authored; protected copy/real payload absent; substitution controls inert. |
| L23 | 52-file-anchor-preserved | INVENTORY: map declares 52/anchor; actual payload copy/readback absent. |
| L23 | 1691-entry-map-preserved-no-real-file-reread | INVENTORY: 1691 map metadata independently counted; no external original payload reread/stage. |
| L23 | no-original-source-execution-fallback | INVENTORY, PIN: original source paths inert; pinned candidate loader only; no fallback/candidate execution. |
| L24 | wrong-external-manifest-pin | PIN: pin/inventory code authored; L24 digest/set observations are not actual bootstrap negative controls. |
| L24 | wrong-external-bootstrap-pin | PIN: pin/inventory code authored; L24 digest/set observations are not actual bootstrap negative controls. |
| L24 | stale-policy | PIN: pin/inventory code authored; L24 digest/set observations are not actual bootstrap negative controls. |
| L24 | stale-helper | PIN: pin/inventory code authored; L24 digest/set observations are not actual bootstrap negative controls. |
| L24 | stale-harness | PIN: pin/inventory code authored; L24 digest/set observations are not actual bootstrap negative controls. |
| L24 | extra-manifest-entry | PIN: pin/inventory code authored; L24 digest/set observations are not actual bootstrap negative controls. |
| L24 | adjacent-self-approval-rejected | PIN: pin/inventory code authored; L24 digest/set observations are not actual bootstrap negative controls. |
| L24 | exact-case-normalized-inventory | PIN: pin/inventory code authored; L24 digest/set observations are not actual bootstrap negative controls. |
| L25 | unprotected-temp | LOADER: protected dependency admission/inventory absent; no compiler/binary/build evidence; guards remain. |
| L25 | unprotected-compiler | LOADER: protected dependency admission/inventory absent; no compiler/binary/build evidence; guards remain. |
| L25 | unprotected-dll | LOADER: protected dependency admission/inventory absent; no compiler/binary/build evidence; guards remain. |
| L25 | unprotected-cwd | LOADER: protected dependency admission/inventory absent; no compiler/binary/build evidence; guards remain. |
| L25 | unprotected-path | LOADER: protected dependency admission/inventory absent; no compiler/binary/build evidence; guards remain. |
| L25 | unresolved-dependency | LOADER: protected dependency admission/inventory absent; no compiler/binary/build evidence; guards remain. |
| L25 | block-before-add-type-native-launch | LOADER: no Add-Type path; unconditional guards reject; complete protected dependency adapter absent. |
| L25 | local-temp-task-owned | LOADER: protected task-owned TEMP preparation/admission adapter absent. |
| L25 | compiler-files-retained | LOADER: no compiler/build/artifact; compiler retention evidence unavailable. |
| L27 | timeout-injection | NATIVE, FINAL: proposed owned containment authored; native injection/identity/bounds/cleanup proof absent; outer supervisor missing. |
| L27 | nonzero-child-injection | NATIVE, FINAL: proposed owned containment authored; native injection/identity/bounds/cleanup proof absent; outer supervisor missing. |
| L27 | containment-failure-injection | NATIVE, FINAL: proposed owned containment authored; native injection/identity/bounds/cleanup proof absent; outer supervisor missing. |
| L27 | pid-start-executable-job-identity | NATIVE, FINAL: proposed owned containment authored; native injection/identity/bounds/cleanup proof absent; outer supervisor missing. |
| L27 | suspended-create-assign-before-resume | NATIVE, FINAL: proposed owned containment authored; native injection/identity/bounds/cleanup proof absent; outer supervisor missing. |
| L27 | max-two-owned-children | NATIVE, FINAL: proposed owned containment authored; native injection/identity/bounds/cleanup proof absent; outer supervisor missing. |
| L27 | no-shared-process-sweep | NATIVE: TerminateExact uses owned handles only; no shared sweep in reviewed paths; runtime verification absent. |
| L27 | zero-survivors-or-blocked-containment | NATIVE, FINAL: proposed owned containment authored; native injection/identity/bounds/cleanup proof absent; outer supervisor missing. |
| L27 | no-retry | NATIVE, SYNTH: no child/case retry loop in proposed sequence; paths untested. |
| L28 | exact-28-ids-once | FINAL: accounting/hash source authored; complete parent preservation/failure/envelope/final readbacks absent; no external census. |
| L28 | all-case-hashes | FINAL: accounting/hash source authored; complete parent preservation/failure/envelope/final readbacks absent; no external census. |
| L28 | all-failure-receipts-retained | FINAL: accounting/hash source authored; complete parent preservation/failure/envelope/final readbacks absent; no external census. |
| L28 | stdout-stderr-retained-if-any | FINAL: accounting/hash source authored; complete parent preservation/failure/envelope/final readbacks absent; no external census. |
| L28 | evidence-byte-manifest | FINAL: accounting/hash source authored; complete parent preservation/failure/envelope/final readbacks absent; no external census. |
| L28 | roots-readonly-metadata-if-accessible | FINAL: accounting/hash source authored; complete parent preservation/failure/envelope/final readbacks absent; no external census. |
| L28 | service-readonly-metadata-if-supported | FINAL: accounting/hash source authored; complete parent preservation/failure/envelope/final readbacks absent; no external census. |
| L28 | no-credential-ledger-content-read | FINAL: disabled dummy/metadata harness; reviewer read no credential/ledger content; no operational census. |
| L28 | no-cloud-delta-claim-without-proof | FINAL: no remote/network census; preserved zero-spend declaration is not cloud delta proof. |
| L28 | owned-job-empty | FINAL: accounting/hash source authored; complete parent preservation/failure/envelope/final readbacks absent; no external census. |
| L28 | not-run-remains-not-run | FINAL: stopped loop emits NOT_RUN; F05 pre-loop failure lacks complete accounting; zero cases executed. |
| L28 | no-reruns | FINAL: one-pass proposed case loop; zero review runs/retries. |

All 134 names explicitly mapped. No row changes original evidence or claims execution. Identity JSON also records the complete mapping and independently checked file identities.
