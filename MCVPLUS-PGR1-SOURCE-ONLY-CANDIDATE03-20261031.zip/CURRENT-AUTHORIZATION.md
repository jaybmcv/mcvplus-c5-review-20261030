# Current authorization — source authoring and independent source review only
Requester: Biggunn, 2026-10-31, requesting conversation. Source-only candidate at this exact separate directory. This document supersedes ALL historical execution permissions in original-reference.

Permitted: read and copy original source bytes without changes to originals; author revised candidate source and documentation; JSON data inventory, exact byte lengths and SHA256 hashing; independent textual source review of exact frozen manifest.

NOT authorized: execute, compile, import candidate/helper/launcher code (including syntax/AST checks), create or run disposable fixtures, tests, probes or retries. No operational root, service identity, token, ACL, SCM, launch-dependency or installed-state probing. No Setup, operational staging, deployment, hosted testing, network/remote verification, credential/approval-pin/financial/ledger/database/tunnel/provider actions, shared ACL or service/account changes, reboot or deletion. Existing application/deployment branches remain untouched. No public upload or communications publication. Delivery of source/review text to requester is permitted.

Original run/source/receipts/reviews remain unchanged. Historical results remain exactly 1 static PASS (L26) and 27 BLOCKED. No source correction retrospectively repairs F01/F02/F03/F04 evidence gaps. No candidate execution means new runtime evidence count ZERO. Revised source is UNTESTED, not qualified; independent source review is NOT a passing test. All 48 hosted attempts (42 primary +6 reserve) remain unspent. Supported Vercel access restoration remains separate and unverified.

Future verification categories describe prerequisites only, not authorization. Future disposable local checks and actual operational root/identity/SCM/loader evidence must be distinguished. Unknown, unsupported, unavailable or unfounded inputs must fail closed. No synthetic operational proof or caller approval flags.

Original reference access: first workspace-write source worker could read current task/inventory but not original external directory. Parent copied required original source/review/harness files byte-preservingly into original-reference; worker resumed using copies, without permission changes or access bypass. This was source-preparation recovery, not a candidate test retry.

Preservation scope: ORIGINAL-PRESERVATION-BEFORE.json records original regular-file bytes/lengths/hashes and reparse-entry metadata without following it. Final byte comparison is local source/evidence preservation only; no remote, financial or service census is claimed.
